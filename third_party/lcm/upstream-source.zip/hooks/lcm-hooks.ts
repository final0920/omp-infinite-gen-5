// hooks/lcm-hooks.ts — lcm's function-hooks module (Claude Code early access).
//
// Claude Code loads it whenever its mods (function hooks) are on; the command hooks remain
// for when they are not. It claims the session in a temp-dir file, rewritten in every
// classic event a claim-reading command hook listens to, before that command hook runs,
// and withdrawn at session.end. While the claim stands the SessionStart, PostToolUse,
// PostToolUseFailure, UserPromptSubmit and Stop command hooks stay silent
// (functionHooksOwnSession in src/hooks/session-claim.ts) and this module does their work
// through the daemon:
//   tool.call       → POST /tool-event    (the daemon writes the passive-learning rows)
//   prompt.submit   → POST /prompt-search (memory hits ride as hidden context on the prompt)
//   prompt.section  → the learning instruction is appended once to the system prompt's
//                     `memory` section, instead of to every prompt.
//   prompt.context  → POST /restore (the session's memory, as one named context block)
//   turn.complete   → POST /ingest (the daemon reads the transcript delta) and
//                     POST /promote-events, at most once a minute, replacing the Stop hook.
// The module has no Node and no SQLite, so the daemon does every write.
//
// Types: Claude Code writes them to .claude-plugin/types/ when it loads this plugin from a
// folder you own (`claude --plugin-dir .`); then `import type { Register } from "claude-code"`.
// They are written from the running build and not committed, so the check is on demand:
// `npm run typecheck:hooks`. Run it after a Claude Code update too — the API is early
// access, and a green run is the answer to whether the release moved anything under this.
// `claude plugin validate` reads this file statically: `$` may only be passed to a function
// declared at the top level, and calls on it must be spelled `$.noun.method(...)`.
import type { Register, EngineInterface } from "claude-code";
import { endSharedSessionBudget, sharedSessionOutputBudget, type SessionOutputBudget } from "./model-budget.js";
import { endShadowSessionBudget } from "./shadow-budget.js";
import type { ShadowDeadline } from "./shadow-deadline.js";
import type { ShadowAppend } from "./shadow-boundaries.js";
import { ShadowSessionState, runCompactionShadow, type ShadowTransport, type ShadowEngine } from "./compaction-shadow.js";

/** Same set the PostToolUse matcher in plugin.json names; `mcp__*` is matched by prefix. */
const CAPTURED_TOOLS = new Set([
  "Agent", "AskUserQuestion", "Bash", "EnterPlanMode", "ExitPlanMode",
  "Read", "Edit", "Write", "Glob", "Grep", "TaskCreate", "TaskUpdate", "Skill",
]);
const DEFAULT_PORT = 3737;
/** Fallback when the host command cannot report TMPDIR; matches Node os.tmpdir() on POSIX. */
const DEFAULT_TMP_DIR = "/tmp";
/** Same default as hooks.snapshotIntervalSec for the Stop command hook: one ingest a minute. */
const INGEST_INTERVAL_MS = 60_000;
let lastIngestAt = 0;

// Verbatim copy of LEARNING_INSTRUCTION in src/guidance.ts (the module cannot import from src/);
// test/hooks/learning-instruction.test.ts fails when the two drift.
const LEARNING_INSTRUCTION = `<learning-instruction>
When you recognize a durable insight, call lcm_store immediately:
- decision: an architectural or design choice, with the trade-off that settled it
- preference: how the user wants things done
- root-cause: a bug cause that took effort to uncover
- pattern: a codebase convention documented nowhere else
- gotcha: a non-obvious pitfall
- solution: a non-trivial fix worth remembering
- workflow: a multi-step process that works

Tag each store with type: plus one of project: or scope:; add source: when the origin matters for trust, and priority: rarely.
Usage: lcm_store(text: "concise insight with why", tags: ["type:decision", "project:<repo>"])

When you act on a surfaced memory (use it to inform a decision, avoid a known pitfall, or reference it in your work), emit:
lcm_store(text: "Acted on memory <id> — <one-line how>", tags: ["signal:memory_used", "memory_id:<id>"])

When you check a surfaced memory against current evidence, vote on it (reason is required both ways):
lcm_store(text: "<what confirmed it, e.g. a file, test, or command output>", tags: ["signal:memory_vote", "vote:+1", "memory_id:<id>"])
lcm_store(text: "<what contradicts it>", tags: ["signal:memory_vote", "vote:-1", "memory_id:<id>"])
"Not relevant here" is not a -1 — only a real contradiction is.
</learning-instruction>`;

/** What the module cannot read for itself: everything outside $.fs's project-and-temp reach. */
type HostEnv = { port: number; token: string | null; tmpDir: string };
let hostEnv: Promise<HostEnv> | null = null;
/** Routes the running daemon answered 404 for: an older lcm build. Logged once each, not per call. */
const missingRoutes = new Set<string>();

type HookObservation = {
  hook: string;
  operation: string;
  kind: "delivery" | "execution";
  status: string;
  reason: string;
  count: number;
};
type HookSnapshot = {
  counts: Map<string, HookObservation>;
  failures: { hook: string; operation: string; code: string; at: number }[];
  seq: number;
  truncated: boolean;
  writing: boolean;
};
const hookSnapshots = new Map<string, HookSnapshot>();
const MAX_HOOK_OBSERVATIONS = 128;
const MAX_ACTIVE_HOOK_SESSIONS = 32;
const hookSnapshotGeneration = Date.now();
const failedHookSnapshotWrites = new Set<string>();

function sessionFileId(sessionId: string): string {
  return encodeURIComponent(sessionId).replace(/[_.!~*'()]/g,
    (char) => `%${char.charCodeAt(0).toString(16).toUpperCase().padStart(2, "0")}`);
}

function noteHook(
  sessionId: string, hook: string, operation: string,
  kind: HookObservation["kind"], status: string, reason = "",
): void {
  if (!sessionId?.trim()) return;
  const snapshot = hookSnapshots.get(sessionId) ?? {
    counts: new Map<string, HookObservation>(), failures: [], seq: 0, truncated: false, writing: false,
  };
  if (!hookSnapshots.has(sessionId) && hookSnapshots.size >= MAX_ACTIVE_HOOK_SESSIONS) {
    hookSnapshots.delete(hookSnapshots.keys().next().value!);
  }
  hookSnapshots.set(sessionId, snapshot);
  noteObservation(snapshot, { hook, operation, kind, status, reason, count: 1 });
}
function noteObservation(snapshot: HookSnapshot, observation: HookObservation): void {
  const key = JSON.stringify([observation.hook, observation.operation, observation.kind, observation.status, observation.reason]);
  const existing = snapshot.counts.get(key);
  if (existing) existing.count++;
  else addObservation(snapshot, key, observation);
  if (observation.status !== "failed" && observation.status !== "rejected") return;
  snapshot.failures.push({ hook: observation.hook, operation: observation.operation, code: observation.reason || observation.status, at: Date.now() });
  if (snapshot.failures.length <= 32) return;
  snapshot.failures.shift(); snapshot.truncated = true;
}
function addObservation(snapshot: HookSnapshot, key: string, observation: HookObservation): void {
  if (snapshot.counts.size >= MAX_HOOK_OBSERVATIONS) {
    snapshot.counts.delete(snapshot.counts.keys().next().value!); snapshot.truncated = true;
  }
  snapshot.counts.set(key, observation);
}

async function flushHookObservations($: EngineInterface, sessionId: string): Promise<void> {
  if (!sessionId?.trim()) return;
  const snapshot = hookSnapshots.get(sessionId);
  if (!snapshot || snapshot.writing) return;
  snapshot.writing = true;
  const pending = writeHookSnapshot($, { snapshot, sessionId }).catch(() => undefined)
    .finally(() => { snapshot.writing = false; });
  try {
    await Promise.race([
      pending,
      $.clock.sleep(250),
    ]);
  } catch {
    return; // Diagnostic host failure leaves the turn usable.
  }
}

async function writeHookSnapshot($: EngineInterface, { snapshot, sessionId }: { snapshot: HookSnapshot; sessionId: string }): Promise<void> {
    const { tmpDir } = await readHostEnv($);
    const safeId = sessionFileId(sessionId);
    const cwd = await $.session.cwd().catch(() => "");
    const seq = ++snapshot.seq;
    const path = `${tmpDir}/lcm-hook-observe-${safeId}-${seq % 2}.json`;
    const content = JSON.stringify({
      version: 1, harness: "claude-function", sessionId, cwd, seq, generation: hookSnapshotGeneration,
      updatedAt: Date.now(), truncated: snapshot.truncated,
      observations: [...snapshot.counts.values()], failures: snapshot.failures,
    });
    try {
      await $.fs.write(path, content);
    } catch {
      warnSnapshotWrite($, sessionId);
    }

}

function warnSnapshotWrite($: EngineInterface, sessionId: string): void {
  if (failedHookSnapshotWrites.has(sessionId)) return;
  failedHookSnapshotWrites.add(sessionId);
  try { $.ui.log("[lcm] hook observation snapshot could not be written"); }
  catch { return; }
}

/** No config file yet, or one being rewritten, both mean the compiled-in port. */
function parsePort(configJson: string): number {
  try {
    const port = JSON.parse(configJson).daemon?.port;
    return typeof port === "number" ? port : DEFAULT_PORT;
  } catch {
    return DEFAULT_PORT;
  }
}

// The daemon's port and bearer token live under the lcm home, and TMPDIR is an
// environment value; neither is reachable through $.fs (project and temp dir only), so
// one host command reads all three once per module load. LCM_HOME moves that home, which
// is what lets a sandbox run this module without touching the host's own lcm state.
function readHostEnv($: EngineInterface): Promise<HostEnv> {
  hostEnv ??= $.process.run(["sh", "-c",
    // Trimmed before the emptiness test, so a blank LCM_HOME falls back here exactly as
    // it does in lcmHome(); otherwise the two sides disagree about the root.
    'H=$(printf %s "${LCM_HOME:-}" | sed "s/^[[:space:]]*//; s/[[:space:]]*$//"); '
    + '[ -n "$H" ] || H="$HOME/.lossless-claude"; '
    + 'cat "$H/daemon.token" 2>/dev/null; echo; echo "__CONFIG__"; '
    + 'cat "$H/config.json" 2>/dev/null; echo; echo "__TMPDIR__"; '
    + 'printf %s "${TMPDIR:-/tmp}"',
  ]).then(({ stdout }) => {
    const [tokenPart, afterToken = ""] = stdout.split("__CONFIG__");
    const [configPart, tmpPart = ""] = afterToken.split("__TMPDIR__");
    return {
      port: parsePort(configPart),
      token: tokenPart.trim() || null,
      tmpDir: tmpPart.trim().replace(/\/+$/, "") || DEFAULT_TMP_DIR,
    };
  }, () => ({ port: DEFAULT_PORT, token: null, tmpDir: DEFAULT_TMP_DIR }));
  return hostEnv;
}

/**
 * Tell the command hooks this module is live for this session, so they stay silent
 * instead of doing the same work again. Read by functionHooksOwnSession in
 * src/hooks/session-claim.ts, which names the same file from Node's os.tmpdir() and
 * counts it only while `ts` is fresh and no `ended` is set. No claim means "not mine",
 * costing a duplicate row rather than a lost one, so nothing here is worth failing an
 * event over.
 */
async function writeClaim($: EngineInterface, sessionId: string, ended?: string): Promise<void> {
  if (!sessionId) return;
  const { tmpDir } = await readHostEnv($);
  const file = `${tmpDir}/lcm-claim-${sessionFileId(sessionId)}.json`;
  await $.fs.write(file, JSON.stringify({ sessionId, ts: Date.now(), ...(ended ? { ended } : {}) }));
}

/** Sessions whose claim could not be written, so the failure is logged once, not per event. */
const unclaimedSessions = new Set<string>();

async function claimSession($: EngineInterface, sessionId: string, hook: string): Promise<void> {
  let claimed = true;
  await writeClaim($, sessionId).catch((error: unknown) => {
    claimed = false;
    if (unclaimedSessions.has(sessionId)) return;
    unclaimedSessions.add(sessionId);
    $.ui.log(`[lcm] could not claim the session, command hooks stay active: ${String(error)}`);
  });
  noteHook(sessionId, hook, "claim", "execution", claimed ? "completed" : "failed",
    claimed ? "" : "write-failed");
}

/**
 * The claim is rewritten in each classic event a claim-reading command hook listens to.
 * Modules run before the command hooks of the same event, which run inside `next(e)`,
 * so the claim is fresh when they read it. That also covers a session id that begins
 * with /clear, /resume or /branch, where no session.start fires: its classic
 * SessionStart claims it before the SessionStart command hook can restore.
 */
function registerSessionClaim(on: On, shadow?: ShadowSessionState): void {
  on("classic.SessionStart", async ($, e, next) => {
    if (["clear", "resume", "fork"].includes(e.source)) shadow?.reset(e.session_id);
    await claimSession($, e.session_id, "classic.SessionStart");
    return next(e);
  });
  on("classic.UserPromptSubmit", async ($, e, next) => {
    await claimSession($, e.session_id, "classic.UserPromptSubmit");
    return next(e);
  });
  on("classic.PostToolUse", async ($, e, next) => {
    await claimSession($, e.session_id, "classic.PostToolUse");
    return next(e);
  });
  on("classic.PostToolUseFailure", async ($, e, next) => {
    await claimSession($, e.session_id, "classic.PostToolUseFailure");
    return next(e);
  });
  on("classic.Stop", async ($, e, next) => {
    await claimSession($, e.session_id, "classic.Stop");
    return next(e);
  });
}

/**
 * session.end fires on exit, /clear, /resume and /branch. The ending id's claim is
 * withdrawn so a later run of that id without this module records again; a crash skips
 * this, and its claim lapses with its timestamp instead.
 */
function registerSessionEnd(on: On, shadow?: ShadowSessionState): void {
  on("session.end", async ($, e, next) => {
    shadow?.reset(e.sessionId);
    endSharedSessionBudget(e.sessionId); endShadowSessionBudget(e.sessionId);
    await writeClaim($, e.sessionId, e.reason).catch(() => { /* the claim lapses on its own */ });
    return next(e);
  });
}

/** Last time this module asked the host to start the daemon; one attempt per cooldown window. */
let lastDaemonStartAt = 0;
const DAEMON_START_COOLDOWN_MS = 60_000;
const DAEMON_START_TIMEOUT_MS = 15_000;
const HEALTH_PROBE_TIMEOUT_MS = 500;
const DAEMON_POST_TIMEOUT_MS = 5_000;
const RESTORE_TIMEOUT_MS = 10_000;
/** The daemon's summary-job long poll holds for up to 25 seconds. */
const SUMMARY_POLL_TIMEOUT_MS = 30_000;
let warnedBusyDaemon = false;
/** POSIX exit code for "command not found": no `lcm` binary on PATH. */
const EXIT_COMMAND_NOT_FOUND = 127;
/** `daemon start --automatic` reports an active hold with EX_TEMPFAIL. */
const EXIT_DAEMON_HELD = 75;
let warnedNoLcmBinary = false;

/**
 * The daemon exits when idle and the command hooks used to bring it back (ensureDaemon).
 * While this module owns the events, it must do the same, or every tool call and prompt
 * between the idle exit and the next SessionStart is lost. `lcm daemon start --detach`
 * spawns the daemon and waits until /health answers.
 */
async function startDaemon($: EngineInterface): Promise<boolean> {
  const now = Date.now();
  if (now - lastDaemonStartAt < DAEMON_START_COOLDOWN_MS) return false;
  lastDaemonStartAt = now;
  const run = await $.process.run(
    ["sh", "-c", 'command -v lcm >/dev/null 2>&1 || exit 127; exec lcm daemon start --detach --automatic'],
    { timeoutMs: DAEMON_START_TIMEOUT_MS },
  ).catch(() => null);
  if (run?.exitCode === EXIT_DAEMON_HELD) {
    if (lastDaemonStartAt === now) lastDaemonStartAt = 0;
    return false;
  }
  return reportDaemonLaunch($, run);
}
function reportDaemonLaunch($: EngineInterface, run: Awaited<ReturnType<EngineInterface["process"]["run"]>> | null): boolean {
  if (run?.exitCode === 0) return true;
  if (run?.exitCode === EXIT_COMMAND_NOT_FOUND && !warnedNoLcmBinary) {
    warnedNoLcmBinary = true;
    $.ui.log("[lcm] daemon is down and no `lcm` binary is on PATH to start it; events are lost until a command hook restarts it");
  } else if (run && run.exitCode !== EXIT_COMMAND_NOT_FOUND) {
    $.ui.log(`[lcm] daemon start failed (exit ${run.exitCode}): ${run.stderr.trim().split("\n")[0] ?? ""}`);
  }
  return false;
}

type PostOutcome = { body: Record<string, unknown> | null; connectionFailed: boolean; httpStatus?: number };

/** A refused connection fails at once; a listener that is busy fails only after a wait. */
const REFUSED_WITHIN_MS = 1_000;

/**
 * Whether a call started at `startedAt` failed for lack of a listener, which a start and a
 * retry can fix. The error comes from the host's realm, so its fields are read rather than
 * trusted to `instanceof`; one that names no refusal is judged by how long it took.
 */
function isDaemonUnreachableError(error: unknown, startedAt: number): boolean {
  const fields = (value: unknown) =>
    (typeof value === "object" && value !== null ? value : {}) as { code?: unknown; message?: unknown; cause?: unknown; name?: unknown };
  const failure = fields(error);
  if (failure.name === "TimeoutError" || failure.name === "AbortError") return false;
  const text = [failure.code, fields(failure.cause).code, failure.message].map(String).join(" ");
  return /ECONNREFUSED|connection refused/i.test(text) || Date.now() - startedAt < REFUSED_WITHIN_MS;
}

/** Bound our wait even on hosts that do not put a deadline on HTTP fetches. */
async function fetchDaemon(
  $: EngineInterface, url: string, init: Parameters<EngineInterface["http"]["fetch"]>[1], timeoutMs: number,
): ReturnType<EngineInterface["http"]["fetch"]> {
  return Promise.race([
    Promise.resolve().then(() => $.http.fetch(url, init)),
    Promise.resolve().then(() => $.clock.sleep(timeoutMs)).then(() => {
      const error = new Error("daemon did not answer within its deadline");
      error.name = "TimeoutError";
      throw error;
    }),
  ]);
}

function reportBusyDaemon($: EngineInterface): void {
  if (warnedBusyDaemon) return;
  warnedBusyDaemon = true;
  $.ui.log("[lcm] daemon busy, did not answer; delivery is unconfirmed and the next capture will retry");
}

function delivery(outcome: PostOutcome): ["accepted" | "rejected" | "unconfirmed", string] {
  return outcome.body ? ["accepted", ""]
    : outcome.httpStatus !== undefined ? ["rejected", `http-${outcome.httpStatus}`]
      : ["unconfirmed", "unconfirmed"];
}

/** A 404 means an older lcm build is listening. Say so once per route, not per call. */
function logMissingRoute($: EngineInterface, route: string, consequence: string): void {
  if (missingRoutes.has(route)) return;
  missingRoutes.add(route);
  $.ui.log(`[lcm] daemon has no ${route} route (older lcm build); ${consequence}`);
}

async function postOnce($: EngineInterface, route: string, body: unknown): Promise<PostOutcome> {
  let startedAt = Date.now();
  let res: Awaited<ReturnType<EngineInterface["http"]["fetch"]>>;
  try {
    const { port, token } = await readHostEnv($);
    startedAt = Date.now();
    res = await fetchDaemon($, `http://127.0.0.1:${port}${route}`, {
      method: "POST",
      headers: { "content-type": "application/json", ...(token ? { authorization: `Bearer ${token}` } : {}) },
      body: JSON.stringify(body),
    }, route === "/restore" ? RESTORE_TIMEOUT_MS : DAEMON_POST_TIMEOUT_MS);
  } catch (error) {
    if (isDaemonUnreachableError(error, startedAt)) return { body: null, connectionFailed: true };
    // A timed-out or dropped call may still complete. The next Stop snapshot or scan
    // captures the turn, so starting another daemon or retrying now adds no safety.
    reportBusyDaemon($);
    return { body: null, connectionFailed: false };
  }
  if (res.status === 404) {
    // Not "the command hooks still record": they stand down while this module holds the
    // session, so an older daemon means the call is simply lost.
    logMissingRoute($, route, "this call is dropped until the daemon is upgraded");
    return { body: null, connectionFailed: false, httpStatus: res.status };
  }
  if (!res.ok) {
    $.ui.log(`[lcm] ${route}: daemon answered ${res.status}`);
    return { body: null, connectionFailed: false, httpStatus: res.status };
  }
  try {
    return { body: JSON.parse(res.text) as Record<string, unknown>, connectionFailed: false };
  } catch {
    // A listener answered, so neither a start nor a retry applies.
    $.ui.log(`[lcm] ${route}: daemon answered ${res.status} with a body that is not JSON`);
    return { body: null, connectionFailed: false };
  }
}

/**
 * POST `body` to the daemon; resolves to the parsed JSON, or null when the daemon lacks the
 * route or cannot be reached. Only a refused connection starts the daemon and retries once.
 */
async function postDaemonOutcome($: EngineInterface, route: string, body: unknown): Promise<PostOutcome> {
  const first = await postOnce($, route, body);
  if (!first.connectionFailed) return first;
  if (!(await startDaemon($))) return first;
  const second = await postOnce($, route, body);
  if (second.connectionFailed) $.ui.log(`[lcm] ${route}: daemon still unreachable after start`);
  return second;
}

async function postDaemon($: EngineInterface, route: string, body: unknown): Promise<Record<string, unknown> | null> {
  return (await postDaemonOutcome($, route, body)).body;
}

type SummaryJob = {
  id: string;
  session_id: string;
  kind: "leaf" | "condensed";
  system: string;
  prompt: string;
  maxTokens: number;
  pool?: true;
};
type SummaryAnswer = {
  text: string;
  providerId: "session:haiku" | "session:fork" | "session-pool:haiku" | "session-pool:sonnet";
  usage: { input_tokens: number; output_tokens: number; estimated: boolean };
  priorUsage?: UsageAttempt[];
};
type UsageAttempt = {
  providerId: "session:haiku" | "session:fork" | "session-pool:haiku" | "session-pool:sonnet";
  usage: { input_tokens: number; output_tokens: number; estimated: boolean };
  /** Whether this call failed to provide a usable answer. */
  failed?: boolean;
};
type SummaryFailure = Error & { usageAttempts?: UsageAttempt[]; usageUnknown?: boolean };
const DEFAULT_SUMMARY_OUTPUT_CAP = 50_000;
/** The engine's own estimate ratio; used only when the host reports no usage. */
const CHARS_PER_TOKEN = 4;
/** The host capped the long poll below the daemon's hold, so poll short and pause between. */
const SHORT_POLL_PAUSE_MS = 2_000;
/** The daemon has no summarizer route; a later respawn may bring it back. */
const MISSING_ROUTE_RETRY_MS = 60_000;
/** The daemon answered but not with a job: back off before asking again. */
const POLL_BACKOFF_MS = 5_000;
const WORKER_ANSWER_ATTEMPTS = 3;
let summaryPollerStarted = false;

function summaryDelay($: EngineInterface, ms: number): Promise<void> {
  return new Promise((resolve) => { $.clock.after(ms, resolve); });
}

type WorkerModel = "haiku" | "sonnet";

async function completeSummary($: EngineInterface, job: SummaryJob, remainingTokens: number, workerModel?: WorkerModel): Promise<SummaryAnswer> {
  const providerId = workerModel ? `session-pool:${workerModel}` as const : "session:haiku";
  const result = await $.model.complete({
    model: workerModel ?? "haiku", system: job.system, prompt: job.prompt, maxTokens: Math.min(job.maxTokens, remainingTokens),
  });
  // Earlier engine builds returned the text directly; current builds return a
  // discriminated result and do not reject when the provider cannot answer.
  if (typeof result !== "string" && !result.isAnswered) {
    const failure = new Error(result.reason) as SummaryFailure;
    failure.usageAttempts = [{ providerId, usage: {
      input_tokens: result.usage.input_tokens,
      output_tokens: result.usage.output_tokens, estimated: false,
    }, failed: true }];
    throw failure;
  }
  const text = typeof result === "string" ? result : result.text;
  // The engine can mark a completion answered without its text being a string (the
  // exact shape is not confirmed — the module has no committed types for it). Treat
  // that the same as an unanswered job instead of throwing out of `.trim()`.
  if (typeof text !== "string") {
    const failure = new Error("model.complete: answer text was not a string") as SummaryFailure;
    if (typeof result !== "string") {
      failure.usageAttempts = [{ providerId, usage: {
        input_tokens: result.usage.input_tokens,
        output_tokens: result.usage.output_tokens, estimated: false,
      }, failed: true }];
    }
    throw failure;
  }
  const trimmed = text.trim();
  const usage = typeof result === "string"
    ? { input_tokens: Math.ceil((job.system.length + job.prompt.length) / CHARS_PER_TOKEN),
        output_tokens: Math.ceil(trimmed.length / CHARS_PER_TOKEN), estimated: true }
    : { input_tokens: result.usage.input_tokens,
        output_tokens: result.usage.output_tokens, estimated: false };
  return {
    text: trimmed, providerId,
    usage,
  };
}

async function answerSummary($: EngineInterface, job: SummaryJob, remainingTokens: number): Promise<SummaryAnswer> {
  if (job.kind !== "condensed") return completeSummary($, job, remainingTokens);
  const fork = await $.model.fork({ prompt: `${job.system}\n\n${job.prompt}` }).catch(() => null);
  if (fork && usableSummaryFork(fork)) {
    return { text: fork.text.trim(), providerId: "session:fork",
      usage: { input_tokens: fork.usage.input_tokens, output_tokens: fork.usage.output_tokens, estimated: false } };
  }
  const forkTextMalformed = Boolean(fork && "text" in fork && "usage" in fork);
  const forkAttempt: UsageAttempt | undefined = fork && "usage" in fork ? { providerId: "session:fork",
    usage: { input_tokens: fork.usage.input_tokens, output_tokens: fork.usage.output_tokens, estimated: false }, failed: true } : undefined;
  const forkSpent = forkAttempt?.usage.output_tokens ?? 0;
  if (forkSpent >= remainingTokens) {
    const failure = new Error("spend cap") as SummaryFailure;
    failure.usageAttempts = forkAttempt ? [forkAttempt] : []; throw failure;
  }
  return fallbackSummary($, { job, remainingTokens: remainingTokens - forkSpent, forkAttempt, forkTextMalformed });
}
function usableSummaryFork(fork: Awaited<ReturnType<EngineInterface["model"]["fork"]>>): fork is Extract<typeof fork, { text: string }> {
  return "text" in fork && "usage" in fork && typeof fork.text === "string";
}
async function fallbackSummary($: EngineInterface, context: { job: SummaryJob; remainingTokens: number; forkAttempt?: UsageAttempt; forkTextMalformed: boolean }): Promise<SummaryAnswer> {
  const { job, remainingTokens, forkAttempt, forkTextMalformed } = context;
  let answer: SummaryAnswer;
  try { answer = await completeSummary($, job, remainingTokens); }
  catch (error) { throw failedSummaryFallback(error, forkAttempt, forkTextMalformed); }
  return forkAttempt ? { ...answer, priorUsage: [forkAttempt] } : answer;
}
function failedSummaryFallback(error: unknown, attempt: UsageAttempt | undefined, malformed: boolean): unknown {
  if (!attempt) return error;
  const failure = (error instanceof Error ? error : new Error(String(error))) as SummaryFailure;
  if (malformed) failure.message = `model.fork: answer text was not a string; fallback: ${failure.message}`;
  failure.usageUnknown ||= !failure.usageAttempts?.length;
  failure.usageAttempts = [attempt, ...(failure.usageAttempts ?? [])];
  return failure;
}

/**
 * One poll of `/summarize-jobs/next`. A `job` is one to run; `wait` means the daemon
 * answered something other than a job and the caller should back off for that long.
 */
type PollOutcome =
  | { job: SummaryJob }
  | { wait: number; shortPoll?: true };

async function fetchNextJob($: EngineInterface, { port, token }: HostEnv, sessionId: string, shortPoll: boolean, worker = false) {
  const binding = worker ? `&caller_session_id=${encodeURIComponent(sessionId)}&cwd=${encodeURIComponent(await $.session.cwd())}&client=claude&transport=hook` : "";
  return fetchDaemon($,
    `http://127.0.0.1:${port}/summarize-jobs/next?${worker ? "worker_id" : "session_id"}=${encodeURIComponent(sessionId)}${binding}${shortPoll ? "&wait_ms=0" : ""}`,
    { headers: token ? { authorization: `Bearer ${token}` } : {} }, SUMMARY_POLL_TIMEOUT_MS,
  );
}

/** Turns a non-job response into how long to wait before asking again. */
function classifyPollResponse($: EngineInterface, status: number): { wait: number } {
  if (status === 204) return { wait: 0 };
  if (status === 404) {
    // An older build answered, or the daemon was swapped mid-session. A later
    // respawn may bring the route back, so keep checking, slowly.
    logMissingRoute($, "/summarize-jobs/next", "retrying every minute");
    return { wait: MISSING_ROUTE_RETRY_MS };
  }
  if (status === 401) hostEnv = null;
  $.ui.log(`[lcm] /summarize-jobs/next: daemon answered ${status}`);
  return { wait: POLL_BACKOFF_MS };
}

async function nextSummaryJob(
  $: EngineInterface, sessionId: string, shortPoll: boolean, worker = false,
): Promise<PollOutcome> {
  let job: SummaryJob | undefined;
  let startedAt = Date.now();
  let response: Awaited<ReturnType<typeof fetchNextJob>>;
  try {
    const host = await readHostEnv($);
    // Timed from the request alone: a slow host-environment read is not the daemon's wait.
    startedAt = Date.now();
    response = await fetchNextJob($, host, sessionId, shortPoll, worker);
  } catch (error) {
    // Some hosts cap HTTP request duration below the daemon's 25-second hold.
    if (isDaemonUnreachableError(error, startedAt)) {
      await startDaemon($);
      hostEnv = null; // A restarted daemon may have a new bearer token.
    }
    return { wait: POLL_BACKOFF_MS, shortPoll: true };
  }
  if (!response.ok || response.status === 204) return classifyPollResponse($, response.status);
  try {
    job = JSON.parse(response.text).job as SummaryJob;
  } catch {
    // A malformed 200 backs off like a transport failure instead of stopping the poller.
    return { wait: POLL_BACKOFF_MS, shortPoll: true };
  }
  return validatePolledJob($, job, { sessionId, worker });
}
function validatePolledJob($: EngineInterface, job: SummaryJob | undefined, { sessionId, worker }: { sessionId: string; worker: boolean }): PollOutcome {
  if (worker && !job) return { wait: 0 };
  if (!job || !summaryJobMatches(job, sessionId, worker)) {
    $.ui.log("[lcm] discarded summary job for a different session"); return { wait: POLL_BACKOFF_MS };
  }
  return { job };
}
function summaryJobMatches(job: SummaryJob, sessionId: string, worker: boolean): boolean {
  return worker ? job.pool === true : job.pool !== true && job.session_id === sessionId;
}

async function postSummaryAnswer($: EngineInterface, job: SummaryJob, route: string, body: unknown): Promise<void> {
  const sessionId = job.pool ? await $.session.id() : job.session_id;
  try {
    const boundBody = job.pool ? { ...(body as Record<string, unknown>),
      worker_id: sessionId, caller_session_id: sessionId, cwd: await $.session.cwd(), client: "claude", transport: "hook",
      providerId: (body as Record<string, unknown>).providerId ?? `session-pool:${await $.env.get("LCM_SUMMARIZE_WORKER_MODEL") || "haiku"}`,
    } : body;
    for (let attempt = 0; attempt < WORKER_ANSWER_ATTEMPTS; attempt++) {
      const outcome = await postDaemonOutcome($, route, boundBody);
      noteHook(sessionId, "session.start", "summary-answer", "delivery", ...delivery(outcome));
      // Submissions are idempotent: a delivered answer with a lost response is
      // discarded on retry. Reuse the answer rather than spending on completion again.
      if (!retrySummaryDelivery(job, outcome)) return;
      if (attempt + 1 === WORKER_ANSWER_ATTEMPTS) return;
      if (outcome.httpStatus === 401) hostEnv = null;
      await summaryDelay($, POLL_BACKOFF_MS);
    }
  } catch (error) {
    noteHook(sessionId, "session.start", "summary-answer", "delivery", "unconfirmed", "transport");
    throw error;
  } finally {
    await flushHookObservations($, sessionId);
  }
}

function retrySummaryDelivery(job: SummaryJob, outcome: PostOutcome): boolean {
  if (outcome.body || !job.pool) return false;
  if (outcome.httpStatus === undefined) return true;
  return outcome.httpStatus >= 500 || outcome.httpStatus === 401 || outcome.httpStatus === 429;
}

/** Answers one job. Returns the output tokens it spent, or null when the cap was hit. */
async function serveSummaryJob(
  $: EngineInterface, job: SummaryJob, budget: SessionOutputBudget, workerModel?: WorkerModel,
): Promise<number | null> {
  const route = `/summarize-jobs/${encodeURIComponent(job.id)}`;
  const lease = await budget.reserveOrdinary(job.maxTokens, !workerModel && job.kind === "condensed");
  if (!lease) {
    await postSummaryAnswer($, job, route, { error: "spend cap" });
    return null;
  }
  let answer: SummaryAnswer;
  try {
    answer = workerModel ? await completeSummary($, job, lease.allowance, workerModel)
      : await answerSummary($, job, lease.allowance);
  } catch (error) {
    const { attempts, used, unknown } = failedSummaryAccounting(error);
    lease.settle(used, unknown);
    const overshot = budget.snapshot().overshoot > 0;
    await postSummaryAnswer($, job, route, { error: overshot ? "spend cap" : error instanceof Error ? error.message : String(error),
      ...(attempts.length ? { usageAttempts: attempts } : {}) });
    return overshot ? null : used;
  }
  const attempts: UsageAttempt[] = [...(answer.priorUsage ?? []),
    { providerId: answer.providerId, usage: answer.usage, failed: false }];
  const totalOutput = attempts.reduce((sum, attempt) => sum + attempt.usage.output_tokens, 0);
  lease.settle(totalOutput);
  if (budget.snapshot().overshoot > 0) {
    await postSummaryAnswer($, job, route, { error: "spend cap", usageAttempts: attempts });
    return null;
  }
  if (!answer.text) {
    await postSummaryAnswer($, job, route, { error: "empty summary", usageAttempts: [
      ...(answer.priorUsage ?? []), { providerId: answer.providerId, usage: answer.usage, failed: true },
    ] });
    return totalOutput;
  }
  const { priorUsage, ...body } = answer;
  await postSummaryAnswer($, job, route, priorUsage ? { ...body, usageAttempts: priorUsage } : body);
  return totalOutput;
}
function failedSummaryAccounting(error: unknown): { attempts: UsageAttempt[]; used: number; unknown: boolean } {
  const failure = error as SummaryFailure;
  const attempts = failure?.usageAttempts ?? [];
  const known = attempts.filter(attempt => Number.isSafeInteger(attempt.usage.output_tokens) && attempt.usage.output_tokens >= 0);
  return { attempts, used: known.reduce((sum, attempt) => sum + attempt.usage.output_tokens, 0),
    unknown: Boolean(failure?.usageUnknown) || attempts.length === 0 || known.length !== attempts.length };
}

/** One request at a time also serializes jobs from concurrent daemon compactions. */
type ServingConfig = { cap: number; worker: boolean; workerModel?: WorkerModel };
async function workerDeclared($: EngineInterface): Promise<boolean> {
  try { return await $.env.get("LCM_SUMMARIZE_WORKER") === "1"; }
  catch { return false; }
}
async function summaryServingConfig($: EngineInterface, configuredCap: number): Promise<ServingConfig | null> {
  const worker = await workerDeclared($);
  if (!worker) return { cap: configuredCap, worker };
  const model = await $.env.get("LCM_SUMMARIZE_WORKER_MODEL") ?? "haiku";
  if (model !== "haiku" && model !== "sonnet") {
    $.ui.log("[lcm] worker model must be haiku or sonnet; worker stopped"); return null;
  }
  const setting = await $.env.get("LCM_SUMMARIZE_WORKER_MAX_OUTPUT_TOKENS");
  const cap = setting === undefined ? configuredCap : Number(setting);
  if (!Number.isSafeInteger(cap) || cap < 0) {
    $.ui.log("[lcm] worker output cap must be a non-negative integer; worker stopped"); return null;
  }
  return { cap, worker, workerModel: model };
}
async function pollSummaries($: EngineInterface, configuredCap: number): Promise<void> {
  const config = await summaryServingConfig($, configuredCap);
  if (!config || config.cap === 0) return;
  let shortPoll = false;
  while (true) {
    if (shortPoll) await summaryDelay($, SHORT_POLL_PAUSE_MS);
    const sessionId = await $.session.id();
    const outcome = await nextSummaryJob($, sessionId, shortPoll, config.worker);
    if ("wait" in outcome) {
      shortPoll = outcome.shortPoll ?? shortPoll;
      await waitSummaryPoll($, outcome.wait); continue;
    }
    if (!await continueSummaryServing($, outcome.job, { sessionId, config })) return;
  }
}
async function continueSummaryServing($: EngineInterface, job: SummaryJob, { sessionId, config }: { sessionId: string; config: ServingConfig }): Promise<boolean> {
  const budget = sharedSessionOutputBudget(sessionId, config.cap);
  const spent = await serveSummaryJob($, job, budget, config.workerModel);
  return spent !== null && (!config.worker || budget.snapshot().available > 0);
}
async function waitSummaryPoll($: EngineInterface, delay: number): Promise<void> {
  if (delay > 0) await summaryDelay($, delay);
}

type On = Parameters<Register>[0];

function startSummaryPoller($: EngineInterface, summaryCap: number): void {
  if (summaryPollerStarted) return;
  summaryPollerStarted = true;
  void pollSummaries($, summaryCap).catch((error) => {
    $.ui.log(`[lcm] session summarizer stopped: ${String(error)}`);
  });
}

/** Keep checking late command-hook registration without holding session.start open. */
async function retryWorkerEnrollment($: EngineInterface, sessionId: string, cwd: string, summaryCap: number): Promise<void> {
  while (!summaryPollerStarted) {
    await summaryDelay($, POLL_BACKOFF_MS);
    if (await $.session.id() !== sessionId) return;
    const enrollment = await postDaemon($, "/worker-session", {
      session_id: sessionId, cwd, client: "claude", declared: true, action: "check",
    }).catch(() => null);
    if (enrollment?.enrolled === true && typeof enrollment.warning === "string") {
      $.ui.log(`[lcm] ${enrollment.warning}`);
      startSummaryPoller($, summaryCap);
      return;
    }
    $.ui.log(`[lcm] worker mode refused: ${enrollment?.reason ?? "command-hook enrollment could not be confirmed"}; retrying`);
  }
}

/** Read the daemon's address and make sure it is listening before the first prompt. */
async function awaitWorkerEnrollment($: EngineInterface, sessionId: string, cwd: string): Promise<Record<string, unknown> | null> {
  let enrollment: Record<string, unknown> | null = null;
  let waited = 0, delay = 250;
  do {
    enrollment = await postDaemon($, "/worker-session", { session_id: sessionId, cwd, client: "claude", declared: true, action: "check" }).catch(() => null);
    if (workerConfirmed(enrollment) || waited >= 30_000) break;
    const pause = Math.min(delay, 30_000 - waited);
    await summaryDelay($, pause); waited += pause; delay = Math.min(delay * 2, 2_000);
  } while (true);
  return enrollment;
}
function workerConfirmed(enrollment: Record<string, unknown> | null): boolean {
  return enrollment?.enrolled === true && typeof enrollment.warning === "string";
}
async function startupWorker($: EngineInterface, sessionId: string, summaryCap: number): Promise<boolean> {
  if (!await workerDeclared($)) return true;
  const cwd = await $.session.cwd(), enrollment = await awaitWorkerEnrollment($, sessionId, cwd);
  if (workerConfirmed(enrollment)) { $.ui.log(`[lcm] ${enrollment!.warning}`); return true; }
  $.ui.log(`[lcm] worker mode refused: ${enrollment?.reason ?? "command-hook enrollment could not be confirmed"}; retrying`);
  void retryWorkerEnrollment($, sessionId, cwd, summaryCap).catch(error => { $.ui.log(`[lcm] worker enrollment retry stopped: ${String(error)}`); });
  return false;
}
function probeSessionDaemon($: EngineInterface): void {
  void readHostEnv($).then(({ port }) => {
    const startedAt = Date.now();
    return fetchDaemon($, `http://127.0.0.1:${port}/health`, undefined, HEALTH_PROBE_TIMEOUT_MS).then(() => undefined,
      async (error: unknown) => {
        if (isDaemonUnreachableError(error, startedAt)) await startDaemon($);
        else reportBusyDaemon($);
      });
  });
}
function registerSessionStart(on: On, summaryCap: number): void {
  on("session.start", async ($, e, next) => {
    const sessionId = await $.session.id();
    const mayServe = await startupWorker($, sessionId, summaryCap);
    await claimSession($, sessionId, "session.start");
    await flushHookObservations($, sessionId);
    probeSessionDaemon($);
    // The housekeeping the SessionStart command hook awaited. Nothing reads its result,
    // and the session has no reason to wait for a prune.
    void $.session.cwd().then(cwd => postDaemon($, "/session-scavenge", { cwd }));
    // Catch-up sweep for conversations of the same project a prior session left
    // uncompacted (it ended without SessionEnd). The daemon selects, caps and
    // fires the actual compaction requests; this call only triggers it.
    void $.session.cwd().then(cwd => postDaemon($, "/session-start-compact", { cwd, session_id: sessionId }));
    if (mayServe) startSummaryPoller($, summaryCap);
    return next(e);
  });
}

type RestoreResponse = {
  context?: string;
  insights?: { content: string; confidence?: number; tags: string[] }[];
};

/** The text the SessionStart command hook printed: the daemon's context, plus its insights. */
function restoreBlockText(body: Record<string, unknown> | null): string {
  const result = (body ?? {}) as RestoreResponse;
  const context = result.context ?? "";
  const insights = result.insights ?? [];
  if (insights.length === 0) return context;
  const seen = new Set<string>();
  const lines = insights.filter((i) => !seen.has(i.content) && seen.add(i.content))
    .map((i) => `- ${i.content}${typeof i.confidence === "number" ? ` (confidence: ${i.confidence})` : ""}`).join("\n");
  return `${context}\n<learned-insights source="passive-capture">\n`
    + `Recent learnings from your previous sessions:\n${lines}\n</learned-insights>`;
}

/**
 * `prompt.context` replaces the SessionStart command hook's stdout. It fires once per
 * conversation and again after compaction and `/clear` — the three moments the command
 * hook ran — but carries no reason for firing, so the daemon decides which content to
 * return from the mark `/compact` left for this session.
 */
function registerRestoreContext(on: On): void {
  on("prompt.context", async ($, e, next) => {
    const { blocks } = await next(e);
    const [session_id, cwd] = await Promise.all([$.session.id(), $.session.cwd()]);
    const outcome = await postDaemonOutcome($, "/restore", { session_id, cwd });
    const restored = outcome.body;
    const text = restoreBlockText(restored);
    noteHook(session_id, "prompt.context", "restore", "delivery", ...delivery(outcome));
    if (restored) noteHook(session_id, "prompt.context", "restore", "execution", "completed",
      text.trim() ? "context" : "no-context");
    if (!text.trim()) return { blocks };
    return { blocks: [...blocks, { name: "lcm", text }] };
  });
}

/**
 * The learning instruction goes into the system prompt once, cached for the session,
 * instead of riding on every prompt as the command hook's stdout did.
 */
function registerLearningInstruction(on: On): void {
  on("prompt.section", { name: "memory" }, async ($, e, next) => {
    const section = await next(e);
    noteHook(await $.session.id(), "prompt.section", "instruction", "execution", "completed");
    return { text: `${section.text ?? ""}\n\n${LEARNING_INSTRUCTION}` };
  });
}

/** Memory hits ride as hidden context on the prompt; the user never sees them. */
function registerPromptSearch(on: On): void {
  on("prompt.submit", async ($, e, next) => {
    if (!e.text.trim()) {
      noteHook(await $.session.id(), "prompt.submit", "search", "execution", "skipped", "empty-prompt");
      return next(e);
    }
    const [result, search] = await Promise.all([
      next(e),
      Promise.all([$.session.id(), $.session.cwd()]).then(([session_id, cwd]) =>
        postDaemonOutcome($, "/prompt-search", {
          query: e.text, cwd, session_id,
          learningInstructionBytes: 0, // the instruction lives in prompt.section now, not in this budget
          recordEvents: true,
          format: "context",
        })),
    ]);
    const sessionId = await $.session.id();
    noteHook(sessionId, "prompt.submit", "search", "delivery", ...delivery(search));
    if (search.body) noteHook(sessionId, "prompt.submit", "search", "execution", "completed",
      typeof search.body.context === "string" ? "context" : "no-context");
    if (result.drop !== undefined) return result;
    const context = typeof search.body?.context === "string" ? search.body.context : null;
    if (!context) return result;
    return { ...result, context: [...(result.context ?? []), context] };
  });
}

/**
 * The session's transcript is ingested incrementally as turns end, so memory does not wait
 * for SessionEnd. The daemon derives the transcript path from session id and cwd.
 */
function registerTurnIngest(on: On): void {
  on("turn.complete", async ($, e, next) => {
    const result = await next(e);
    const session_id = await $.session.id();
    const now = Date.now();
    if (now - lastIngestAt < INGEST_INTERVAL_MS) {
      noteHook(session_id, "turn.complete", "capture", "execution", "deferred", "throttled");
      await flushHookObservations($, session_id);
      return result;
    }
    lastIngestAt = now;
    const cwd = await $.session.cwd();
    const captured = await postDaemonOutcome($, "/ingest", { session_id, cwd });
    noteHook(session_id, "turn.complete", "capture", "delivery", ...delivery(captured));
    if (captured.body) noteHook(session_id, "turn.complete", "capture", "execution", "completed");
    const promoted = await postDaemonOutcome($, "/promote-events", { cwd });
    noteHook(session_id, "turn.complete", "promote-events", "delivery", ...delivery(promoted));
    await flushHookObservations($, session_id);
    return result;
  });
}

/** The same body the PostToolUse command hook reads on stdin, so both paths write one row shape. */
function toolEventPayload(
  event: Record<string, unknown>, result: { isError?: boolean; result?: unknown; text?: string },
  session_id: string, cwd: string,
): Record<string, unknown> {
  const { tool, tool_use_id, ...tool_input } = event as { tool: string; tool_use_id: string } & Record<string, unknown>;
  const failed = result.isError === true;
  return {
    session_id, cwd, tool_use_id, harness: "claude-function",
    tool_name: tool,
    tool_input,
    tool_response: result.result,
    tool_output: failed ? { isError: true } : undefined,
    hook_event_name: failed ? "PostToolUseFailure" : "PostToolUse",
    error: failed ? result.text : undefined,
  };
}

/** One hook replaces both PostToolUse and PostToolUseFailure; the daemon writes the rows. */
function registerToolCapture(on: On): void {
  on("tool.call", async ($, e, next) => {
    const captured = CAPTURED_TOOLS.has(e.tool) || e.tool.startsWith("mcp__");
    if (!captured) {
      const result = await next(e);
      noteHook(await $.session.id(), "tool.call", "tool-capture", "execution", "skipped", "unmatched-tool");
      return result;
    }

    const result = await next(e);
    if (result.deny !== undefined) {
      noteHook(await $.session.id(), "tool.call", "tool-capture", "execution", "skipped", "denied");
      return result;
    }

    const [session_id, cwd] = await Promise.all([$.session.id(), $.session.cwd()]);
    const recorded = await postDaemonOutcome($, "/tool-event", toolEventPayload(e, result, session_id, cwd));
    noteHook(session_id, "tool.call", "tool-capture", "delivery", ...delivery(recorded));
    if (recorded.body) noteHook(session_id, "tool.call", "tool-capture", "execution", "completed",
      typeof recorded.body.recorded === "number" && recorded.body.recorded > 0 ? "events" : "no-match");
    return result;
  });
}

export const register: Register = (on, options) => {
  const summaryCap = normalizedSummaryCap(options.sessionSummarizerMaxOutputTokens);
  const shadow = options.compactionShadow === true ? shadowSessions : undefined;
  registerSessionStart(on, summaryCap);
  registerSessionClaim(on, shadow);
  registerSessionEnd(on, shadow);
  registerRestoreContext(on);
  registerLearningInstruction(on);
  registerPromptSearch(on);
  registerTurnIngest(on);
  registerToolCapture(on);
  if (options.compactionShadow === true) registerCompactionShadow(on, summaryCap);
};
const shadowSessions = new ShadowSessionState();
function shadowTransport($: EngineInterface): ShadowTransport {
  return { post: (route, body, deadline) => postShadow($, { route, body }, deadline), observe: (status, reason, sessionId) => noteHook(sessionId ?? "unknown", "session.compact", "shadow", "execution", status, reason) };
}
async function postShadow($: EngineInterface, { route, body }: { route: string; body: unknown }, deadline?: ShadowDeadline): Promise<PostOutcome> {
  if (!deadline) return postDaemonOutcome($, route, body);
  deadline.check();
  const { port, token } = await readHostEnv($);
  deadline.check();
  const response = await $.http.fetch(`http://127.0.0.1:${port}${route}`, {
    method: "POST", headers: { "content-type": "application/json", ...(token ? { authorization: `Bearer ${token}` } : {}) }, body: JSON.stringify(body),
  });
  deadline.check();
  return { body: response.ok ? JSON.parse(response.text) as Record<string, unknown> : null, connectionFailed: false, httpStatus: response.status };
}
function shadowEngine($: EngineInterface): ShadowEngine {
  return { clock: { after: (ms, callback) => $.clock.after(ms, callback) }, env: { get: () => $.env.get("LCM_SUMMARIZE_WORKER") }, session: { id: () => $.session.id(), cwd: () => $.session.cwd(), model: () => $.session.model() },
    model: { fork: request => $.model.fork(request), complete: (request, options) => $.model.complete(request, options) } };
}
function registerCompactionShadow(on: On, cap: number): void {
  on("session.append", async ($, event, next) => {
    let sessionId: string;
    try { sessionId = await $.session.id(); }
    catch { noteHook("unknown", "session.append", "shadow", "execution", "unavailable", "identity"); return next(event); }
    const owner = event.agentId === undefined ? shadowSessions.beginAppend(sessionId, event.door) : undefined;
    const result = await next(event);
    settledShadowAppend(owner, result);
    return result;
  });
  on("session.compact", async ($, event, next) => {
    return runCompactionShadow(shadowEngine($), { event, next, state: shadowSessions, cap, signal: next.signal }, shadowTransport($));
  });
}
function settledShadowAppend(owner: ShadowAppend | undefined, result: import("claude-code").EventResult<"session.append">): void {
  if (!owner || result.deny !== undefined) return;
  if (result.message.role === undefined) return;
  const text = result.message.content.filter(block => block.type === "text").map(block => block.text).join("\n");
  shadowSessions.storedAppend(owner, { uuid: result.uuid, text });
}
function normalizedSummaryCap(value: unknown): number {
  if (typeof value !== "number" || !Number.isFinite(value)) return DEFAULT_SUMMARY_OUTPUT_CAP;
  return Math.min(Number.MAX_SAFE_INTEGER, Math.max(0, Math.floor(value)));
}
