import {
  existsSync as realExistsSync,
  readFileSync as realReadFileSync,
} from "node:fs";
import { spawnSync as realSpawnSync, type SpawnSyncReturns } from "node:child_process";
import type { ServiceDeps } from "./install.js";
import type { TeardownDeps } from "./uninstall.js";

const fakeZeroExit = (): SpawnSyncReturns<string> => ({
  status: 0,
  stdout: "",
  stderr: "",
  pid: 0,
  output: [],
  signal: null,
  error: undefined,
});

export class DryRunServiceDeps implements ServiceDeps, TeardownDeps {
  // ── intercepted ───────────────────────────────────────────────────────────

  writeFileSync(path: string, _data: string): void {
    console.log(`[dry-run] would write: ${path}`);
  }

  mkdirSync(path: string, _opts?: any): void {
    if (!realExistsSync(path)) {
      console.log(`[dry-run] would create: ${path}`);
    }
  }

  rmSync(path: string, _opts?: any): void {
    console.log(`[dry-run] would remove: ${path}`);
  }

  spawnSync(cmd: string, args: string[], opts?: any): SpawnSyncReturns<string> {
    // Special case 1: setup.sh — actually run it with XGH_DRY_RUN=1 so it prints its own preview.
    // Use stdio:"pipe" (not inherited) so we can capture stdout and forward it ourselves,
    // enabling both user-visible output and testable result.stdout.
    if (cmd === "bash" && typeof args[0] === "string" && args[0].endsWith("setup.sh")) {
      const env = { ...(opts?.env ?? process.env), XGH_DRY_RUN: "1" };
      const result = realSpawnSync(cmd, args, { encoding: "utf-8", env, stdio: "pipe" }) as SpawnSyncReturns<string>;
      if (result.stdout) process.stdout.write(result.stdout);
      if (result.stderr) process.stderr.write(result.stderr);
      return result;
    }

    // Model every PATH probe as installed, including the OMP harness. Returning
    // the probed name keeps dry-run output honest while preserving success.
    if (cmd === "sh" && args[0] === "-c" && typeof args[1] === "string" && args[1].startsWith("command -v")) {
      const binary = args[1].trim().split(/\s+/).at(-1) ?? "lcm";
      return { ...fakeZeroExit(), stdout: binary };
    }

    // All other commands: print and fake
    console.log(`[dry-run] would run: ${cmd} ${args.join(" ")}`);
    return fakeZeroExit();
  }

  async promptUser(question: string): Promise<string> {
    console.log(`[dry-run] would prompt: ${question}`);
    return "";
  }

  async ensureDaemon(_opts: { port: number; pidFilePath: string; spawnTimeoutMs: number }): Promise<{ connected: boolean }> {
    console.log(`[dry-run] would start daemon on port ${_opts.port}`);
    return { connected: true };
  }

  async runDoctor(): Promise<{ name: string; status: string }[]> {
    console.log(`[dry-run] would run doctor checks`);
    return [];
  }

  // ── pass-through ──────────────────────────────────────────────────────────

  readFileSync(path: string, encoding: string): string {
    return realReadFileSync(path, encoding as BufferEncoding) as string;
  }

  existsSync(path: string): boolean {
    return realExistsSync(path);
  }
}
