import { describe, it, expect, beforeEach, afterEach, vi } from "vitest";
import { mkdtempSync, rmSync } from "node:fs";
import { join } from "node:path";
import { tmpdir } from "node:os";
import { EventsDb } from "../../../src/hooks/events-db.js";
import { createToolEventHandler } from "../../../src/daemon/routes/tool-event.js";
import type { DaemonConfig } from "../../../src/daemon/config.js";
import { createLcmPaths, type LcmPaths } from "../../../src/lcm-paths.js";
import { eventsDbPath } from "../../../src/db/events-path.js";

const promoteEvents = vi.fn().mockResolvedValue(undefined);
vi.mock("../../../src/daemon/routes/promote-events.js", () => ({
  createPromoteEventsHandler: () => promoteEvents,
}));

function respond() {
  const out = { status: 0, body: {} as Record<string, unknown> };
  const res = {
    writeHead: (status: number) => { out.status = status; },
    end: (body: string) => { out.body = JSON.parse(body); },
  } as unknown as Parameters<ReturnType<typeof createToolEventHandler>>[1];
  return { res, out };
}

describe("POST /tool-event", () => {
  let dir: string;
  let paths: LcmPaths;
  let handler: ReturnType<typeof createToolEventHandler>;

  beforeEach(() => {
    dir = mkdtempSync(join(tmpdir(), "tool-event-"));
    // The functions read only `paths.eventsDir`; pointing it straight at the temp
    // dir avoids also creating the sibling `events/` directory a real home would have.
    paths = { ...createLcmPaths(dir), eventsDir: dir };
    handler = createToolEventHandler({} as DaemonConfig, paths);
    promoteEvents.mockClear();
  });

  afterEach(() => {
    rmSync(dir, { recursive: true, force: true });
  });

  it("rejects a body without session_id, tool_name or cwd", async () => {
    const { res, out } = respond();
    await handler({} as never, res, JSON.stringify({ tool_name: "Bash", cwd: dir }));
    expect(out.status).toBe(400);
  });

  it("answers 400 on a malformed JSON body instead of throwing", async () => {
    const { res, out } = respond();
    await handler({} as never, res, "{not json");
    expect(out.status).toBe(400);
  });

  it("rejects a non-string session_id", async () => {
    const { res, out } = respond();
    await handler({} as never, res, JSON.stringify({ session_id: 42, tool_name: "Bash", cwd: dir }));
    expect(out.status).toBe(400);
  });

  it("rejects a non-string cwd", async () => {
    const { res, out } = respond();
    await handler({} as never, res, JSON.stringify({ session_id: "s1", tool_name: "Bash", cwd: { path: dir } }));
    expect(out.status).toBe(400);
  });

  it("writes the same event row the PostToolUse command hook writes", async () => {
    const { res, out } = respond();
    await handler({} as never, res, JSON.stringify({
      session_id: "s1", cwd: dir, tool_name: "Read", tool_input: { file_path: "/repo/src/a.ts" },
    }));
    expect(out.status).toBe(200);
    expect(out.body).toEqual({ recorded: 1, promoted: false });

    const db = new EventsDb(eventsDbPath(dir, paths));
    const rows = db.getUnprocessed();
    db.close();
    expect(rows).toHaveLength(1);
    expect(rows[0]).toMatchObject({ session_id: "s1", type: "file_read", source_hook: "PostToolUse" });
    expect(promoteEvents).not.toHaveBeenCalled();
  });

  it.each([
    ["object", { id: "turn-1" }],
    ["empty", ""],
  ])("drops a %s turn_id while preserving the structured response", async (_kind, turn_id) => {
    const { res, out } = respond();
    await handler({} as never, res, JSON.stringify({
      session_id: `s-${_kind}`, cwd: dir, tool_name: "Read", tool_input: { file_path: "/repo/src/a.ts" }, turn_id,
    }));
    expect(out.status).toBe(200);
    expect(out.body).toEqual({ recorded: 1, promoted: false });

    const db = new EventsDb(eventsDbPath(dir, paths));
    const [row] = db.getUnprocessed();
    db.close();
    expect(row).toMatchObject({ session_id: `s-${_kind}`, turn_id: null });
  });

  it("persists a non-empty turn_id from the shared route payload", async () => {
    const { res, out } = respond();
    await handler({} as never, res, JSON.stringify({
      session_id: "s-turn", cwd: dir, tool_name: "Read", tool_input: { file_path: "/repo/src/a.ts" }, turn_id: "turn-1",
    }));
    expect(out.body).toEqual({ recorded: 1, promoted: false });

    const db = new EventsDb(eventsDbPath(dir, paths));
    const [row] = db.getUnprocessed();
    db.close();
    expect(row).toMatchObject({ session_id: "s-turn", turn_id: "turn-1" });
  });

  it("labels a failed call PostToolUseFailure and promotes it at once", async () => {
    const { res, out } = respond();
    await handler({} as never, res, JSON.stringify({
      session_id: "s1", cwd: dir, tool_name: "Bash", tool_input: { command: "npm test" },
      hook_event_name: "PostToolUseFailure", error: "Exit code 1\nfailing test", tool_output: { isError: true },
    }));
    expect(out.body).toEqual({ recorded: 1, promoted: true });

    const db = new EventsDb(eventsDbPath(dir, paths));
    const [row] = db.getUnprocessed();
    db.close();
    expect(row).toMatchObject({ type: "error_tool", priority: 1, source_hook: "PostToolUseFailure" });
    await vi.waitFor(() => expect(promoteEvents).toHaveBeenCalledTimes(1));
    expect(JSON.parse(promoteEvents.mock.calls[0][2])).toMatchObject({ cwd: expect.stringContaining("tool-event-"), skip_tool_lessons: true });
  });
});
