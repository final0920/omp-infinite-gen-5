import { appendFileSync, mkdirSync, mkdtempSync, rmSync, utimesSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { DatabaseSync } from "node:sqlite";
import { afterEach, describe, expect, it } from "vitest";
import { createDaemon, type DaemonInstance } from "../../../src/daemon/server.js";
import { createIngestHandler } from "../../../src/daemon/routes/ingest.js";
import { invokeRoute } from "../../../src/daemon/routes/session-end.js";
import { loadDaemonConfig } from "../../../src/daemon/config.js";
import { DaemonClient } from "../../../src/daemon/client.js";
import { projectDbPath, projectId } from "../../../src/daemon/project.js";
import { lcmHome } from "../../../src/lcm-home.js";
import { createLcmPaths } from "../../../src/lcm-paths.js";

const paths = createLcmPaths(lcmHome());
import { enqueue } from "../../../src/daemon/project-queue.js";
import { importSessions } from "../../../src/import.js";
import { EventsDb } from "../../../src/hooks/events-db.js";
import { eventsDbPath } from "../../../src/db/events-path.js";
import { dispatchCodexHook, type CodexHookDeps } from "../../../src/hooks/codex.js";

const tempDirs: string[] = [];

describe("POST /ingest", () => {
  let daemon: DaemonInstance | undefined;

  afterEach(async () => {
    if (daemon) {
      await daemon.stop();
      daemon = undefined;
    }
    for (const dir of tempDirs.splice(0)) {
      rmSync(dir, { recursive: true, force: true });
    }
  });

  it("parses Codex rollout responses server-side and rejects a mismatched project", async () => {
    // The mismatch check needs a cwd that contains the transcript but is not the cwd the
    // transcript records, so the project is this test's own directory inside a parent of
    // its own. Posting the shared tmpdir() would work too, but every test that does that
    // lands on one project database, and two writing it at once answer SQLITE_BUSY.
    const parentDir = mkdtempSync(join(tmpdir(), "lossless-ingest-parent-"));
    tempDirs.push(parentDir);
    const tempDir = mkdtempSync(join(parentDir, "codex-"));
    tempDirs.push(tempDir);
    const path = join(tempDir, "rollout-2026-09-07-different-filename.jsonl");
    writeFileSync(path, [
      { type: "session_meta", payload: { id: "codex-meta-id", cwd: tempDir } },
      { type: "event_msg", payload: { type: "user_message", message: "duplicate notification" } },
      { type: "response_item", payload: { type: "message", role: "user", content: [{ type: "input_text", text: "hello" }] } },
      { type: "response_item", payload: { type: "message", role: "assistant", content: [{ type: "output_text", text: "hi" }] } },
    ].map(line => JSON.stringify(line)).join("\n") + "\n");
    daemon = await createDaemon(loadDaemonConfig("/nonexistent", { daemon: { port: 0 } }));
    const post = (cwd: string, sessionId = "codex-meta-id", transcriptPath = path) => fetch(`http://127.0.0.1:${daemon!.address().port}/ingest`, {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ session_id: sessionId, cwd, client: "codex", transcript_path: transcriptPath }),
    });
    const wrong = await post(parentDir);
    // Name the body on failure: a 500 here is otherwise an opaque status with the cause
    // stranded in the daemon's reply.
    expect(wrong.status, await wrong.clone().text()).toBe(400);
    expect(await wrong.json()).toEqual({ error: "Codex transcript cwd does not match requested project" });
    const wrongSession = await post(tempDir, "different-session-id");
    expect(wrongSession.status).toBe(400);
    expect(await wrongSession.json()).toEqual({ error: "Codex transcript session id does not match request" });
    const missing = await post(tempDir, "codex-meta-id", join(tempDir, "missing.jsonl"));
    expect(missing.status).toBe(400);
    expect(await missing.json()).toEqual({ error: "Codex transcript is unreadable" });
    const outsideDir = mkdtempSync(join(tmpdir(), "lossless-ingest-codex-outside-"));
    tempDirs.push(outsideDir);
    const outsidePath = join(outsideDir, "rollout.jsonl");
    writeFileSync(outsidePath, `${JSON.stringify({ type: "session_meta", payload: { id: "codex-meta-id", cwd: tempDir } })}\n`);
    const disallowed = await post(tempDir, "codex-meta-id", outsidePath);
    expect(disallowed.status).toBe(400);
    expect(await disallowed.json()).toEqual({ error: "Codex transcript path is not allowed" });
    const response = await post(tempDir);
    expect(response.status).toBe(200);
    expect(await response.json()).toEqual({ ingested: 2, totalTokens: 3 });
    const db = new DatabaseSync(projectDbPath(tempDir, paths));
    try {
      expect(db.prepare("SELECT role, content FROM messages ORDER BY seq").all().map(r => [r.role, r.content])).toEqual([["user", "hello"], ["assistant", "hi"]]);
      expect(db.prepare("SELECT session_id FROM conversations").get()?.session_id).toBe("codex-meta-id");
    } finally { db.close(); }
  });

  it("recovers a deferred Codex tail after restart and deduplicates an overlapping import", async () => {
    const tempDir = mkdtempSync(join(tmpdir(), "lossless-ingest-codex-delta-"));
    tempDirs.push(tempDir);
    const codexHome = join(tempDir, "codex-home");
    const transcriptDir = join(codexHome, "sessions", "2026", "09", "08");
    mkdirSync(transcriptDir, { recursive: true });
    const path = join(transcriptDir, "rollout-codex-delta.jsonl");
    const sessionId = "codex-delta-id";
    const meta = JSON.stringify({ type: "session_meta", payload: { id: sessionId, cwd: tempDir } });
    const message = (role: "user" | "assistant", text: string) => JSON.stringify({
      type: "response_item",
      payload: {
        type: "message",
        role,
        content: [{ type: role === "user" ? "input_text" : "output_text", text }],
      },
    });
    const first = message("user", "first complete message");
    const second = message("assistant", "tail recovered by import");
    writeFileSync(path, `${meta}\n${first}\n${second.slice(0, -8)}`);

    const startDaemon = async () => createDaemon(loadDaemonConfig("/nonexistent", { daemon: { port: 0 } }));
    daemon = await startDaemon();
    const postLive = () => fetch(`http://127.0.0.1:${daemon!.address().port}/ingest`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ session_id: sessionId, cwd: tempDir, client: "codex", transcript_path: path }),
    });

    expect(await (await postLive()).json()).toEqual({ ingested: 1, totalTokens: 6 });
    expect(await (await postLive()).json()).toEqual({ ingested: 0, totalTokens: 0 });
    const invalidImport = await fetch(`http://127.0.0.1:${daemon.address().port}/ingest`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        session_id: sessionId,
        cwd: tempDir,
        client: "codex",
        source: "import",
        transcript_path: path,
      }),
    });
    expect(invalidImport.status).toBe(400);
    const invalidOffset = Buffer.byteLength(`${meta}\n${first}\n`, "utf8");
    expect(await invalidImport.json()).toEqual({ error: `Invalid Codex transcript JSONL at byte offset ${invalidOffset}` });
    writeFileSync(path, `${meta}\n${first}\n${second.slice(0, -8)}\n`);
    const invalidLive = await postLive();
    expect(invalidLive.status).toBe(400);
    expect(await invalidLive.json()).toEqual({ error: `Invalid Codex transcript JSONL at byte offset ${invalidOffset}` });

    await daemon.stop();
    daemon = undefined;
    writeFileSync(path, `${meta}\n${first}\n${second}`);
    daemon = await startDaemon();

    // A live capture still defers the valid but non-newline-terminated tail.
    expect(await (await postLive()).json()).toEqual({ ingested: 0, totalTokens: 0 });

    const db = new DatabaseSync(projectDbPath(tempDir, paths));
    db.prepare(
      "INSERT INTO session_ingest_log (session_id, message_count) VALUES (?, ?) " +
      "ON CONFLICT(session_id) DO UPDATE SET message_count = excluded.message_count",
    ).run(sessionId, 1);
    db.close();

    const client = new DaemonClient(
      `http://127.0.0.1:${daemon.address().port}`,
      join(tempDir, "missing-daemon-token"),
    );
    const imported = await importSessions(client, {
      provider: "codex",
      cwd: tempDir,
      _codexDir: codexHome,
    });
    expect(imported.imported).toBe(1);
    expect(imported.totalMessages).toBe(1);

    const repeated = await importSessions(client, {
      provider: "codex",
      cwd: tempDir,
      _codexDir: codexHome,
    });
    expect(repeated.imported).toBe(0);
    expect(repeated.skippedEmpty).toBe(1);

    const third = message("user", "concurrent tail");
    writeFileSync(path, `${meta}\n${first}\n${second}\n${third}\n`);
    let releaseQueue!: () => void;
    let markQueueStarted!: () => void;
    const queueHold = new Promise<void>(resolve => { releaseQueue = resolve; });
    const queueStarted = new Promise<void>(resolve => { markQueueStarted = resolve; });
    const blocker = enqueue(projectId(tempDir), async () => {
      markQueueStarted();
      await queueHold;
    });
    await queueStarted;
    const concurrentPromise = Promise.all([postLive(), postLive()]);
    try {
      const state = await Promise.race([
        concurrentPromise.then(() => "settled" as const),
        new Promise<"waiting">(resolve => setTimeout(() => resolve("waiting"), 50)),
      ]);
      expect(state).toBe("waiting");
    } finally {
      releaseQueue();
      await blocker;
    }
    const concurrent = await concurrentPromise;
    const concurrentBodies = await Promise.all(concurrent.map(response => response.json()));
    expect(concurrentBodies.map(body => body.ingested).sort()).toEqual([0, 1]);
    expect(await (await postLive()).json()).toEqual({ ingested: 0, totalTokens: 0 });

    const verifyDb = new DatabaseSync(projectDbPath(tempDir, paths));
    try {
      expect(verifyDb.prepare("SELECT role, content FROM messages ORDER BY seq").all()).toEqual([
        { role: "user", content: "first complete message" },
        { role: "assistant", content: "tail recovered by import" },
        { role: "user", content: "concurrent tail" },
      ]);
    } finally {
      verifyDb.close();
    }
  });

  it("keeps filename-derived identity for legacy Codex imports without a metadata id", async () => {
    const tempDir = mkdtempSync(join(tmpdir(), "lossless-ingest-codex-legacy-"));
    tempDirs.push(tempDir);
    const codexHome = join(tempDir, "codex-home");
    const archivedDir = join(codexHome, "archived_sessions");
    mkdirSync(archivedDir, { recursive: true });
    const transcriptPath = join(archivedDir, "legacy-session.jsonl");
    writeFileSync(transcriptPath, [
      JSON.stringify({ type: "session_meta", payload: { cwd: tempDir } }),
      JSON.stringify({
        type: "response_item",
        payload: {
          type: "message",
          role: "user",
          content: [{ type: "input_text", text: "legacy imported message" }],
        },
      }),
    ].join("\n"));

    daemon = await createDaemon(loadDaemonConfig("/nonexistent", { daemon: { port: 0 } }));
    const liveResponse = await fetch(`http://127.0.0.1:${daemon.address().port}/ingest`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        session_id: "legacy-session",
        cwd: tempDir,
        client: "codex",
        transcript_path: transcriptPath,
      }),
    });
    expect(liveResponse.status).toBe(400);
    expect(await liveResponse.json()).toEqual({ error: "Codex transcript session id does not match request" });

    const client = new DaemonClient(
      `http://127.0.0.1:${daemon.address().port}`,
      join(tempDir, "missing-daemon-token"),
    );
    const result = await importSessions(client, {
      provider: "codex",
      cwd: tempDir,
      _codexDir: codexHome,
    });
    expect(result.totalMessages).toBe(1);

    const db = new DatabaseSync(projectDbPath(tempDir, paths));
    try {
      expect(db.prepare(
        "SELECT c.session_id, m.content FROM conversations c JOIN messages m ON m.conversation_id = c.conversation_id",
      ).get()).toEqual({ session_id: "legacy-session", content: "legacy imported message" });
    } finally {
      db.close();
    }
  });

  it("writes skill and command message_parts for messages carrying them", async () => {
    const tempDir = mkdtempSync(join(tmpdir(), "lossless-ingest-parts-"));
    tempDirs.push(tempDir);

    daemon = await createDaemon(loadDaemonConfig("/nonexistent", { daemon: { port: 0 } }));
    const res = await fetch(`http://127.0.0.1:${daemon.address().port}/ingest`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        session_id: "parts-test-1",
        cwd: tempDir,
        messages: [
          { role: "user", content: "roda os testes", tokenCount: 3 },
          {
            role: "user",
            content: "<command-name>/model</command-name><command-args>opus</command-args>",
            tokenCount: 4,
            parts: [{ type: "command", name: "/model", args: "opus" }],
          },
          {
            role: "tool",
            content: "Skill",
            tokenCount: 1,
            parts: [{ type: "skill", name: "grilling", args: null }],
          },
        ],
      }),
    });
    expect(res.status).toBe(200);
    expect(await res.json()).toEqual({ ingested: 3, totalTokens: 8 });

    const db = new DatabaseSync(projectDbPath(tempDir, paths));
    try {
      const parts = db
        .prepare(
          `SELECT part_type, tool_name, tool_input FROM message_parts mp
           JOIN messages m ON m.message_id = mp.message_id
           ORDER BY m.seq`,
        )
        .all();
      expect(parts).toEqual([
        { part_type: "command", tool_name: "/model", tool_input: "opus" },
        { part_type: "skill", tool_name: "grilling", tool_input: null },
      ]);
    } finally {
      db.close();
    }
  });

  it("accepts messages[] as an alternative to transcript_path", async () => {
    const tempDir = mkdtempSync(join(tmpdir(), "lossless-ingest-"));
    tempDirs.push(tempDir);

    daemon = await createDaemon(loadDaemonConfig("/nonexistent", { daemon: { port: 0 } }));
    const res = await fetch(`http://127.0.0.1:${daemon.address().port}/ingest`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        session_id: "codex-test-1",
        cwd: tempDir,
        messages: [
          { role: "user", content: "hello", tokenCount: 1 },
          { role: "assistant", content: "hi", tokenCount: 1 },
        ],
      }),
    });

    expect(res.status).toBe(200);
    expect(await res.json()).toEqual({ ingested: 2, totalTokens: 2 });
    const db = new DatabaseSync(projectDbPath(tempDir, paths));
    try {
      expect(db.prepare("SELECT parser_shape FROM conversations WHERE session_id = ?").get("codex-test-1"))
        .toEqual({ parser_shape: "structured" });
    } finally {
      db.close();
    }
  });

  it("accepts tool messages in structured ingestion mode", async () => {
    const tempDir = mkdtempSync(join(tmpdir(), "lossless-ingest-tool-"));
    tempDirs.push(tempDir);

    daemon = await createDaemon(loadDaemonConfig("/nonexistent", { daemon: { port: 0 } }));
    const res = await fetch(`http://127.0.0.1:${daemon.address().port}/ingest`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        session_id: "codex-test-tool",
        cwd: tempDir,
        messages: [
          { role: "user", content: "run rg", tokenCount: 2 },
          { role: "assistant", content: "Tool call shell: rg --files", tokenCount: 6 },
          { role: "tool", content: "README.md", tokenCount: 2 },
          { role: "assistant", content: "Done", tokenCount: 1 },
        ],
      }),
    });

    expect(res.status).toBe(200);
    expect(await res.json()).toEqual({ ingested: 4, totalTokens: 11 });
  });

  it("prefers messages[] over transcript_path when both are present", async () => {
    const tempDir = mkdtempSync(join(tmpdir(), "lossless-ingest-both-"));
    tempDirs.push(tempDir);

    daemon = await createDaemon(loadDaemonConfig("/nonexistent", { daemon: { port: 0 } }));
    const res = await fetch(`http://127.0.0.1:${daemon.address().port}/ingest`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        session_id: "codex-test-2",
        cwd: tempDir,
        transcript_path: "/definitely/missing.jsonl",
        messages: [
          { role: "user", content: "preferred", tokenCount: 2 },
          { role: "assistant", content: "path", tokenCount: 1 },
        ],
      }),
    });

    expect(res.status).toBe(200);
    expect(await res.json()).toEqual({ ingested: 2, totalTokens: 3 });
  });

  it("scrubs secrets from message content before SQLite write", async () => {
    const tempDir = mkdtempSync(join(tmpdir(), "lossless-ingest-scrub-"));
    tempDirs.push(tempDir);

    daemon = await createDaemon(
      loadDaemonConfig("/nonexistent", {
        daemon: { port: 0 },
        security: { sensitivePatterns: ["MY_PROJECT_SECRET"] },
      }),
    );
    const res = await fetch(`http://127.0.0.1:${daemon.address().port}/ingest`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        session_id: "scrub-test-1",
        cwd: tempDir,
        messages: [
          { role: "user", content: "token=MY_PROJECT_SECRET", tokenCount: 5 },
        ],
      }),
    });

    expect(res.status).toBe(200);

    // Verify the stored content was scrubbed
    const db = new DatabaseSync(projectDbPath(tempDir, paths));
    let row: { content: string } | undefined;
    try {
      row = db.prepare("SELECT content FROM messages LIMIT 1").get() as { content: string } | undefined;
    } finally {
      db.close();
    }
    expect(row?.content).toContain("[REDACTED]");
    expect(row?.content).not.toContain("MY_PROJECT_SECRET");
  });

  it("increments redaction_stats per category when content contains secrets", async () => {
    const tempDir = mkdtempSync(join(tmpdir(), "lossless-ingest-redact-stats-"));
    tempDirs.push(tempDir);

    daemon = await createDaemon(
      loadDaemonConfig("/nonexistent", {
        daemon: { port: 0 },
        security: { sensitivePatterns: ["MY_GLOBAL_TOKEN"] },
      }),
    );
    const res = await fetch(`http://127.0.0.1:${daemon.address().port}/ingest`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        session_id: "redact-stats-1",
        cwd: tempDir,
        messages: [
          {
            role: "user",
            // ghp_ + 36 alphanumeric chars → matches built-in GitHub token pattern
            // MY_GLOBAL_TOKEN → matches the global pattern above
            content: "token ghp_AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA and MY_GLOBAL_TOKEN",
            tokenCount: 10,
          },
        ],
      }),
    });

    expect(res.status).toBe(200);

    const db = new DatabaseSync(projectDbPath(tempDir, paths));
    try {
      const rows = db.prepare(
        "SELECT category, count FROM redaction_stats ORDER BY category"
      ).all() as Array<{ category: string; count: number }>;
      const byCategory = Object.fromEntries(rows.map((r) => [r.category, r.count]));
      // ghp_ token is matched by gitleaks github-pat pattern (gitleaks takes priority over native)
      expect(byCategory["gitleaks"]).toBeGreaterThan(0);
      expect(byCategory["global"]).toBeGreaterThan(0);
    } finally {
      db.close();
    }
  });

  it("replay ingests the transcript tail of a session already in session_ingest_log", async () => {
    const tempDir = mkdtempSync(join(tmpdir(), "lossless-ingest-"));
    tempDirs.push(tempDir);
    daemon = await createDaemon(loadDaemonConfig("/nonexistent", { daemon: { port: 0 } }));
    const url = `http://127.0.0.1:${daemon.address().port}/ingest`;
    const post = (body: Record<string, unknown>) =>
      fetch(url, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
    const first = [{ role: "user", content: "hello", tokenCount: 1 }];
    const grown = [...first, { role: "assistant", content: "hi", tokenCount: 1 }];

    await post({ session_id: "done-sess", cwd: tempDir, messages: first });
    const db = new DatabaseSync(projectDbPath(tempDir, paths));
    db.prepare("INSERT INTO session_ingest_log (session_id, message_count) VALUES ('done-sess', 1)").run();
    db.close();

    // The ordinary path trusts the completion log and skips the grown transcript.
    expect(await (await post({ session_id: "done-sess", cwd: tempDir, messages: grown })).json()).toEqual({ ingested: 0, totalTokens: 0 });
    // A replay re-reads it and ingests only the tail.
    expect(await (await post({ session_id: "done-sess", cwd: tempDir, messages: grown, replay: true })).json()).toEqual({ ingested: 1, totalTokens: 2 });
    // Idempotent: nothing new on the next replay pass.
    expect(await (await post({ session_id: "done-sess", cwd: tempDir, messages: grown, replay: true })).json()).toEqual({ ingested: 0, totalTokens: 0 });
  });

  it("captures the turns a resumed session appends to a completed Claude transcript", async () => {
    const tempDir = mkdtempSync(join(tmpdir(), "lossless-ingest-resume-"));
    tempDirs.push(tempDir);
    daemon = await createDaemon(loadDaemonConfig("/nonexistent", { daemon: { port: 0 } }));
    const base = `http://127.0.0.1:${daemon.address().port}`;
    const post = async (route: string, body: Record<string, unknown>) =>
      (await fetch(`${base}${route}`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) })).json();
    const transcriptPath = join(tempDir, "resumed-sess.jsonl");
    const line = (role: string, content: string) => JSON.stringify({ message: { role, content } }) + "\n";
    const ingest = () => post("/ingest", { session_id: "resumed-sess", cwd: tempDir, transcript_path: transcriptPath });
    const storedContents = () => {
      const db = new DatabaseSync(projectDbPath(tempDir, paths));
      try {
        return (db.prepare("SELECT content FROM messages ORDER BY seq").all() as Array<{ content: string }>).map((r) => r.content);
      } finally {
        db.close();
      }
    };

    writeFileSync(transcriptPath, line("user", "first question") + line("assistant", "first answer"));
    const beforeCompletion = new Date(Date.now() - 60_000);
    utimesSync(transcriptPath, beforeCompletion, beforeCompletion);
    expect(await ingest()).toMatchObject({ ingested: 2 });
    expect(await post("/session-complete", { session_id: "resumed-sess", cwd: tempDir, message_count: 2 })).toEqual({ recorded: true });
    // Unchanged since it was completed: nothing to read.
    expect(await ingest()).toEqual({ ingested: 0, totalTokens: 0 });

    // A resume appends to the same file after the session was completed.
    appendFileSync(transcriptPath, line("user", "resumed question") + line("assistant", "resumed answer"));
    const afterCompletion = new Date(Date.now() + 60_000);
    utimesSync(transcriptPath, afterCompletion, afterCompletion);
    expect(await ingest()).toMatchObject({ ingested: 2 });
    // Idempotent: the resumed turns are stored once.
    expect(await ingest()).toEqual({ ingested: 0, totalTokens: 0 });
    expect(storedContents()).toEqual(["first question", "first answer", "resumed question", "resumed answer"]);
  });

  it("rejects an explicitly supplied Claude transcript path outside the project", async () => {
    const tempDir = mkdtempSync(join(tmpdir(), "lossless-ingest-missing-"));
    tempDirs.push(tempDir);

    daemon = await createDaemon(loadDaemonConfig("/nonexistent", { daemon: { port: 0 } }));
    const res = await fetch(`http://127.0.0.1:${daemon.address().port}/ingest`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        session_id: "codex-test-3",
        cwd: tempDir,
        transcript_path: "/definitely/missing.jsonl",
      }),
    });

    expect(res.status).toBe(400);
    expect(await res.json()).toEqual({ error: "Claude transcript path is not allowed" });
  });

  it("backfills the model on a Claude tool-call event whose hook payload could not carry one", async () => {
    const tempDir = mkdtempSync(join(tmpdir(), "lossless-ingest-model-backfill-"));
    tempDirs.push(tempDir);
    const transcriptPath = join(tempDir, "backfill-session.jsonl");
    writeFileSync(transcriptPath, [
      { message: { role: "user", content: "commit this" } },
      {
        message: {
          role: "assistant", model: "claude-sonnet-5",
          content: [
            { type: "text", text: "On it." },
            { type: "tool_use", id: "toolu_backfill_1", name: "Bash", input: { command: "git commit -m x" } },
          ],
        },
      },
    ].map(line => JSON.stringify(line)).join("\n") + "\n");

    const sidecar = new EventsDb(eventsDbPath(tempDir, paths));
    sidecar.insertToolCallEvents(
      "backfill-session",
      [{ type: "git_commit", category: "git", data: "git commit: x", priority: 2 }],
      "PostToolUse",
      "toolu_backfill_1",
    );
    sidecar.close();

    daemon = await createDaemon(loadDaemonConfig("/nonexistent", { daemon: { port: 0 } }));
    const res = await fetch(`http://127.0.0.1:${daemon.address().port}/ingest`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ session_id: "backfill-session", cwd: tempDir, transcript_path: transcriptPath }),
    });
    expect(res.status).toBe(200);

    // The backfill runs after the response, so poll rather than read once.
    let row;
    for (let attempt = 0; attempt < 50 && row?.model == null; attempt += 1) {
      const after = new EventsDb(eventsDbPath(tempDir, paths));
      row = after.getUnprocessed().find(r => r.tool_use_id === "toolu_backfill_1");
      after.close();
      if (row?.model == null) await new Promise(resolve => setTimeout(resolve, 10));
    }
    expect(row?.client).toBe("claude");
    expect(row?.model).toBe("claude-sonnet-5");
  });

  it("runs the post-response model backfill as a named background task", async () => {
    const tempDir = mkdtempSync(join(tmpdir(), "lossless-ingest-backfill-task-"));
    tempDirs.push(tempDir);
    const transcriptPath = join(tempDir, "backfill-task-session.jsonl");
    writeFileSync(transcriptPath, [
      { message: { role: "user", content: "hello" } },
      { message: { role: "assistant", model: "claude-sonnet-5", content: [{ type: "text", text: "hi" }] } },
    ].map(line => JSON.stringify(line)).join("\n") + "\n");
    const tasks: Array<{ name: string; ended: boolean }> = [];
    const handler = createIngestHandler(loadDaemonConfig("/nonexistent"), paths, undefined, (name) => {
      const task = { name, ended: false };
      tasks.push(task);
      return () => { task.ended = true; };
    });

    await invokeRoute(handler, { session_id: "backfill-task-session", cwd: tempDir, transcript_path: transcriptPath });
    // The response has been sent; the backfill is registered and has not run yet.
    expect(tasks).toEqual([{ name: "ingest:backfill", ended: false }]);
    await new Promise(setImmediate);
    expect(tasks).toEqual([{ name: "ingest:backfill", ended: true }]);
  });

  it("backfills model-less Codex events by their transcript turns", async () => {
    const tempDir = mkdtempSync(join(tmpdir(), "lossless-ingest-codex-model-backfill-"));
    tempDirs.push(tempDir);
    const transcriptPath = join(tempDir, "rollout.jsonl");
    const sessionId = "codex-backfill-session";
    writeFileSync(transcriptPath, [
      { type: "session_meta", payload: { id: sessionId, cwd: tempDir } },
      { type: "turn_context", payload: { turn_id: "turn-1", model: "gpt-5.6-codex" } },
      { type: "response_item", payload: { type: "message", role: "user", content: [{ type: "input_text", text: "edit it" }] } },
      { type: "response_item", payload: { type: "message", role: "assistant", content: [{ type: "output_text", text: "done" }] } },
      { type: "turn_context", payload: { turn_id: "turn-2", model: "gpt-5.6-codex-mini" } },
      { type: "response_item", payload: { type: "message", role: "user", content: [{ type: "input_text", text: "edit it again" }] } },
      { type: "response_item", payload: { type: "message", role: "assistant", content: [{ type: "output_text", text: "done again" }] } },
    ].map(line => JSON.stringify(line)).join("\n") + "\n");

    const hookDeps: CodexHookDeps = {
      client: { post: async () => ({}) }, connect: async () => true, enabled: true, paths,
    };
    for (const [tool_use_id, turn_id, file] of [
      ["call_patch", "turn-1", "src/example.ts"],
      ["call_patch_2", "turn-1", "src/second.ts"],
      ["call_patch_3", "turn-2", "src/third.ts"],
    ]) {
      await dispatchCodexHook(JSON.stringify({
        hook_event_name: "PostToolUse", session_id: sessionId, cwd: tempDir,
        tool_name: "apply_patch", tool_use_id, turn_id,
        tool_input: { command: `*** Begin Patch\n*** Update File: ${file}\n*** End Patch` },
      }), hookDeps);
    }

    daemon = await createDaemon(loadDaemonConfig("/nonexistent", { daemon: { port: 0 } }));
    const post = () => fetch(`http://127.0.0.1:${daemon!.address().port}/ingest`, {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ session_id: sessionId, cwd: tempDir, client: "codex", transcript_path: transcriptPath }),
    });
    expect((await post()).status).toBe(200);

    let rows = [] as ReturnType<EventsDb["getUnprocessed"]>;
    for (let attempt = 0; attempt < 50 && (rows.length === 0 || rows.some(row => row.model == null)); attempt += 1) {
      const after = new EventsDb(eventsDbPath(tempDir, paths));
      rows = after.getUnprocessed().filter(event => event.session_id === sessionId);
      after.close();
      if (rows.some(row => row.model == null)) await new Promise(resolve => setTimeout(resolve, 10));
    }
    expect(rows.map(row => [row.tool_use_id, row.turn_id, row.model])).toEqual([
      ["call_patch", "turn-1", "gpt-5.6-codex"],
      ["call_patch_2", "turn-1", "gpt-5.6-codex"],
      ["call_patch_3", "turn-2", "gpt-5.6-codex-mini"],
    ]);
    const repeated = await post();
    expect(repeated.status).toBe(200);
    expect(await repeated.json()).toEqual({ ingested: 0, totalTokens: 0 });
    const afterRepeat = new EventsDb(eventsDbPath(tempDir, paths));
    expect(afterRepeat.getUnprocessed().filter(event => event.session_id === sessionId).map(event => event.model)).toEqual([
      "gpt-5.6-codex", "gpt-5.6-codex", "gpt-5.6-codex-mini",
    ]);
    afterRepeat.close();
  });
});
