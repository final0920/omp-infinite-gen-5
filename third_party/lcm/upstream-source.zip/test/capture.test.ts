import { appendFileSync, mkdirSync, mkdtempSync, rmSync, utimesSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { DatabaseSync } from "node:sqlite";
import { afterEach, beforeEach, describe, expect, it } from "vitest";
import { runLcmMigrations } from "../src/db/migration.js";
import { ScrubEngine } from "../src/scrub.js";
import { SessionCapture, attributionFromTranscriptPath, isSessionComplete, markSessionComplete } from "../src/capture.js";
import type { ParsedMessage } from "../src/transcript.js";

const msg = (role: ParsedMessage["role"], content: string, parts?: ParsedMessage["parts"]): ParsedMessage =>
  ({ role, content, tokenCount: 1, ...(parts ? { parts } : {}) });

const conversation = [
  msg("user", "hi"),
  msg("assistant", "hello"),
  msg("user", "<command-name>/model</command-name>", [{ type: "command", name: "/model", args: "opus" }]),
  msg("assistant", "done"),
];

describe("SessionCapture", () => {
  let db: DatabaseSync;
  let capture: SessionCapture;

  beforeEach(() => {
    db = new DatabaseSync(":memory:");
    runLcmMigrations(db);
    capture = new SessionCapture(db, "proj", new ScrubEngine([], []));
  });
  afterEach(() => db.close());

  const stored = () => ({
    messages: db.prepare("SELECT seq, role, content FROM messages ORDER BY seq").all(),
    contextItems: db.prepare("SELECT COUNT(*) AS n FROM context_items").get() as { n: number },
    parts: db.prepare(
      `SELECT m.seq, part_type, tool_name, tool_input FROM message_parts mp
       JOIN messages m ON m.message_id = mp.message_id ORDER BY m.seq, ordinal`,
    ).all(),
  });

  it("verifies complete capture through a flushed UUID, including a boundary behind its cursor", async () => {
    const dir = mkdtempSync(join(tmpdir(), "lcm-boundary-"));
    try {
      const path = join(dir, "s1.jsonl");
      writeFileSync(path, JSON.stringify({ uuid: "boundary", message: { role: "user", content: "source" } }) + "\n");
      const input = { sessionId: "s1", cwd: dir, transcriptPath: path, requireComplete: true, captureThroughUuid: "boundary" };
      expect((await capture.captureTranscript(input))?.verification).toEqual({ verified: true, complete: true, boundaryFound: true });
      expect((await capture.captureTranscript(input))?.verification).toEqual({ verified: true, complete: true, boundaryFound: true });
      appendFileSync(path, '{"uuid":"unfinished","message":');
      expect((await capture.captureTranscript(input))?.verification).toEqual({ verified: true, complete: false, boundaryFound: true });
      expect((await capture.captureTranscript({ ...input, captureThroughUuid: "not-flushed" }))?.verification?.boundaryFound).toBe(false);
    } finally { rmSync(dir, { recursive: true, force: true }); }
  });

  it("does not recapture a generated compaction envelope or lose source messages after it", async () => {
    const dir = mkdtempSync(join(tmpdir(), "lcm-recursion-"));
    try {
      const path = join(dir, "s1.jsonl");
      const row = (content: string) => JSON.stringify({ message: { role: "user", content } }) + "\n";
      writeFileSync(path, row("original"));
      await capture.captureTranscript({ sessionId: "s1", cwd: dir, transcriptPath: path });
      appendFileSync(path, row('<lcm-compaction-context version="1">\n<recent-session-context>\nUser:\noriginal\n</recent-session-context>\n</lcm-compaction-context>') + row("new material"));
      await capture.captureTranscript({ sessionId: "s1", cwd: dir, transcriptPath: path });
      expect((await capture.conversationStore.getSessionMessages("s1")).map(r => r.content)).toEqual(["original", "new material"]);
      expect((await capture.captureTranscript({ sessionId: "s1", cwd: dir, transcriptPath: path }))?.records).toHaveLength(0);
    } finally { rmSync(dir, { recursive: true, force: true }); }
  });

  it("writes only the delta past the stored count, twice in a row", async () => {
    const first = await capture.write({ sessionId: "s1", messages: conversation.slice(0, 2) });
    expect(first.records).toHaveLength(2);

    const second = await capture.write({ sessionId: "s1", messages: conversation });
    expect(second.conversationId).toBe(first.conversationId);
    expect(second.records.map((r) => r.seq)).toEqual([2, 3]);

    const { messages, contextItems, parts } = stored();
    expect(messages).toEqual([
      { seq: 0, role: "user", content: "hi" },
      { seq: 1, role: "assistant", content: "hello" },
      { seq: 2, role: "user", content: "<command-name>/model</command-name>" },
      { seq: 3, role: "assistant", content: "done" },
    ]);
    expect(contextItems.n).toBe(4);
    expect(parts).toEqual([{ seq: 2, part_type: "command", tool_name: "/model", tool_input: "opus" }]);
  });

  it("scrubs command and skill arguments in message parts, and counts their matches", async () => {
    const scrubbing = new SessionCapture(db, "proj", new ScrubEngine(["ZQX-PRIVATE-\\d+"], []));
    const result = await scrubbing.write({ sessionId: "s1", messages: [
      msg("user", "<command-name>/deploy</command-name> ZQX-PRIVATE-7781",
        [{ type: "command", name: "/deploy", args: "--key ZQX-PRIVATE-7781" }]),
      msg("assistant", "launching", [{ type: "skill", name: "release", args: "token ZQX-PRIVATE-4410" }]),
    ] });
    const { messages, parts } = stored();
    expect(JSON.stringify([messages, parts])).not.toContain("ZQX-PRIVATE-");
    expect(parts).toEqual([
      expect.objectContaining({ part_type: "command", tool_name: "/deploy", tool_input: expect.stringContaining("--key ") }),
      expect.objectContaining({ part_type: "skill", tool_name: "release", tool_input: expect.stringContaining("token ") }),
    ]);
    expect(result.totalCounts.global).toBe(3);
  });

  it.each(["claude", "codex"])("keeps a %s tool output after a NUL through capture and readback", async (client) => {
    const dir = mkdtempSync(join(tmpdir(), "lcm-nul-capture-"));
    try {
      const path = join(dir, "s1.jsonl");
      const output = "before\u0000after";
      const entries = client === "claude"
        ? [{ message: { role: "user", content: [{ type: "tool_result", content: output }] } }]
        : [
            { type: "session_meta", payload: { id: "s1", cwd: dir } },
            { type: "response_item", payload: { type: "function_call_output", output } },
          ];
      writeFileSync(path, entries.map((entry) => JSON.stringify(entry)).join("\n") + "\n");
      const result = await capture.captureTranscript({ sessionId: "s1", cwd: dir, transcriptPath: path, client });
      expect(result?.records.map((record) => record.content)).toEqual(["before\uFFFDafter"]);
      expect(stored().messages).toEqual([{ seq: 0, role: "tool", content: "before\uFFFDafter" }]);
      expect(db.prepare("SELECT content FROM messages_fts").get()).toEqual({ content: "before\uFFFDafter" });
    } finally {
      rmSync(dir, { recursive: true, force: true });
    }
  });

  it("replaying the full transcript writes nothing new", async () => {
    await capture.write({ sessionId: "s1", messages: conversation });
    const replay = await capture.write({ sessionId: "s1", messages: conversation });
    expect(replay.records).toHaveLength(0);
    expect(stored().messages).toHaveLength(4);
    expect(stored().parts).toHaveLength(1);
  });

  it("a suffix read from a source offset resumes exactly at the stored count", async () => {
    await capture.write({ sessionId: "s1", messages: conversation.slice(0, 3) });
    // The source skipped 2 messages; the store holds 3, so only the last one is new.
    const result = await capture.write({ sessionId: "s1", messages: conversation.slice(2), sourceOffset: 2 });
    expect(result.records.map((r) => r.seq)).toEqual([3]);
    expect(stored().messages).toHaveLength(4);
  });

  it("creates the conversation with attribution even when there is nothing to write", async () => {
    const result = await capture.write({
      sessionId: "agent-1", messages: [], attribution: { parentSessionId: "parent", subagentType: "Explore", subagentDesc: "look" },
    });
    expect(result.records).toHaveLength(0);
    const row = db.prepare("SELECT parent_session_id, subagent_type, subagent_desc FROM conversations WHERE session_id = ?")
      .get("agent-1");
    expect(row).toEqual({ parent_session_id: "parent", subagent_type: "Explore", subagent_desc: "look" });
    expect(await capture.stored("agent-1")).toEqual({ conversationId: result.conversationId, storedCount: 0 });
  });

  it("reads attribution from the sidecar of a subagent transcript when the caller has none", async () => {
    const dir = mkdtempSync(join(tmpdir(), "lcm-capture-"));
    try {
      const subagents = join(dir, "parent-session", "subagents");
      mkdirSync(subagents, { recursive: true });
      const path = join(subagents, "agent-2.jsonl");
      writeFileSync(path, "");
      writeFileSync(join(subagents, "agent-2.meta.json"), JSON.stringify({ agentType: "Plan", description: "plan it" }));

      expect(attributionFromTranscriptPath(path)).toEqual({ parentSessionId: "parent-session", subagentType: "Plan", subagentDesc: "plan it" });
      expect(attributionFromTranscriptPath(join(dir, "parent-session.jsonl"))).toBeUndefined();
      const nested = join(subagents, "workflows", "wf_1", "agent-3.jsonl");
      mkdirSync(join(subagents, "workflows", "wf_1"), { recursive: true });
      writeFileSync(nested, "");
      writeFileSync(join(subagents, "workflows", "wf_1", "agent-3.meta.json"), "{}");
      expect(attributionFromTranscriptPath(nested)).toEqual({ parentSessionId: "parent-session", subagentType: null, subagentDesc: null });

      await capture.write({ sessionId: "agent-2", transcriptPath: path, messages: conversation.slice(0, 1) });
      const row = db.prepare("SELECT parent_session_id, subagent_type FROM conversations WHERE session_id = ?").get("agent-2");
      expect(row).toEqual({ parent_session_id: "parent-session", subagent_type: "Plan" });
    } finally {
      rmSync(dir, { recursive: true, force: true });
    }
  });

  it("scrubs content and tallies redaction counts per project", async () => {
    const result = await capture.write({
      sessionId: "s1", messages: [msg("user", "token ghp_AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA here")],
    });
    expect(result.records[0].content).not.toContain("ghp_AAAA");
    expect(result.totalCounts.gitleaks).toBeGreaterThan(0);
    const row = db.prepare("SELECT count FROM redaction_stats WHERE category = 'gitleaks'").get() as { count: number };
    expect(row.count).toBe(result.totalCounts.gitleaks);
  });

  it("a failure in a later write leaves no conversation row behind", async () => {
    const original = capture.conversationStore.createMessagesBulk.bind(capture.conversationStore);
    capture.conversationStore.createMessagesBulk = async () => {
      throw new Error("boom");
    };
    try {
      await expect(capture.write({ sessionId: "s1", messages: conversation.slice(0, 2) })).rejects.toThrow("boom");
    } finally {
      capture.conversationStore.createMessagesBulk = original;
    }
    expect(db.prepare("SELECT 1 FROM conversations WHERE session_id = ?").get("s1")).toBeUndefined();
    expect(stored().messages).toHaveLength(0);
  });

  it("owns the session ingest log", () => {
    expect(isSessionComplete(db, "s1")).toBe(false);
    markSessionComplete(db, "s1", 4);
    expect(isSessionComplete(db, "s1")).toBe(true);
    markSessionComplete(db, "s1", 6);
    expect(db.prepare("SELECT message_count FROM session_ingest_log WHERE session_id = 's1'").get()).toEqual({ message_count: 6 });
  });

  it("does not treat a session as complete once its transcript changed after completion", () => {
    const dir = mkdtempSync(join(tmpdir(), "lcm-capture-complete-"));
    try {
      const transcriptPath = join(dir, "s1.jsonl");
      writeFileSync(transcriptPath, "{}\n");
      const minuteAgo = new Date(Date.now() - 60_000);
      utimesSync(transcriptPath, minuteAgo, minuteAgo);
      markSessionComplete(db, "s1", 1);
      expect(isSessionComplete(db, "s1", transcriptPath)).toBe(true);

      // Written to after the session was completed, as a resume does.
      const minuteAhead = new Date(Date.now() + 60_000);
      utimesSync(transcriptPath, minuteAhead, minuteAhead);
      expect(isSessionComplete(db, "s1", transcriptPath)).toBe(false);
      expect(isSessionComplete(db, "s1")).toBe(true);

      // Completing it again moves the completion past that write.
      utimesSync(transcriptPath, minuteAgo, minuteAgo);
      db.prepare("UPDATE session_ingest_log SET completed_at = '2000-01-01 00:00:00' WHERE session_id = 's1'").run();
      expect(isSessionComplete(db, "s1", transcriptPath)).toBe(false);
      markSessionComplete(db, "s1", 2);
      expect(isSessionComplete(db, "s1", transcriptPath)).toBe(true);

      // A transcript that cannot be read is read again rather than skipped.
      expect(isSessionComplete(db, "s1", join(dir, "missing.jsonl"))).toBe(false);
    } finally {
      rmSync(dir, { recursive: true, force: true });
    }
  });
});
