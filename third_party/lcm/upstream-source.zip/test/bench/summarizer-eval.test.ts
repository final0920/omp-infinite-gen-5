import { createHash } from "node:crypto";
import { existsSync, mkdtempSync, rmSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { describe, expect, it } from "vitest";
import type { LcmSummarizeFn } from "../../src/llm/types.js";
import {
  buildSyntheticSession,
  loadCorpusDir,
  runEval,
  scoreSummary,
  writeResult,
  type CorpusSession,
} from "./summarizer-eval-harness.js";
import { createEvalSummarizer, evalRequestBody, type EvalProvider } from "./summarizer-eval-providers.js";
import { parseLanguageTag } from "../../src/search/language.js";

const RESULTS_DIR = join(import.meta.dirname, "results");

/** Offline stand-in that obeys the prompt contract and echoes the input head. */
const fakeSummarizer: LcmSummarizeFn = async (text, _aggressive, ctx = {}) => {
  const head = text.replace(/\[[^\]]*\]\n/g, "").slice(0, 2400);
  const files = ctx.isCondensed ? "" : "Files: none\n";
  return `${files}${head}\nExpand for details about: filler observations`;
};

describe("summarizer eval harness (offline)", () => {
  it("runs leaf and depth-1 passes under production config and scores them", async () => {
    const session = buildSyntheticSession();
    const result = await runEval({ session, summarizer: fakeSummarizer, model: "fake", provider: "fake", run: 1 });

    expect(result.incomplete).toBe(false);
    expect(result.calls.filter((c) => c.pass === "leaf").length).toBeGreaterThanOrEqual(3);
    expect(result.calls.filter((c) => c.pass === "condensed" && c.depth === 1).length).toBeGreaterThanOrEqual(1);
    expect(result.summaries.some((s) => s.depth === 1)).toBe(true);
    expect(result.totals.formatTotal).toBe(result.calls.length);
    expect(result.totals.formatPass).toBe(result.totals.formatTotal);
    expect(result.plantedFacts?.map((f) => f.name)).toHaveLength(5);
    expect(result.tokensAfter).toBeLessThan(result.tokensBefore);
  }, 30_000);

  it("counts output-cap hits for HTTP runs only, whatever label the usage carries", async () => {
    // The factory labels usage with the eval endpoint's name, so the run's provider decides.
    const summarizer: LcmSummarizeFn = async (_text, _aggressive, ctx = {}) => {
      ctx.onUsage?.({ provider: "eval", outputTokens: 1_000_000, tokensUsed: 1_000_000 });
      return "Files: none\nSummary\nExpand for details about: cap";
    };
    const run = (provider: string) =>
      runEval({ session: buildSyntheticSession(), summarizer, model: "fake", provider, run: 1 });
    expect((await run("claude-process")).totals.maxTokensHits).toBe(0);
    expect((await run("openrouter")).totals.maxTokensHits).toBeGreaterThan(0);
  }, 30_000);

  it("passes the corpus language through the production engine configuration", async () => {
    const languages: Array<string | undefined> = [];
    const summarizer: LcmSummarizeFn = async (_text, _aggressive, ctx) => {
      languages.push(ctx.language);
      return "Files: none\nSummary\nExpand for details about: language";
    };
    const result = await runEval({
      session: buildSyntheticSession(), summarizer, model: "fake", provider: "fake", run: 1, language: "pt-BR",
    });
    expect(languages.length).toBeGreaterThan(0);
    expect(languages.every((language) => language === "pt-BR")).toBe(true);
    expect(result.language).toBe("pt-BR");

    const dir = mkdtempSync(join(tmpdir(), "lcm-eval-language-"));
    try {
      const ptPath = writeResult(dir, result);
      const enPath = writeResult(dir, { ...result, language: "en" });
      expect(ptPath).not.toBe(enPath);
      expect(ptPath).toContain("__lang-pt-BR__");
    } finally {
      rmSync(dir, { recursive: true, force: true });
    }
  }, 30_000);

  it("scores format per pass type", () => {
    const leaf = scoreSummary("Did things.\nFiles: none\nExpand for details about: x", 0);
    expect(leaf).toMatchObject({ hasFilesLine: true, hasExpandTrailer: true, isFallback: false });
    const condensed = scoreSummary("Did things.\nExpand for details about: x", 1);
    expect(condensed).toMatchObject({ hasFilesLine: null, hasExpandTrailer: true });
    expect(scoreSummary("Did things.", 0)).toMatchObject({ hasFilesLine: false, hasExpandTrailer: false });
    expect(scoreSummary("raw text\n[Truncated from 900 tokens]", 0).isFallback).toBe(true);
  });

  it("detects the production empty-content fallback", async () => {
    // openai.ts returns text.slice(0, 500) when the model sends empty content.
    const echoing: LcmSummarizeFn = async (text) => text.slice(0, 500);
    const result = await runEval({
      session: buildSyntheticSession(), summarizer: echoing, model: "fake", provider: "fake", run: 1,
    });
    expect(result.calls.length).toBeGreaterThan(0);
    expect(result.calls.every((c) => c.emptyContentFallback)).toBe(true);
  }, 30_000);

  it("merges LCM_EVAL_BODY into the request body and rejects anything but a JSON object", () => {
    const saved = { body: process.env.LCM_EVAL_BODY, thinking: process.env.LCM_EVAL_DISABLE_THINKING };
    try {
      process.env.LCM_EVAL_DISABLE_THINKING = "1";
      process.env.LCM_EVAL_BODY = '{"enable_thinking":false}';
      expect(evalRequestBody()).toEqual({ chat_template_kwargs: { enable_thinking: false }, enable_thinking: false });
      process.env.LCM_EVAL_BODY = "[1]";
      expect(() => evalRequestBody()).toThrow(/LCM_EVAL_BODY must be a JSON object/);
    } finally {
      for (const [name, value] of [["LCM_EVAL_BODY", saved.body], ["LCM_EVAL_DISABLE_THINKING", saved.thinking]] as const) {
        if (value === undefined) delete process.env[name];
        else process.env[name] = value;
      }
    }
  });

  it("marks a run incomplete when the summarizer keeps failing", async () => {
    const failing: LcmSummarizeFn = async () => {
      throw new Error("429 rate limited");
    };
    const result = await runEval({ session: buildSyntheticSession(), summarizer: failing, model: "fake", provider: "fake", run: 1 });
    expect(result.incomplete).toBe(true);
    expect(result.error).toContain("429");
    expect(result.totals.failedCalls).toBe(1);
  }, 30_000);
});

// ── Live eval, gated by env ────────────────────────────────────────────────
//
//   LCM_EVAL_MODEL       candidate model id (required)
//   LCM_EVAL_CORPUS_DIR  directory of <label>.json exports (required)
//   LCM_EVAL_PROVIDER    openrouter (default) | openai | claude-process
//   LCM_EVAL_BASE_URL    openai only: OpenAI-compatible endpoint; LCM_EVAL_API_KEY optional
//   LCM_EVAL_RUNS        runs per session (default 1)
//   LCM_EVAL_SESSIONS    comma-separated labels to run (default all)
//   LCM_EVAL_TOOL_CONTEXT on (default) | off (baseline without supplemental input)
//   LCM_EVAL_REASONING         http providers: JSON sent as `reasoning`, e.g. {"enabled":false} (default none)
//   LCM_EVAL_REASONING_EFFORT  shorthand for LCM_EVAL_REASONING={"effort":"<value>"}
//   LCM_EVAL_DISABLE_THINKING  http providers: "1" sends chat_template_kwargs.enable_thinking=false (Qwen-style servers)
//   LCM_EVAL_BODY              http providers: JSON object merged into the request body, e.g. {"enable_thinking":false}
//   LCM_EVAL_LANGUAGE          configured or detected BCP 47 language for the corpus

const EVAL_PROVIDERS: readonly EvalProvider[] = ["openrouter", "openai", "claude-process"];

function parseProvider(value: string | undefined): EvalProvider {
  if (value === undefined) return "openrouter";
  if ((EVAL_PROVIDERS as readonly string[]).includes(value)) return value as EvalProvider;
  throw new Error(`LCM_EVAL_PROVIDER must be one of ${EVAL_PROVIDERS.join(", ")}, got: ${value}`);
}

function parseRuns(value: string | undefined): number {
  if (value === undefined) return 1;
  const n = Number(value);
  if (!Number.isInteger(n) || n < 1) {
    throw new Error(`LCM_EVAL_RUNS must be a positive integer, got: ${value}`);
  }
  return n;
}

const model = process.env.LCM_EVAL_MODEL;
const corpusDir = process.env.LCM_EVAL_CORPUS_DIR;
const provider = parseProvider(process.env.LCM_EVAL_PROVIDER);
const runs = parseRuns(process.env.LCM_EVAL_RUNS);
const contextMode = process.env.LCM_EVAL_TOOL_CONTEXT ?? "on";
if (contextMode !== "on" && contextMode !== "off") {
  throw new Error("LCM_EVAL_TOOL_CONTEXT must be on or off");
}
const toolContext = contextMode === "on";
const only = process.env.LCM_EVAL_SESSIONS?.split(",").map((s) => s.trim()).filter(Boolean);
const language = process.env.LCM_EVAL_LANGUAGE
  ? parseLanguageTag(process.env.LCM_EVAL_LANGUAGE)
  : undefined;
if (process.env.LCM_EVAL_LANGUAGE && !language) {
  throw new Error(`LCM_EVAL_LANGUAGE must be a valid BCP 47 language tag, got: ${process.env.LCM_EVAL_LANGUAGE}`);
}

const reasoning =
  (process.env.LCM_EVAL_REASONING ? ` reasoning=${process.env.LCM_EVAL_REASONING}` : "") +
  (process.env.LCM_EVAL_REASONING_EFFORT ? ` reasoning=${process.env.LCM_EVAL_REASONING_EFFORT}` : "") +
  (process.env.LCM_EVAL_DISABLE_THINKING === "1" ? " thinking=off" : "") +
  (process.env.LCM_EVAL_BODY ? ` body=${bodyIdentity(process.env.LCM_EVAL_BODY)}` : "");

/**
 * A readable prefix of the body plus a digest of its parsed JSON: the filename
 * sanitizer folds punctuation, so the text alone would let distinct bodies collide.
 */
function bodyIdentity(raw: string): string {
  let canonical = raw;
  try {
    canonical = JSON.stringify(JSON.parse(raw));
  } catch {
    // evalRequestBody rejects it when the run starts; keep the raw text here.
  }
  return `${canonical.slice(0, 40)}~${createHash("sha256").update(canonical).digest("hex").slice(0, 12)}`;
}

/** The reasoning/thinking knobs, as a filename-safe run identity. */
const variant = reasoning.trim().replace(/\s+/g, "_") || undefined;

describe.skipIf(!model || !corpusDir)(`summarizer eval: ${model} via ${provider}${reasoning}`, () => {
  if (corpusDir && !existsSync(corpusDir)) {
    throw new Error(`LCM_EVAL_CORPUS_DIR does not exist: ${corpusDir}`);
  }
  const sessions: CorpusSession[] = (corpusDir
    ? [...loadCorpusDir(corpusDir), buildSyntheticSession(), buildSyntheticSession({ toolFailures: true })]
    : []
  ).filter((s) => !only || only.includes(s.label));

  it("has a corpus to run", () => {
    expect(sessions.length).toBeGreaterThan(0);
  });

  for (const session of sessions) {
    for (let run = 1; run <= runs; run++) {
      it(`${session.label} run ${run}`, async () => {
        const summarizer = await createEvalSummarizer(provider, model!);
        const result = await runEval({ session, summarizer, model: model!, provider, variant, run, language, toolContext });
        const file = writeResult(RESULTS_DIR, result);
        const facts = result.plantedFacts
          ? ` facts=${result.plantedFacts.filter((f) => f.survived).length}/${result.plantedFacts.length}`
          : "";
        console.log(
          `${session.label} run ${run}: calls=${result.totals.calls} failed=${result.totals.failedCalls}` +
            ` format=${result.totals.formatPass}/${result.totals.formatTotal} maxTokensHits=${result.totals.maxTokensHits}` +
            ` tokens=${result.tokensBefore}->${result.tokensAfter} latency=${result.totals.latencyMs}ms` +
            `${facts}${result.incomplete ? " INCOMPLETE" : ""} -> ${file}`,
        );
        // A failed or partial run is recorded, not asserted: the JSON is the deliverable.
        expect(existsSync(file)).toBe(true);
      }, 0);
    }
  }
});
