import { mkdtempSync, rmSync, mkdirSync, existsSync, readFileSync, writeFileSync, readdirSync } from "node:fs";
import { tmpdir } from "node:os";
import { join, dirname } from "node:path";
import { afterEach, describe, expect, it, vi } from "vitest";
import { DatabaseSync } from "node:sqlite";
import { runLcmMigrations } from "../../src/db/migration.js";
import { ConversationStore } from "../../src/store/conversation-store.js";
import { SummaryStore } from "../../src/store/summary-store.js";
import { projectDbPath, projectId } from "../../src/daemon/project.js";
import { PromotedStore } from "../../src/db/promoted.js";
import { buildBench, runBench, type BenchFile } from "../../src/bench.js";
import { createLcmPaths } from "../../src/lcm-paths.js";
import { lcmHome } from "../../src/lcm-home.js";
import { invalidateLanguagePacks, languagePackPath } from "../../src/store/language-pack.js";

// project.js is mocked below; the root only has to be a real one.
const paths = createLcmPaths(lcmHome());
import { getLcmConnection } from "../../src/db/connection.js";

const tempDirs: string[] = [];

vi.mock("../../src/daemon/project.js", async (importOriginal) => ({
  ...await importOriginal<typeof import("../../src/daemon/project.js")>(),
  projectDbPath: (cwd: string) => join(cwd, "db.sqlite"),
  projectMetaPath: (cwd: string) => join(cwd, "meta.json"),
}));

vi.mock("../../src/db/connection.js", async (importOriginal) => {
  const actual = await importOriginal<typeof import("../../src/db/connection.js")>();
  return {
    getLcmConnection: vi.fn(actual.getLcmConnection),
    closeLcmConnection: vi.fn(actual.closeLcmConnection),
  };
});

afterEach(() => {
  for (const dir of tempDirs.splice(0)) {
    rmSync(dir, { recursive: true, force: true });
  }
});

async function seedProject(cwd: string): Promise<void> {
  const dbPath = projectDbPath(cwd, paths);
  mkdirSync(dirname(dbPath), { recursive: true });
  const db = new DatabaseSync(dbPath);
  try {
    runLcmMigrations(db);
    const convStore = new ConversationStore(db);
    const summStore = new SummaryStore(db);
    const promotedStore = new PromotedStore(db);

    const sessions: Array<{ sessionId: string; prompts: string[] }> = [
      {
        sessionId: "sess-rollback",
        prompts: [
          "The 2.4.1 release went out this morning and customers are already reporting the settings page is blank. We need to roll back the deploy right now.",
          "Make sure the rollback script also purges the CDN cache, otherwise clients keep fetching the broken bundle.",
        ],
      },
      {
        sessionId: "sess-timeout",
        prompts: [
          "CI failed again on the pricing suite. The jest runner times out waiting for the test database container to become healthy.",
          "This flakes two or three times a week and it is destroying trust in the pipeline.",
        ],
      },
      {
        sessionId: "sess-storage",
        prompts: [
          "For the memory daemon we need to pick a storage engine. I'm leaning towards SQLite but I want the tradeoffs on record.",
          "Operations burden matters more than write concurrency here. This runs on a laptop, not in a datacenter.",
        ],
      },
    ];

    for (const s of sessions) {
      const conv = await convStore.getOrCreateConversation(s.sessionId);
      const inputs = s.prompts.flatMap((prompt, i) => [
        {
          conversationId: conv.conversationId,
          seq: i * 2,
          role: "user" as const,
          content: prompt,
          tokenCount: Math.ceil(prompt.length / 4),
        },
        {
          conversationId: conv.conversationId,
          seq: i * 2 + 1,
          role: "assistant" as const,
          content: `Acknowledged. Working on it now. (${s.sessionId})`,
          tokenCount: 8,
        },
      ]);
      const created = await convStore.createMessagesBulk(inputs);
      const summary = await summStore.insertSummary({
        summaryId: `sum_${s.sessionId}`,
        conversationId: conv.conversationId,
        kind: "leaf",
        content: s.prompts.join("\n"),
        tokenCount: 100,
      });
      await summStore.linkSummaryToMessages(
        summary.summaryId,
        created.map((m) => m.messageId),
      );
      await promotedStore.insert({
        content: `Decision notes for ${s.sessionId}: ${s.prompts[0].slice(0, 120)}`,
        tags: ["decision"],
        projectId: projectId(cwd),
        sessionId: s.sessionId,
      });
    }
  } finally {
    db.close();
  }
}

/**
 * Adds sessions to an already seeded project; `prompt` may carry several turns.
 *
 * A fixture that tests a *rejection* needs a capitalized mid-sentence identifier
 * (e.g. "GitHub", "Stripe"). Without one, `mechanicalQuestion` falls through to a
 * subjectless question that is rejected for an unrelated reason, so the prompt is
 * absent from the bench file whether or not the filter under test exists — and the
 * test passes with the fix removed. This has produced three vacuous tests so far.
 */
async function addSessions(cwd: string, entries: Array<{ sessionId: string; prompt: string | string[] }>): Promise<void> {
  const db = new DatabaseSync(projectDbPath(cwd, paths));
  try {
    const convStore = new ConversationStore(db);
    for (const entry of entries) {
      const conv = await convStore.getOrCreateConversation(entry.sessionId);
      const prompts = Array.isArray(entry.prompt) ? entry.prompt : [entry.prompt];
      await convStore.createMessagesBulk(prompts.map((content, seq) => ({
        conversationId: conv.conversationId,
        seq,
        role: "user" as const,
        content,
        tokenCount: Math.ceil(content.length / 4),
      })));
    }
  } finally {
    db.close();
  }
}

describe("lcm bench", () => {
  it("accepts manually curated real wording and short identifier lookups", async () => {
    const cwd = mkdtempSync(join(tmpdir(), "lcm-bench-"));
    tempDirs.push(cwd);
    await seedProject(cwd);
    const file = join(cwd, "manual.json");
    const question = "Why did we choose SQLite for the memory daemon?";
    writeFileSync(file, JSON.stringify({ version: 1, generator: "manual", queries: [
      { id: "actual", sessionId: "sess-storage", prompt: question, question, generator: "manual" },
      { id: "identifier", sessionId: "sess-rollback", prompt: "Investigate PR #1462", question: "PR #1462", generator: "manual" },
    ] }));
    const result = await runBench({ cwd, benchFile: file, json: true });
    expect(result.exitCode, result.stdout).toBe(0);
    expect(JSON.parse(result.stdout).total).toBe(2);
    expect(JSON.parse(result.stdout).warnings).toEqual([]);
  });

  it("still rejects duplicate and empty manual queries", async () => {
    const cwd = mkdtempSync(join(tmpdir(), "lcm-bench-"));
    tempDirs.push(cwd);
    const file = join(cwd, "manual.json");
    const query = { id: "1", sessionId: "sess-storage", prompt: "SQLite", question: "SQLite", generator: "manual" };
    writeFileSync(file, JSON.stringify({ version: 1, queries: [query, { ...query, id: "2" }] }));
    expect((await runBench({ cwd, benchFile: file })).stdout).toContain("duplicate question");
    writeFileSync(file, JSON.stringify({ version: 1, queries: [{ ...query, question: " " }] }));
    expect((await runBench({ cwd, benchFile: file })).stdout).toContain("nonempty query text");
    writeFileSync(file, JSON.stringify({ version: 1, queries: [{ ...query, sessionId: " " }] }));
    expect((await runBench({ cwd, benchFile: file })).stdout).toContain("source session");
  });

  it("uses an explicit LLM generator without silently substituting mechanical questions", async () => {
    const cwd = mkdtempSync(join(tmpdir(), "lcm-bench-"));
    tempDirs.push(cwd);
    await seedProject(cwd);
    const result = await buildBench({ cwd, generator: "llm", language: "en" }, async () => null);
    expect(result.exitCode).toBe(1);
    expect(result.stdout).toContain("returned no question");
    expect(result.out).toBe("");
  });

  it("rejects an LLM question that just reuses its prompt's vocabulary", async () => {
    const cwd = mkdtempSync(join(tmpdir(), "lcm-bench-"));
    tempDirs.push(cwd);
    await seedProject(cwd);
    // Every content word here is lifted from the storage session's own prompt,
    // so it tests lexical lookup rather than whether search can be reached for
    // with different words.
    const echo = async (prompt: string) =>
      `Which of these did we handle: ${prompt.split(/\s+/).slice(0, 12).reverse().join(" ")}?`;
    const result = await buildBench({ cwd, generator: "llm", language: "en" }, echo);
    expect(result.exitCode).toBe(1);
    expect(result.stdout).toContain("reuses too much of the source prompt");

    // A question about the same session in the user's own later words survives.
    const paraphrase = async () => "Why did we settle on the database we did?";
    const kept = await buildBench({ cwd, generator: "llm", language: "en" }, paraphrase);
    expect(kept.exitCode, kept.stdout).toBe(0);
    const bench = JSON.parse(readFileSync(kept.out, "utf-8")) as BenchFile;
    expect(bench.queries.length).toBeGreaterThan(0);
  });

  it("rejects duplicate and subjectless generated questions", async () => {
    const cwd = mkdtempSync(join(tmpdir(), "lcm-bench-"));
    tempDirs.push(cwd);
    await seedProject(cwd);
    const bad = await buildBench({ cwd, generator: "llm", language: "en" }, async () => "what did we work on in that session?");
    expect(bad.exitCode).toBe(1);
    expect(bad.stdout).toContain("no identifiable subject");
    const duplicate = await buildBench({ cwd, generator: "llm", language: "en" }, async () => "How did we recover the customer settings page?");
    const bench = JSON.parse(readFileSync(duplicate.out, "utf8")) as BenchFile;
    expect(bench.queries).toHaveLength(1);
    expect(bench.generator).toBe("llm");
    expect(duplicate.stdout).toContain("duplicate question");
  });

  it("writes an LLM set in the language read from the corpus's human turns and reports it", async () => {
    const cwd = mkdtempSync(join(tmpdir(), "lcm-bench-"));
    tempDirs.push(cwd);
    await seedProject(cwd);
    const detect = vi.fn(async () => "pt-BR");
    const paraphrase = async () => "Por que escolhemos esse banco de dados?";
    const built = await buildBench({ cwd, generator: "llm" }, paraphrase, detect);
    expect(built.exitCode, built.stdout).toBe(0);
    expect(built.stdout).toContain("(llm, pt-BR)");
    const sample = detect.mock.calls[0][0] as unknown as string[];
    expect(sample.length).toBeGreaterThan(0);
    for (const turn of sample) expect(typeof turn).toBe("string");
    const bench = JSON.parse(readFileSync(built.out, "utf-8")) as BenchFile;
    expect(bench.language).toBe("pt-BR");
    const run = await runBench({ cwd, benchFile: built.out, json: true });
    expect(JSON.parse(run.stdout).language).toBe("pt-BR");
  });

  it("keeps pasted tool output out of the turns the language is read from", async () => {
    const cwd = mkdtempSync(join(tmpdir(), "lcm-bench-"));
    tempDirs.push(cwd);
    await seedProject(cwd);
    const listing = "src/daemon/routes/compact.ts:12: export async function compactRoute(req: GitHub, res: Stripe) {";
    await addSessions(cwd, [{ sessionId: "sess-listing", prompt: listing }]);
    const detect = vi.fn(async () => "pt-BR");
    const built = await buildBench({ cwd, generator: "llm" }, async () => "Por que escolhemos esse banco de dados?", detect);
    expect(built.exitCode, built.stdout).toBe(0);
    const sample = detect.mock.calls[0][0] as unknown as string[];
    expect(sample.length).toBeGreaterThan(0);
    expect(sample).not.toContain(listing);
  });

  it("uses the language the daemon recorded for the project before detecting", async () => {
    const cwd = mkdtempSync(join(tmpdir(), "lcm-bench-"));
    tempDirs.push(cwd);
    await seedProject(cwd);
    writeFileSync(join(cwd, "meta.json"), JSON.stringify({ cwd, language: "de" }));
    const detect = vi.fn(async () => "pt-BR");
    const built = await buildBench({ cwd, generator: "llm" }, async () => "Warum diese Datenbank?", detect);
    expect(built.exitCode, built.stdout).toBe(0);
    expect(detect).not.toHaveBeenCalled();
    expect((JSON.parse(readFileSync(built.out, "utf-8")) as BenchFile).language).toBe("de");
  });

  it("an explicit language wins over detection", async () => {
    const cwd = mkdtempSync(join(tmpdir(), "lcm-bench-"));
    tempDirs.push(cwd);
    await seedProject(cwd);
    const detect = vi.fn(async () => "pt-BR");
    const built = await buildBench({ cwd, generator: "llm", language: "de" }, async () => "Warum diese Datenbank?", detect);
    expect(built.exitCode, built.stdout).toBe(0);
    expect(detect).not.toHaveBeenCalled();
    expect((JSON.parse(readFileSync(built.out, "utf-8")) as BenchFile).language).toBe("de");
  });

  it("an LLM build fails without a language instead of defaulting to English", async () => {
    const cwd = mkdtempSync(join(tmpdir(), "lcm-bench-"));
    tempDirs.push(cwd);
    await seedProject(cwd);
    const noDetector = await buildBench({ cwd, generator: "llm" }, async () => "Why that database?");
    expect(noDetector.exitCode).toBe(1);
    expect(noDetector.out).toBe("");
    expect(noDetector.stdout).toContain("--language");
    const unsure = await buildBench({ cwd, generator: "llm" }, async () => "Why that database?", async () => null);
    expect(unsure.exitCode).toBe(1);
    expect(unsure.stdout).toContain("Could not tell");
    const malformed = await buildBench({ cwd, generator: "llm", language: "Portuguese (Brazil)" }, async () => "Why that database?");
    expect(malformed.exitCode).toBe(1);
    expect(malformed.stdout).toContain("BCP 47");
  });

  it("records mechanical sets as English, which their templates are", async () => {
    const cwd = mkdtempSync(join(tmpdir(), "lcm-bench-"));
    tempDirs.push(cwd);
    await seedProject(cwd);
    const built = await buildBench({ cwd, n: 5, seed: 7 });
    expect(built.exitCode, built.stdout).toBe(0);
    expect((JSON.parse(readFileSync(built.out, "utf-8")) as BenchFile).language).toBe("en");
  });

  it("rejects empty or duplicate benchmark input before measuring", async () => {
    const cwd = mkdtempSync(join(tmpdir(), "lcm-bench-"));
    tempDirs.push(cwd);
    const file = join(cwd, "bench.json");
    writeFileSync(file, JSON.stringify({ version: 1, queries: [] }));
    expect((await runBench({ cwd, benchFile: file })).stdout).toContain("nonempty queries");
    const query = { id: "1", sessionId: "session", prompt: "the original prompt", question: "How did we recover the customer settings page?", generator: "llm" };
    writeFileSync(file, JSON.stringify({ version: 1, queries: [query, { ...query, id: "2" }] }));
    expect((await runBench({ cwd, benchFile: file })).stdout).toContain("duplicate question");
  });
  it("build writes a benchmark file with vocabulary-diverging questions", async () => {
    const cwd = mkdtempSync(join(tmpdir(), "lcm-bench-"));
    tempDirs.push(cwd);
    await seedProject(cwd);

    const result = await buildBench({ cwd, n: 5, seed: 7 });
    expect(result.exitCode).toBe(0);
    expect(existsSync(result.out)).toBe(true);

    const bench = JSON.parse(readFileSync(result.out, "utf-8")) as BenchFile;
    expect(bench.queries.length).toBeGreaterThan(0);
    for (const q of bench.queries) {
      expect(q.question.length).toBeGreaterThan(0);
      // Mechanical questions must not reuse the prompt's content words
      // beyond the single capitalized focus term.
      expect(q.sessionId.length).toBeGreaterThan(0);
    }
  });

  it("build fails cleanly when the project has no database", async () => {
    const cwd = mkdtempSync(join(tmpdir(), "lcm-bench-empty-"));
    tempDirs.push(cwd);
    const result = await buildBench({ cwd });
    expect(result.exitCode).toBe(1);
    expect(result.stdout).toContain("No project database");
  });

  it("run reports the hit rate against the grep baseline", async () => {
    const cwd = mkdtempSync(join(tmpdir(), "lcm-bench-"));
    tempDirs.push(cwd);
    await seedProject(cwd);

    const build = await buildBench({ cwd, n: 5, seed: 7 });
    expect(build.exitCode).toBe(0);

    const run = await runBench({ cwd, k: 5 });
    expect(run.exitCode).toBe(0);
    expect(run.stdout).toContain("hit@5");
    expect(run.stdout).toContain("grep");
    expect(run.stdout).toContain("empty results");
    expect(run.stdout).toContain("p95 latency");
    expect(existsSync(run.out)).toBe(true);
  });

  it("run --json emits a structured report", async () => {
    const cwd = mkdtempSync(join(tmpdir(), "lcm-bench-"));
    tempDirs.push(cwd);
    await seedProject(cwd);
    await buildBench({ cwd, n: 5, seed: 7 });

    const run = await runBench({ cwd, k: 5, json: true });
    expect(run.exitCode).toBe(0);
    const report = JSON.parse(run.stdout) as {
      total: number;
      searchHitRate: number;
      grepHitRate: number;
      emptyRate: number;
      p95LatencyMs: number;
    };
    expect(report.total).toBeGreaterThan(0);
    expect(report.searchHitRate).toBeGreaterThanOrEqual(0);
    expect(report.grepHitRate).toBeGreaterThanOrEqual(0);
    expect(report.emptyRate).toBeGreaterThanOrEqual(0);
  });

  it("run fails cleanly when no benchmark file exists", async () => {
    const cwd = mkdtempSync(join(tmpdir(), "lcm-bench-"));
    tempDirs.push(cwd);
    await seedProject(cwd);
    const run = await runBench({ cwd });
    expect(run.exitCode).toBe(1);
    expect(run.stdout).toContain("lcm bench build");
  });

  it("mechanical questions never focus on sentence-initial filler words", async () => {
    const cwd = mkdtempSync(join(tmpdir(), "lcm-bench-"));
    tempDirs.push(cwd);
    await seedProject(cwd);
    const build = await buildBench({ cwd, n: 20, seed: 3 });
    const bench = JSON.parse(readFileSync(build.out, "utf-8")) as BenchFile;
    const filler = /\b(The|How|They|This|What|Why|When|Where|Do|Does|Make|Operations|For)\b/;
    for (const q of bench.queries) {
      expect(
        filler.test(q.question.replace(/^(what|how|why) (did|do|was|were) we \w+( the| around| about)?/i, "")),
        `question "${q.question}" focuses on a filler word`,
      ).toBe(false);
    }
  });

  it("questions never echo their own prompt verbatim", async () => {
    const cwd = mkdtempSync(join(tmpdir(), "lcm-bench-"));
    tempDirs.push(cwd);
    await seedProject(cwd);
    const build = await buildBench({ cwd, n: 5, seed: 3 });
    const bench = JSON.parse(readFileSync(build.out, "utf-8")) as BenchFile;
    for (const q of bench.queries) {
      // The question must be a paraphrase, not a copy of the prompt.
      expect(q.question).not.toBe(q.prompt);
      expect(q.prompt).not.toContain(q.question);
    }
  });

  it("never samples a prompt that occurs in more than one session", async () => {
    const cwd = mkdtempSync(join(tmpdir(), "lcm-bench-"));
    tempDirs.push(cwd);
    await seedProject(cwd);
    const shared = "The Kubernetes ingress controller keeps dropping websocket upgrades after a rolling restart.";
    await addSessions(cwd, [
      { sessionId: "sess-dup-a", prompt: shared },
      { sessionId: "sess-dup-b", prompt: shared },
    ]);

    const build = await buildBench({ cwd, n: 20, seed: 7 });
    expect(build.exitCode, build.stdout).toBe(0);
    const bench = JSON.parse(readFileSync(build.out, "utf-8")) as BenchFile;
    expect(bench.queries.some((q) => q.prompt === shared)).toBe(false);
    expect(bench.queries.length).toBeGreaterThan(0);
  });

  it("counts only sessions the sampler can draw from as repeats", async () => {
    const cwd = mkdtempSync(join(tmpdir(), "lcm-bench-"));
    tempDirs.push(cwd);
    await seedProject(cwd);
    // Unique among scorable sessions: the second copy lives in a conversation
    // with no session id, which buildBench never samples.
    const unique = "The Redis eviction policy is dropping hot keys under memory pressure and the cache hit ratio collapsed overnight.";
    await addSessions(cwd, [
      { sessionId: "sess-cache", prompt: unique },
      { sessionId: "", prompt: unique },
    ]);

    const build = await buildBench({ cwd, n: 20, seed: 7 });
    expect(build.exitCode, build.stdout).toBe(0);
    const bench = JSON.parse(readFileSync(build.out, "utf-8")) as BenchFile;
    expect(bench.queries.some((q) => q.prompt === unique)).toBe(true);
  });

  it("treats prompts differing only in surrounding whitespace as the same evidence", async () => {
    const cwd = mkdtempSync(join(tmpdir(), "lcm-bench-"));
    tempDirs.push(cwd);
    await seedProject(cwd);
    const shared = "The Kubernetes ingress controller keeps dropping websocket upgrades after a rolling restart.";
    await addSessions(cwd, [
      { sessionId: "sess-ws-a", prompt: shared },
      { sessionId: "sess-ws-b", prompt: `${shared}\n` },
    ]);

    const build = await buildBench({ cwd, n: 20, seed: 7 });
    expect(build.exitCode, build.stdout).toBe(0);
    const bench = JSON.parse(readFileSync(build.out, "utf-8")) as BenchFile;
    expect(bench.queries.some((q) => q.prompt.trim() === shared)).toBe(false);
  });

  it("groups repeats the same way on both sides of the trim", async () => {
    const cwd = mkdtempSync(join(tmpdir(), "lcm-bench-"));
    tempDirs.push(cwd);
    await seedProject(cwd);
    // A non-breaking space: `String.trim` strips it, SQLite's TRIM does not.
    // Both sides must agree, or the lookup key can never equal the group key.
    // Identical text in both sessions, so SQLite groups them under a key that
    // still carries the non-breaking space. `String.trim` would strip it and
    // look up a key that key can never equal.
    const shared = "\u00a0The Stripe reconciliation job double-charged annual plans during the timezone migration.\u00a0";
    await addSessions(cwd, [
      { sessionId: "sess-nbsp-a", prompt: shared },
      { sessionId: "sess-nbsp-b", prompt: shared },
    ]);

    const build = await buildBench({ cwd, n: 20, seed: 7 });
    expect(build.exitCode, build.stdout).toBe(0);
    const bench = JSON.parse(readFileSync(build.out, "utf-8")) as BenchFile;
    expect(bench.queries.length).toBeGreaterThan(0);
    // Neither copy is unique evidence, so neither may be sampled as if it were.
    expect(bench.queries.some((q) => q.prompt.includes("Stripe reconciliation"))).toBe(false);
  });

  it("matches a labelled session that carries stray whitespace", async () => {
    const cwd = mkdtempSync(join(tmpdir(), "lcm-bench-"));
    tempDirs.push(cwd);
    await seedProject(cwd);
    const file = join(cwd, "manual.json");
    const question = "Why did we choose SQLite for the memory daemon?";
    writeFileSync(file, JSON.stringify({ version: 1, queries: [
      { id: "spaced", sessionId: " sess-storage ", prompt: question, question, generator: "manual" },
    ] }));

    const run = await runBench({ cwd, benchFile: file, k: 5, json: true });
    expect(run.exitCode, run.stdout).toBe(0);
    expect(JSON.parse(run.stdout).searchHitRate).toBe(1);
  });

  it("names the real problem when the benchmark exists but does not parse", async () => {
    const cwd = mkdtempSync(join(tmpdir(), "lcm-bench-"));
    tempDirs.push(cwd);
    await seedProject(cwd);
    const file = join(cwd, "broken.json");
    writeFileSync(file, '{ "version": 1, "queries": [ }');

    const run = await runBench({ cwd, benchFile: file });
    expect(run.exitCode).toBe(1);
    expect(run.stdout).toContain("Could not read the benchmark");
    // Never the advice whose remedy would overwrite the file being fixed.
    expect(run.stdout).not.toContain("lcm bench build");
  });

  it("never samples harness boilerplate as a prompt", async () => {
    const cwd = mkdtempSync(join(tmpdir(), "lcm-bench-"));
    tempDirs.push(cwd);
    await seedProject(cwd);
    const boilerplate = "The user doesn't want to proceed with this tool use. The tool use was rejected (eg. if it was a file edit, the new_string was NOT written to the file). STOP what you are doing and wait for the user to tell you how to proceed.";
    await addSessions(cwd, [{ sessionId: "sess-boilerplate", prompt: boilerplate }]);

    const build = await buildBench({ cwd, n: 20, seed: 3 });
    const bench = JSON.parse(readFileSync(build.out, "utf-8")) as BenchFile;
    expect(bench.queries.some((q) => q.prompt === boilerplate)).toBe(false);
  });

  it("never samples pasted tool output as a prompt", async () => {
    const cwd = mkdtempSync(join(tmpdir(), "lcm-bench-"));
    tempDirs.push(cwd);
    await seedProject(cwd);
    // `git push` output: distinctive enough to be sampled, and it carries a
    // capitalized identifier, so the generator would happily build a question from it.
    const grepOutput = "remote: Create a pull request for 'release/v0.10.0' on GitHub by visiting:\nremote: https://github.com/lossless-claude/lcm/pull/new/release/v0.10.0";
    await addSessions(cwd, [{ sessionId: "sess-tool-output", prompt: grepOutput }]);

    const build = await buildBench({ cwd, n: 20, seed: 3 });
    const bench = JSON.parse(readFileSync(build.out, "utf-8")) as BenchFile;
    expect(bench.queries.some((q) => q.prompt === grepOutput)).toBe(false);
  });

  it("counts any labelled session as a hit", async () => {
    const cwd = mkdtempSync(join(tmpdir(), "lcm-bench-"));
    tempDirs.push(cwd);
    await seedProject(cwd);
    const file = join(cwd, "manual.json");
    const query = {
      id: "multi",
      sessionId: "sess-never-returned",
      prompt: "Why did we choose SQLite for the memory daemon?",
      question: "Why did we choose SQLite for the memory daemon?",
      generator: "manual",
    };

    writeFileSync(file, JSON.stringify({ version: 1, queries: [query] }));
    const single = await runBench({ cwd, benchFile: file, k: 5, json: true });
    expect(JSON.parse(single.stdout).searchHitRate).toBe(0);

    writeFileSync(file, JSON.stringify({ version: 1, queries: [{ ...query, sessionIds: ["sess-storage"] }] }));
    const multi = await runBench({ cwd, benchFile: file, k: 5, json: true });
    expect(JSON.parse(multi.stdout).searchHitRate).toBe(1);

    writeFileSync(file, JSON.stringify({ version: 1, queries: [{ ...query, sessionIds: [" "] }] }));
    expect((await runBench({ cwd, benchFile: file })).stdout).toContain("sessionIds must be a list");
  });

  it("scores a question's pivotQuery the way lcm_search does: added to the question", async () => {
    const cwd = mkdtempSync(join(tmpdir(), "lcm-bench-"));
    tempDirs.push(cwd);
    await seedProject(cwd);
    const file = join(cwd, "manual.json");
    const query = {
      id: "pivot",
      sessionId: "sess-rollback",
      prompt: "revertemos a publicação",
      question: "revertemos a publicação desta manhã?",
      generator: "manual",
    };

    writeFileSync(file, JSON.stringify({ version: 1, language: "pt-BR", queries: [query] }));
    const alone = JSON.parse((await runBench({ cwd, benchFile: file, k: 5, json: true })).stdout);
    expect(alone.searchHitRate).toBe(0);

    writeFileSync(file, JSON.stringify({ version: 1, language: "pt-BR", queries: [{ ...query, pivotQuery: "why did we roll back this morning's release?" }] }));
    const withPivot = JSON.parse((await runBench({ cwd, benchFile: file, k: 5, json: true })).stdout);
    expect(withPivot.searchHitRate).toBe(1);

    writeFileSync(file, JSON.stringify({ version: 1, queries: [{ ...query, pivotQuery: 42 }] }));
    expect((await runBench({ cwd, benchFile: file })).stdout).toContain("pivotQuery must be a string");
  });

  it("prepares pivotQuery under the benchmark's own pivotLanguage instead of the configured default", async () => {
    const cwd = mkdtempSync(join(tmpdir(), "lcm-bench-"));
    tempDirs.push(cwd);
    await seedProject(cwd);
    const file = join(cwd, "manual.json");
    const query = {
      id: "pivot-lang",
      sessionId: "sess-rollback",
      prompt: "revertemos a publicação",
      question: "revertemos a publicação desta manhã?",
      // "release" is in sess-rollback's content; "quux" is nowhere in the corpus.
      pivotQuery: "release quux",
      generator: "manual",
    };

    // No pivotLanguage recorded: falls back to the configured default ("en"),
    // which has no pack, so "release" is searched and finds sess-rollback.
    writeFileSync(file, JSON.stringify({ version: 1, language: "pt-BR", queries: [query] }));
    const withDefault = JSON.parse((await runBench({ cwd, benchFile: file, k: 5, json: true })).stdout);
    expect(withDefault.searchHitRate).toBe(1);

    // A pack only the file's own pivotLanguage ("xx") would apply: it treats
    // "release" as a function word, leaving only the nonsense "quux".
    mkdirSync(dirname(languagePackPath(paths, "xx")), { recursive: true });
    writeFileSync(languagePackPath(paths, "xx"), JSON.stringify({ version: 1, tag: "xx", stopwords: ["release"], generatedAt: new Date().toISOString() }));
    invalidateLanguagePacks();

    writeFileSync(file, JSON.stringify({ version: 1, language: "pt-BR", pivotLanguage: "xx", queries: [query] }));
    const withStored = JSON.parse((await runBench({ cwd, benchFile: file, k: 5, json: true })).stdout);
    expect(withStored.searchHitRate).toBe(0);
  });

  it("gives search enough rows to fill every session slot the grep column fills", async () => {
    const cwd = mkdtempSync(join(tmpdir(), "lcm-bench-"));
    tempDirs.push(cwd);
    await seedProject(cwd);
    // Six sessions on the same subject, each with several matching turns, so a
    // row budget spent inside one session starves the others of a slot.
    await addSessions(cwd, Array.from({ length: 6 }, (_, i) => ({
      sessionId: `sess-quota-${i}`,
      prompt: [
        `The nightly quota reconciliation job overshot its budget again on shard ${i} and paged the on-call engineer.`,
        `Quota reconciliation paged us twice more on shard ${i}; the budget alarm keeps firing before the job finishes.`,
        `We raised the quota budget for shard ${i} and the reconciliation job stopped paging, but it still overshoots.`,
      ],
    })));
    const file = join(cwd, "manual.json");
    const question = "quota reconciliation budget shard paged";
    writeFileSync(file, JSON.stringify({ version: 1, queries: [
      { id: "wide", sessionId: "sess-quota-0", prompt: question, question, generator: "manual" },
    ] }));

    const run = await runBench({ cwd, benchFile: file, k: 5 });
    expect(run.exitCode, run.stdout).toBe(0);
    const { outcomes } = JSON.parse(readFileSync(run.out, "utf-8")) as { outcomes: Array<{ searchTopK: string[] }> };
    expect(outcomes[0].searchTopK).toHaveLength(5);
  });

  it("cleans up the temp ripgrep directory even when connection acquisition throws", async () => {
    const cwd = mkdtempSync(join(tmpdir(), "lcm-bench-"));
    tempDirs.push(cwd);
    await seedProject(cwd);
    const file = join(cwd, "manual.json");
    writeFileSync(file, JSON.stringify({ version: 1, queries: [
      { id: "test", sessionId: "sess-storage", prompt: "test", question: "Test question?", generator: "manual" },
    ] }));

    const testError = new Error("Connection acquisition failed");

    // Captured, not counted: a set diff alone would also pass if the run never created a
    // directory at all, which is the one thing this regression must not accept.
    // Scoped to this process: another run's `lcm-bench-rg-*` directory in the shared temp
    // root must not be mistaken for ours.
    const rgPrefix = `lcm-bench-rg-${process.pid}-`;
    const rgDirsBefore = new Set(readdirSync(tmpdir()).filter((name) => name.startsWith(rgPrefix)));
    let created: string | undefined;
    vi.mocked(getLcmConnection).mockImplementationOnce(() => {
      created = readdirSync(tmpdir())
        .filter((name) => name.startsWith(rgPrefix))
        .find((name) => !rgDirsBefore.has(name));
      throw testError;
    });

    const run = await runBench({ cwd, benchFile: file });

    expect(run.exitCode).toBe(1);
    expect(run.stdout).toContain("Connection acquisition failed");
    expect(created).toBeDefined();
    expect(existsSync(join(tmpdir(), created!))).toBe(false);
  });
});
