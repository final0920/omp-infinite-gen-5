# Compaction shadow artifacts

Shadow measurement stores alternative compaction documents beside native's result.
It does not install a document, change restore or regenerate the DAG. The opt-in
function hook runs model arms; background lifetime and fork/native concurrency
require verification in the engine.

See [compaction header jobs](compaction-header.md) for the document, version-2
schema and executor rules. The shadow hook preserves native compaction.
Version-2 arms persist per-item citation resolution without changing shadow
`answered` outcomes; the live acceptance predicate refuses missing or ambiguous
references. Human messages are never removed from excerpts by a classifier.

## Shadow hook

Plugin `userConfig.compactionShadow` defaults to `false`. While off, there are no
shadow requests or model calls. While enabled, it incurs substantial extra model
spending and uses a separate shadow account under the existing
`sessionSummarizerMaxOutputTokens` limit. Ordinary summaries retain their full
allowance regardless of shadow spending/reservations. Unknown shadow usage is
recorded as `usageUnknown` and refuses later shadow arms with that reason, without
pushing ordinary jobs onto their cap or fallback provider. Leaf and
condensed summaries remain on the configured pipeline.

Only real main-session manual, auto and plugin cuts are admitted. Precompute,
subagent/fork and dedicated worker loops pass through; A cannot recursively sample
its own compaction. The append observer remembers the last model-visible UUID and
advances only for stored rows and resets on clear, resume, branch and session end.
Pending/denied/rejected appends never become the boundary; completion order cannot
restore a rejected predecessor. Unavailable boundaries are recorded
without guessing. Entry freezes the observed boundary, session/cwd/model, trigger, instructions
and all original engine messages before awaiting the host. The pending cut is registered with its captured lifecycle epoch before admission
awaits the transport, and rechecks that epoch after admission returns and before
starting any arm. A changed epoch records cancelled admission without arm calls or
arm records; native pairing retains that stage in `shadowAdmission`. Cut nonce and snapshot hash bind
every asynchronous callback, independently of later session changes.

The hook awaits admission, calls the original `next(e)` exactly once unchanged,
awaits native pairing, and returns the identical native object. Admission and
pairing each have one fixed 2000 ms deadline covering every prerequisite and HTTP,
raced with abort. Expiry allows no admission arms; unavailable storage is recorded
in diagnostics without a fresh wait. Foreground requests make one attempt and
late prerequisites cannot advance to a new transport stage. A starts before
native; B/C are owned background tasks waiting for the native remainder. No model
completion or arm delivery is awaited after native returns. Failure/refusal stays
in diagnostics or artifact outcomes and never replaces native. Native rejection is
re-thrown unchanged after recording it. Abort/session end prohibit queued provider calls and record unstarted arms.
Already-running calls retain the host's eventual outcome and usage; a lost promise
leaves an incomplete cut rather than a fabricated terminal result. Background
promise survival is not established
by ownership in a module registry.

Summary extraction requires exactly one new message at index zero relative to
unique original handles. The remaining descriptors must match original handles,
roles and text in increasing order. Missing or ambiguous correspondence records
`native-summary-unverified` or `native-tail-unverified` with safe observed message
projections and candidate indices. It supplies no guessed remainder to B/C. Known native usage and token counts
remain recorded even when extraction is ambiguous.
A uniquely matching compaction append supplies the observed summary UUID; duplicate
matches leave it unknown. Hook-observed native text is preserved exactly, including
whitespace, and its pre-scrub hash/length support exact historical JSONL parity.
A live paired cut must verify text equality before cross-source evaluation is trusted.

`prepare_header: true` on admission requests the daemon's C3 fork prompt/evidence;
on verified native delivery it requests the common complete prompt/evidence.
Admission prepares its header job before creating the cut; a preparation failure
creates no manifest or snapshot in the shadow namespace. Both
use the frozen window and current scrubbing rules. A receives extraction rules and
excerpts; B/C receive identical window/tail input and equal output allowances. All
three documents use excerpts, working-state header, yielding window, engine tail.
The daemon renders and persists answered version-2 documents with targets,
overflow and elision metadata. It resolves citations again against frozen evidence;
missing/ambiguous citations retain an `answered` shadow outcome. Future installation
must use `allCitationsResolved` before accepting a header.

Arms retain separate queue and model durations, setup/native/pairing/total-hook
measurements, four exact usage counters, conservative budget state and uncapped
fork overshoot. Pairing/storage failures are unconfirmed or unavailable, never
invented zero cost. Transport retries reuse frozen results rather than regenerate
models. Provider error bodies and arbitrary engine tool/media objects are omitted.

## Admission and storage

The authenticated daemon routes are `POST /compaction-shadow/start`, `/native` and
`/arm`. Start takes `cwd`, `session_id`, a nonce `cut_id`, `boundary_uuid`, `model`,
`trigger` (`manual`, `auto`, `plugin`) and optional `instructions`, `transcript_path`
and `engine_messages`. The transcript must identify the requested session. Capture
must be verified, complete and end at the specified model-visible UUID.

Admission snapshots the current complete window and its exact lineage under the
project mutation lease, preserving all raw roles. It rejects unavailable coverage,
post-cut content, source changes and windows beyond the existing 65536-byte bound.
It does not run a summary sweep. Native PreCompact continues using its configured
pipeline. The source index uses unique role/text matches for UUID/origin evidence;
ambiguous UUIDs remain unknown instead of being assigned by counting. Origin may
be retained when all matching source rows agree.

Each cut lives under `projects/<project-id>/compaction-shadow/<cut-id>/` in the lcm
home, independently of episodic storage. `manifest.json` records cut identity,
source boundary, model, snapshot/scrubbing hashes, timestamps and expected arms.
`snapshot.json` freezes captured originals, the window/coverage and safe engine
descriptors. `native.json` preserves observed summary text and tail, a pre-scrub text
hash/byte count, optional usage and timing. `arm-<A|B|C>-<attempt-id>.json` records
header/output, input/prompt hashes, outcome, model, timing and usage attempts.
Arm records optionally preserve HTTP status, a bounded API error kind and known
completion `maxTokens`/`effort`; provider error bodies are not stored. A failed arm
is an experimental outcome, not a reason to regenerate another model's output.

Native/arm delivery takes `cwd`, `session_id`, `cut_id`, `snapshot_hash` and `record`;
arm delivery also takes `arm` and `attempt_id`. Usage retains uncached input, output,
cache-read and cache-creation counters. Missing usage or cost is unknown, never zero.
Identical retries are accepted; conflicting results or identities are rejected.
`requestIdentityHash` binds the raw cwd, cut nonce, session, boundary, model,
trigger and instruction presence/value, plus a digest of raw engine-message
roles, text, handles and order before redaction. Its SHA-256 digest
is stored beside the identifiers and scrubbed instructions. A retry cannot change
those inputs, even when instructions redact to the same text. Legacy cuts without this digest remain
readable for evaluation and expiry, but admission retries require a new cut nonce.
Independent files and atomic publication preserve out-of-order completion. Once
native and all three arms have records, the manifest is complete even when an arm
reports a non-answer.

A native tail must resolve each handle uniquely to the frozen engine messages,
in strictly increasing order, with identical roles and text after both copies
are scrubbed under the current rules. Empty tails and ordered subsequences are
allowed. Missing, unknown, ambiguous, reused or reordered handles and changed
content are conflicts: native delivery returns HTTP 409 before publication.
The evaluator applies the same check to legacy stored tails; a conflicting cut
is counted invalid and skipped, even when its native summary text matches JSONL.

Free text from transcripts, the instructions and model outputs is scrubbed with
Capture's current global/project rules, including frozen windows and historical
summary text. Scrubbing the shadow copy
does not rewrite stored DAG summaries. Engine descriptors
allow only role, text and opaque handle; arbitrary result objects and media bytes
are omitted. Correlation identifiers are 1–140 ASCII letters, digits, underscores
or hyphens, and are rejected if current scrubbing rules flag them. Accepted handles,
session/cut/boundary/source/attempt identifiers, supersession ids and source pointers
retain their exact values. Source pointers must use `[raw:<cut-id>:<positive-id>]`
or `[sum:<summary-id>]` with a `sum_` prefix; quoted evidence uses `{ "quote": "..." }`. Caller-supplied
digests and error kinds retain their stricter shapes and are also checked for
sensitive values. Identifiers, including model names, handles, session, cut and
boundary ids, are validated and never scrubbed. Model names in the manifest,
requested model and usage attempts share `^[A-Za-z0-9][A-Za-z0-9._:/-]{0,63}$`
and retain their values even when sensitive patterns match them.
Artifacts have private file/directory permissions. Nothing uploads
them; later model calls through the session client can still transmit prompts.

Cuts expire after 30 days. Startup and admission prune expired cuts in bounded
update batches, only in this namespace, and mark another daemon owner's pending
cuts incomplete. Delivery to an expired cut is rejected. A local evaluation export
has its own lifetime. Recovery checks every descended directory with `lstat`,
including project, shadow and cut directories, and skips links. Every recursive
removal, including staging cleanup, rechecks the directory chain and verifies its
real path is strictly inside the lcm home's real projects directory. Recovery
also checks every file it reads with `lstat`, including project `meta.json` and
cut manifests, and skips links.

## Corpus policy

`bench-corpora.json` is an evaluation policy, not a prerequisite for shadow mode.
Admission uses a valid existing policy to skip excluded projects before Capture;
the response is HTTP 200 with `{ admitted: false, reason: "excluded" }`.
A missing policy leaves admission available. An unreadable or invalid policy
refuses admission before Capture with HTTP 200 and
`{ admitted: false, reason: "policy-unavailable" }` and emits a
`compaction-shadow.policy_unavailable` warning in the daemon log.
Corpus discovery skips non-directory project entries and unreadable metadata.
Paths and cwd substrings use the shared canonical, case-insensitive benchmark
rules. A candidate cwd can resolve a substring policy before its first capture.

The offline evaluator requires a valid explicit policy; present exclusion and
holdout fields must be lists, including when empty. Null is invalid. Projects are
excluded from metadata before loading transcript payloads or artifacts. The
evaluator scans root metadata on every transcript row, including after the cut,
without decoding message payloads. A missing `cwd` inherits the previous row's;
a model-visible row with no established ownership is ineligible. Any recorded
excluded cwd disqualifies the whole session, including paired shadow cuts. Holdout
rows also reserve the session. Every recorded row session id must be a UUID and
match the supplied session label before exclusion is acted on; a mismatch counts
as an invalid source. Exclusions block the session ids actually recorded by the
transcript, including when its label is wrong. At least one recorded session id
is required. A directory or manifest label cannot establish
ownership because Claude directory names can collide. Exclusions take precedence over holdout.
Missing or unresolvable corpus identity is not eligible for evaluation.

## Phase-1 triage

The repository tool `scripts/eval-compaction-shadow.mts` reads built evaluator
modules, frozen shadow cuts and native JSONL `isCompactSummary` records. It makes
no model, daemon, retrieval or database call. See configuration for invocation.
Sampling is seeded by project, session and cut, targeting at least 30 cuts across
3 allowed projects. Smaller samples are reported as insufficient. Existing
historical cuts have no invented arms or reconstructed current DAG window.

Historical originals require explicit `parentUuid` ancestry before the summary.
Every ancestor must precede its child in transcript row order;
compact boundaries and prior summary rows are not probe sources. Unresolvable,
cyclic or incomplete transcripts are invalid sources. Source UUID/boundary and
pre-scrub hash/byte count pair hook-observed native text with decoded JSONL text.
Whitespace is significant; a mismatch disables native comparison for that cut.

Every identifier exported by the harness is validated before measurements and
probes are written. Session, boundary, summary-message and original-row UUIDs use
UUID syntax; opaque cut/attempt/supersession identifiers, digest fields, model
names and source pointers retain their respective shapes. A malformed identifier
counts as an invalid source and that source is skipped. Identifiers are never
scrubbed; supersession ids retain their provenance failures when rules match them.

Every probe preserves a verbatim real user message and source address before the
cut. Exact quote retention is a recall proxy. A versioned lexical classifier
checks paths, issue numbers, summary ids, code identifiers and recognized command
forms against captured originals; pointer resolution uses frozen raw/DAG lineage.
Directive paraphrases fail the verbatim check. A valid generated summary pointer
can still fail the strict literal identifier floor; these results are separate.
Presence does not prove relationships, negation or task status.

Outputs are `selection.json`, `probes.jsonl`, `metrics.json`, `report.md` and a hash
`manifest.json`. Current Capture rules re-scrub source text without rewriting
identity, role, usage or outcome metadata. Sizes describe scrubbed text, not the
complete hidden tool/media state kept by an opaque engine handle.

Optional prices have a `version` and `models` map keyed by reported requested model;
each model has `inputPerMillion`, `outputPerMillion`, `cacheReadPerMillion` and
`cacheCreationPerMillion`. Estimates retain failed-attempt spending and exact cache
counters. The primary usage describes the arm call once; `usageAttempts` adds
only other attempts, never a duplicate of the primary call. Hook overhead excludes
native duration and reports p50/p95 over recorded cuts; absent or conflicting
timings remain unknown. Unknown usage/model/rates remain unknown. Native cost needs reported
charge evidence; it is not inferred from another arm's model. DAG/retrieval cost
attribution is unavailable, so this tool cannot establish an amortized-cost gate.

Continuation scoring returns `not-run/phase-2`, with the frozen rubric hash and
version. Phase 2 requires frozen source/DAG/retrieval/environment, held-out sessions
and human calibration. Superiority and default-on are not phase-1 conclusions.
