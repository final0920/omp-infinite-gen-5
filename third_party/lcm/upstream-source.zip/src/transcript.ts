import { isWorkerClaim, workerPayloadJobIds } from "./worker-markers.js";
import { isCompactionContext } from "./compaction-context.js";
import { transcriptToolInvocation, transcriptToolResult, type TranscriptToolCall } from "./tool-calls.js";
import { readFileSync } from "node:fs";

/** Bump when the Claude parser changes the rows or fields a transcript yields. */
export const CLAUDE_PARSER_SHAPE = "claude-v4";

interface ContentBlock {
  type?: string;
  text?: string;
  name?: string;
  is_error?: boolean;
  content?: string | ContentBlock[];
  /** Tool input, selected separately from the unchanged message rows. */
  input?: Record<string, unknown>;
  tool_use_id?: string;
  /** `tool_use` id — the same id a PostToolUse hook payload carries as `tool_use_id`. */
  id?: string;
}

interface TranscriptLine {
  sessionId?: unknown;
  isSidechain?: boolean;
  attachment?: { type?: string; url?: unknown };
  timestamp?: unknown;
  type?: string;
  message?: {
    role?: string;
    content?: string | ContentBlock[];
    /** The model that produced this assistant turn, including any tool calls in it. */
    model?: string;
  };
}

export type SessionUrlDeclaration = { sessionId: string; url: string };

/**
 * A skill invocation or slash command, recorded as structure rather than as a
 * substring of a message body. Never the expanded skill prompt or command
 * output — that stays in the message's own content.
 */
export type MessagePart =
  | { type: "skill"; name: string; args: string | null }
  | { type: "command"; name: string; args: string | null };

export interface ParsedMessage {
  role: string;
  content: string;
  tokenCount: number;
  /** Transcript record time; absent when the source provides no valid timestamp. */
  eventAt?: string;
  parts?: MessagePart[];
  workerClaims?: string[];
  /** A successful claim's result: the call it answers and the job id it carries. */
  workerPayloads?: WorkerPayload[];
}

/** Accept only an explicit timestamp with a timezone; never use the current clock. */
export function transcriptEventTime(value: unknown): string | undefined {
  if (typeof value !== "string" || !/^\d{4}-\d{2}-\d{2}T.*(?:Z|[+-]\d{2}:\d{2})$/i.test(value)) return undefined;
  const time = Date.parse(value);
  return Number.isFinite(time) ? new Date(time).toISOString() : undefined;
}

export type WorkerPayload = { callId: string; jobId: string };

function extractText(content: string | ContentBlock[] | unknown): string {
  if (typeof content === "string") return content;
  if (Array.isArray(content)) {
    return content
      .map((b: ContentBlock) => {
        if (b.type === "text" && typeof b.text === "string") return b.text;
        if (b.type === "tool_result") return extractText(b.content);
        return "";
      })
      .filter(Boolean)
      .join("\n");
  }
  return "";
}

export function estimateTokens(text: string): number {
  return Math.max(1, Math.ceil(text.length / 4));
}

/** Marks a tool result the tool itself reported as failed. */
export const TOOL_ERROR_MARKER = "[tool error]";

function blocksOf(content: string | ContentBlock[] | undefined): ContentBlock[] {
  return Array.isArray(content) ? content : [];
}

const hasProse = (blocks: ContentBlock[]): boolean =>
  blocks.some(b => b.type === "text" && typeof b.text === "string" && b.text.trim() !== "");

/**
 * The role to store an entry under.
 *
 * The transcript's own `role` says who the turn belongs to, not who produced
 * the text: a tool result comes back as a `user` turn, and ingesting it that
 * way tells a later reader the user said it. So the blocks decide.
 *
 * Prose wins. An entry that mixes human text with a tool result is human —
 * measured, that combination occurs once in 8749 entries, and calling it a
 * tool log would lose a real user message to save almost nothing.
 */
function roleOf(entryRole: string, content: string | ContentBlock[] | undefined): string {
  if (typeof content === "string") return entryRole;
  const blocks = blocksOf(content);
  if (blocks.length === 0 || hasProse(blocks)) return entryRole;
  if (blocks.some(b => b.type === "tool_result" || b.type === "tool_use")) return "tool";
  return entryRole;
}

/**
 * What to store for an entry that holds no prose.
 *
 * A `tool_use` keeps its name in the message row; selected inputs travel beside
 * it as tool-call structure. A `tool_result` keeps its output and its failure
 * flag as a searchable marker. Tool-call metadata never changes these rows.
 */
function toolContent(blocks: ContentBlock[], legacyToolShape = false): string {
  const lines: string[] = [];
  for (const block of blocks) {
    if (block.type === "tool_use") {
      if (!legacyToolShape) lines.push(typeof block.name === "string" && block.name ? block.name : "tool_use");
      continue;
    }
    if (block.type !== "tool_result") continue;
    const output = extractText(block.content);
    lines.push(block.is_error && !legacyToolShape ? `${TOOL_ERROR_MARKER}\n${output}` : output);
  }
  return lines.filter(line => line.trim() !== "").join("\n");
}

/**
 * A `Skill` tool_use already carries its name in a structured field — the
 * expansion that follows is what arrives as text, not the invocation itself.
 */
function extractSkillParts(blocks: ContentBlock[]): MessagePart[] {
  const parts: MessagePart[] = [];
  for (const block of blocks) {
    if (block.type !== "tool_use" || block.name !== "Skill") continue;
    const skill = typeof block.input?.skill === "string" ? block.input.skill.trim() : "";
    if (!skill) continue;
    const args = typeof block.input?.args === "string" ? block.input.args.trim() : "";
    parts.push({ type: "skill", name: skill, args: args || null });
  }
  return parts;
}

const COMMAND_NAME_RE = /<command-name>([^<]*)<\/command-name>/;
const COMMAND_ARGS_RE = /<command-args>([^<]*)<\/command-args>/;

/** A slash command block quoted inside a code fence is documentation, not an invocation. */
function stripCodeFences(text: string): string {
  return text.replace(/```[\s\S]*?```/g, "");
}

export function extractCommandParts(text: string): MessagePart[] {
  const searchable = stripCodeFences(text);
  const name = searchable.match(COMMAND_NAME_RE)?.[1]?.trim();
  if (!name) return [];
  const args = searchable.match(COMMAND_ARGS_RE)?.[1]?.trim() ?? "";
  return [{ type: "command", name, args: args || null }];
}

/**
 * The model that issued each tool call in a Claude transcript, keyed by the
 * `tool_use` block's id — the same id a PostToolUse hook payload carries as
 * `tool_use_id`. Claude's hook payload carries no model, so the daemon calls
 * this at ingest to backfill it on the events already recorded for the call.
 */
export function extractToolUseModels(transcriptPath: string): Map<string, string> {
  let raw: string;
  try {
    raw = readFileSync(transcriptPath, "utf-8");
  } catch {
    return new Map();
  }

  const models = new Map<string, string>();
  for (const line of raw.split("\n")) {
    const trimmed = line.trim();
    if (!trimmed) continue;
    try {
      for (const [id, model] of toolUseModels(JSON.parse(trimmed))) models.set(id, model);
    } catch {
      // skip malformed lines
    }
  }
  return models;
}

function toolUseModels(obj: TranscriptLine): Map<string, string> {
  const models = new Map<string, string>();
  const model = obj.message?.model;
  if (obj.message?.role !== "assistant" || typeof model !== "string" || !model) return models;
  for (const block of blocksOf(obj.message.content)) {
    if (block.type === "tool_use" && typeof block.id === "string" && block.id) models.set(block.id, model);
  }
  return models;
}

function claudeToolCalls(blocks: ContentBlock[], message?: ParsedMessage): TranscriptToolCall[] {
  return blocks.flatMap(block => {
    if (block.type === "tool_use" && block.id) return [transcriptToolInvocation(block.id, block.name || "tool_use", block.input, message)];
    if (block.type === "tool_result" && block.tool_use_id) return [{ ...transcriptToolResult(block.tool_use_id, "claude",
      { output: extractText(block.content), error: block.is_error }), message }];
    return [];
  });
}

/** One Claude JSONL entry; full and incremental readers use exactly the same filtering and shape. */
export function parseClaudeTranscriptRecord(record: string, toolShape: "current" | "legacy" = "current"):
  { message?: ParsedMessage; toolUseModels: Map<string, string>; toolCalls?: TranscriptToolCall[]; sessionUrlDeclaration?: SessionUrlDeclaration } {
  try {
    const obj: TranscriptLine = JSON.parse(record);
    const models = toolUseModels(obj);
    if (obj.type === "attachment") {
      const attachment = obj.attachment;
      if (!obj.isSidechain && attachment?.type === "remote_session_change" &&
          typeof obj.sessionId === "string" && typeof attachment.url === "string" && attachment.url.length > 0) {
        return { toolUseModels: models, sessionUrlDeclaration: { sessionId: obj.sessionId, url: attachment.url } };
      }
      return { toolUseModels: models };
    }
    const entryRole = obj.message?.role;
    if (!entryRole || !["user", "assistant", "system"].includes(entryRole)) return { toolUseModels: models };
    // One transcript entry stays one message, whatever it holds.
    const blocks = blocksOf(obj.message?.content);
    const role = roleOf(entryRole, obj.message?.content);
    const content = role === "tool" ? toolContent(blocks, toolShape === "legacy") : extractText(obj.message?.content);
    if (!content.trim()) return { toolUseModels: models, toolCalls: claudeToolCalls(blocks) };
    // Generated envelopes are control rows; their source content is already captured.
    if (role === "user" && isCompactionContext(content) &&
        (typeof obj.message?.content === "string" || blocks.every(block => block.type === "text"))) return { toolUseModels: models };
    const parts = [...extractSkillParts(blocks), ...extractCommandParts(content)];
    const workerClaims = blocks.filter(block => block.type === "tool_use" && isWorkerClaim(block.name, block.input))
      .map(block => block.id).filter((id): id is string => Boolean(id));
    const workerPayloads = blocks.filter(block => block.type === "tool_result" && !block.is_error && block.tool_use_id)
      .flatMap(block => workerPayloadJobIds(block.content).map(jobId => ({ callId: block.tool_use_id!, jobId })));
    const eventAt = transcriptEventTime(obj.timestamp);
    const message: ParsedMessage = { role, content, tokenCount: estimateTokens(content), ...(eventAt ? { eventAt } : {}), ...(parts.length ? { parts } : {}),
      ...(workerClaims.length ? { workerClaims } : {}), ...(workerPayloads.length ? { workerPayloads } : {}) };
    const toolCalls = claudeToolCalls(blocks, message);
    return { message, toolUseModels: models, ...(toolCalls.length ? { toolCalls } : {}) };
  } catch {
    // Claude's existing full parser skips malformed entries.
    return { toolUseModels: new Map() };
  }
}

/** A full byte-reader snapshot reuses this seam without reading or decoding the file twice. */
export function parseTranscript(
  transcriptPath: string, toolShape: "current" | "legacy" = "current", snapshot?: ParsedMessage[],
): ParsedMessage[] {
  if (toolShape === "current" && snapshot !== undefined) return snapshot;
  let raw: string;
  try {
    raw = readFileSync(transcriptPath, "utf-8");
  } catch {
    return [];
  }

  const messages: ParsedMessage[] = [];
  for (const line of raw.split("\n")) {
    const trimmed = line.trim();
    if (!trimmed) continue;
    const { message } = parseClaudeTranscriptRecord(trimmed, toolShape);
    if (message) messages.push(message);
  }
  return messages;
}
