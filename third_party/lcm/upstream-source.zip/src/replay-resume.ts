/**
 * Durable progress for `--replay` runs (import and batch compact).
 *
 * Two tables per project DB (see db/migration.ts):
 *  - replay_manifest: the ordered session list frozen under a run_id.
 *  - replay_ledger:   one row per completed session compaction, written only
 *                     after the summary is persisted.
 *
 * Resume is the default: a new run adopts the latest manifest for its command,
 * skips ledger rows whose content fingerprint still matches, restores the
 * threaded `previousSummary` chain from the last good row, and continues.
 * State is keyed per project (cwd); a run spanning multiple projects keeps one
 * manifest + ledger set per project database.
 */

import { randomUUID } from "node:crypto";
import { existsSync, statSync } from "node:fs";
import { join } from "node:path";
import type { DatabaseSync } from "node:sqlite";
import { projectId } from "./daemon/project.js";
import { closeLcmConnection, getLcmConnection, openStandaloneLcmConnection } from "./db/connection.js";
import { runLcmMigrations } from "./db/migration.js";
import { SummaryStore } from "./store/summary-store.js";
import type { DaemonClient } from "./daemon/client.js";
import { createLcmPaths, type LcmPaths } from "./lcm-paths.js";

export type ReplayCommand = "import" | "compact";

/**
 * How a session finished. Both values mean "done, skip on resume"; they differ
 * only in whether a summary — and so a threading anchor — was produced.
 */
export type ReplayOutcome = "compacted" | "no_work";

export interface ReplayRunInfo {
  runId: string;
  command: ReplayCommand;
  model: string | null;
  createdAt: string;
}

export interface ReplayLedgerEntry {
  sessionId: string;
  position: number;
  contentFingerprint: string;
  /** Threading anchor; null when the session produced no summary. */
  summaryId: string | null;
  outcome: ReplayOutcome;
  model: string | null;
  completedAt: string;
}

type ProjectDbOpenResult =
  | { kind: "missing" }
  | { kind: "error" }
  | { kind: "ready"; db: DatabaseSync; dbPath: string };

interface ProjectPlan<T extends { sessionId: string }> {
  runId: string;
  previousRunId: string | null;
  previousModel: string | null;
  doneCount: number;
  remaining: T[];
  /** session_id → frozen manifest position (resumed projects only). */
  positions: Map<string, number>;
  restoredPreviousSummary: string | undefined;
  droppedPreviousSummary: string | undefined;
  changedSessionIds: string[];
  manifestOrder: string[];
  manifestAppends: string[];
}

export interface ReplayResumePlan<T extends { sessionId: string }> {
  /** cwd → run_id (fresh id for projects with no prior run, adopted id otherwise). */
  runIds: Map<string, string>;
  /** cwd → frozen manifest order for that project (existing or to-be-created). */
  manifests: Map<string, string[]>;
  /** cwd → session_id → manifest position, for resumed projects. */
  positions: Map<string, Map<string, number>>;
  /** cwd → newly discovered session_ids appended to adopted manifests. */
  manifestAppends: Map<string, string[]>;
  /** Projects with no prior run — caller must create their manifests. */
  freshCwds: Set<string>;
  /** Sessions to process in input order (changed, new, or previously failed). */
  remaining: T[];
  /** Sessions skipped because their ledger row fingerprint still matches. */
  doneCount: number;
  /** Model recorded on the most recently resumed run, when they differ across projects. */
  previousModel: string | null;
  /** cwd → per-project restored threaded summary content. */
  restoredPreviousSummaries: Map<string, string>;
  /** cwd → per-project dropped threaded summary content warning marker. */
  droppedPreviousSummaries: Map<string, string>;
  /** Session ids whose content changed since their ledger row. */
  changedSessionIds: string[];
}

export function replayRunId(): string {
  return randomUUID();
}

/**
 * Fingerprint for transcript content: size + mtime.
 * Transcripts are append-only, so appends move at least one of these.
 */
export function fingerprintFile(path: string): string {
  const st = statSync(path);
  return `${st.size}:${Math.floor(st.mtimeMs)}`;
}

/**
 * Fingerprint for DB-backed sessions (batch compact has no transcript path):
 * message count + total tokens change whenever the conversation grows.
 */
export function fingerprintStats(messages: number, tokens: number): string {
  return `db:${messages}:${tokens}`;
}

// A replay only needs one schema sweep per database per process; later ledger
// writes use the schema already established by the first open.
const migratedDbPaths = new Set<string>();

function openProjectDb(dbPath: string): ProjectDbOpenResult {
  if (!existsSync(dbPath)) return { kind: "missing" };
  let db: DatabaseSync | null = null;
  try {
    db = getLcmConnection(dbPath);
    if (!migratedDbPaths.has(dbPath)) {
      // The daemon may hold connections opened before the replay tables
      // existed; the sweep is additive and idempotent, so this self-heals
      // stale databases and is skipped on every later open.
      runLcmMigrations(db, { fts5Available: false });
      migratedDbPaths.add(dbPath);
    }
    db.prepare("SELECT 1 FROM replay_ledger LIMIT 1").get();
    return { kind: "ready", db, dbPath };
  } catch {
    if (db) {
      closeLcmConnection(dbPath);
    }
    return { kind: "error" };
  }
}

function closeDb(opened: ProjectDbOpenResult): void {
  if (opened.kind !== "ready") return;
  try { closeLcmConnection(opened.dbPath); } catch { /* already closed */ }
}

function projectDbPathFor(cwd: string, paths: LcmPaths): string {
  return join(paths.projectsDir, projectId(cwd), "db.sqlite");
}

type ReplayPaths = { paths?: LcmPaths; lcmDir?: string };

function replayPaths(opts: ReplayPaths): LcmPaths {
  if (opts.paths) return opts.paths;
  if (opts.lcmDir) return createLcmPaths(opts.lcmDir);
  throw new Error("replay state requires an LcmPaths storage root");
}

function loadLatestRun(db: DatabaseSync, command: ReplayCommand): ReplayRunInfo | null {
  const row = db.prepare(`
    SELECT run_id, command, model, MIN(created_at) AS created_at
    FROM replay_manifest
    WHERE command = ?
    GROUP BY run_id
    ORDER BY created_at DESC, run_id DESC
    LIMIT 1
  `).get(command) as { run_id: string; command: string; model: string | null; created_at: string } | undefined;
  if (!row) return null;
  return { runId: row.run_id, command: row.command as ReplayCommand, model: row.model, createdAt: row.created_at };
}

function loadManifestOrder(db: DatabaseSync, runId: string): string[] {
  const rows = db.prepare(
    "SELECT session_id FROM replay_manifest WHERE run_id = ? ORDER BY position ASC",
  ).all(runId) as { session_id: string }[];
  return rows.map((r) => r.session_id);
}

function loadLedger(db: DatabaseSync, runId: string): Map<string, ReplayLedgerEntry> {
  const rows = db.prepare(
    "SELECT session_id, position, content_fingerprint, summary_id, outcome, model, completed_at FROM replay_ledger WHERE run_id = ?",
  ).all(runId) as {
    session_id: string; position: number;
    content_fingerprint: string; summary_id: string | null; outcome: string;
    model: string | null; completed_at: string;
  }[];
  const map = new Map<string, ReplayLedgerEntry>();
  for (const r of rows) {
    map.set(r.session_id, {
      sessionId: r.session_id,
      position: r.position,
      contentFingerprint: r.content_fingerprint,
      summaryId: r.summary_id,
      outcome: r.outcome === "no_work" ? "no_work" : "compacted",
      model: r.model,
      completedAt: r.completed_at,
    });
  }
  return map;
}

function fetchSummaryContent(db: DatabaseSync, summaryId: string): string | undefined {
  const row = db.prepare("SELECT content FROM summaries WHERE summary_id = ?").get(summaryId) as
    | { content: string }
    | undefined;
  return row?.content;
}

/**
 * Persist a new run's manifest. Returns false, writing nothing, when the DB
 * cannot be opened; callers keep the manifest pending and retry later.
 */
export function createReplayRun(opts: {
  cwd: string;
  paths?: LcmPaths;
  lcmDir?: string;
  command: ReplayCommand;
  runId: string;
  sessions: { sessionId: string }[];
  model?: string | null;
}): boolean {
  const opened = openProjectDb(projectDbPathFor(opts.cwd, replayPaths(opts)));
  if (opened.kind !== "ready") return false;
  const { db } = opened;
  try {
    db.exec("BEGIN");
    try {
      const stmt = db.prepare(
        "INSERT INTO replay_manifest (run_id, command, position, session_id, model) VALUES (?, ?, ?, ?, ?)",
      );
      opts.sessions.forEach((s, i) => {
        stmt.run(opts.runId, opts.command, i, s.sessionId, opts.model ?? null);
      });
      db.exec("COMMIT");
      return true;
    } catch (err) {
      db.exec("ROLLBACK");
      throw err;
    }
  } catch { return false; /* resume state is best-effort — never fail the run */ }
  finally { closeDb(opened); }
}

/**
 * Append new sessions to an adopted manifest, preserving prior positions.
 * Existing (run_id, position) rows are left untouched.
 */
export function appendReplayManifestSessions(opts: {
  cwd: string;
  paths?: LcmPaths;
  lcmDir?: string;
  command: ReplayCommand;
  runId: string;
  sessions: { sessionId: string; position: number }[];
  model?: string | null;
}): void {
  if (opts.sessions.length === 0) return;
  const opened = openProjectDb(projectDbPathFor(opts.cwd, replayPaths(opts)));
  if (opened.kind !== "ready") return;
  const { db } = opened;
  try {
    db.exec("BEGIN");
    try {
      const stmt = db.prepare(
        "INSERT OR IGNORE INTO replay_manifest (run_id, command, position, session_id, model) VALUES (?, ?, ?, ?, ?)",
      );
      for (const session of opts.sessions) {
        stmt.run(opts.runId, opts.command, session.position, session.sessionId, opts.model ?? null);
      }
      db.exec("COMMIT");
    } catch (err) {
      db.exec("ROLLBACK");
      throw err;
    }
  } catch { /* resume state is best-effort — never fail the run */ }
  finally { closeDb(opened); }
}

/** Plan one project against its own database. Returns null when the DB is unusable. */
function planProject<T extends { sessionId: string }>(opts: {
  cwd: string;
  paths?: LcmPaths;
  lcmDir?: string;
  command: ReplayCommand;
  sessions: T[];
  fingerprint: (session: T) => string | null;
  restart?: boolean;
}): ProjectPlan<T> | null {
  const freshProject: ProjectPlan<T> = {
    runId: replayRunId(),
    previousRunId: null,
    previousModel: null,
    doneCount: 0,
    remaining: [...opts.sessions],
    positions: new Map(),
    restoredPreviousSummary: undefined,
    droppedPreviousSummary: undefined,
    changedSessionIds: [],
    manifestOrder: opts.sessions.map((s) => s.sessionId),
    manifestAppends: [],
  };

  const opened = openProjectDb(projectDbPathFor(opts.cwd, replayPaths(opts)));
  if (opened.kind !== "ready") return null;
  const { db } = opened;
  try {
    const prev = loadLatestRun(db, opts.command);
    if (!prev || opts.restart) {
      return freshProject;
    }

    const order = loadManifestOrder(db, prev.runId);
    const ledger = loadLedger(db, prev.runId);
    const positionOf = new Map(order.map((sid, i) => [sid, i]));
    const appended: string[] = [];
    for (const session of opts.sessions) {
      if (positionOf.has(session.sessionId)) continue;
      positionOf.set(session.sessionId, order.length);
      order.push(session.sessionId);
      appended.push(session.sessionId);
    }
    const sessionById = new Map(opts.sessions.map((session) => [session.sessionId, session]));

    const doneRows: { position: number; entry: ReplayLedgerEntry }[] = [];
    const remaining: T[] = [];
    const changedSessionIds: string[] = [];
    let seenGap = false;
    for (const sessionId of order) {
      const session = sessionById.get(sessionId);
      if (!session) continue;
      const entry = ledger.get(sessionId);
      let fp: string | null = null;
      try { fp = opts.fingerprint(session); } catch { fp = null; }
      const isDone = !seenGap && !!entry && fp !== null && entry.contentFingerprint === fp;
      if (isDone) {
        doneRows.push({ position: positionOf.get(sessionId) ?? entry.position, entry });
        continue;
      }
      seenGap = true;
      if (entry && fp !== null && entry.contentFingerprint !== fp) {
        changedSessionIds.push(sessionId);
      }
      remaining.push(session);
    }

    // Restore the threaded chain from the last done row that precedes the first
    // remaining session; if the chain was already broken there, drop it.
    const firstRemainingPos = remaining.length > 0
      ? (positionOf.get(remaining[0].sessionId) ?? Number.MAX_SAFE_INTEGER)
      : Number.MAX_SAFE_INTEGER;
    // Walk back to the most recent row that actually produced a summary. A
    // no-work session carries no anchor and is skipped over, not treated as a
    // break — it did its job, there was simply nothing to summarise.
    const anchor = doneRows
      .filter((r) => r.position < firstRemainingPos && r.entry.summaryId !== null)
      .sort((a, b) => b.position - a.position)[0];

    let restored: string | undefined;
    let dropped: string | undefined;
    if (anchor && anchor.entry.summaryId) {
      const content = fetchSummaryContent(db, anchor.entry.summaryId);
      if (content !== undefined) {
        // A genuine break is a session that compacted but whose summary was
        // never recorded. A no-work row with a null summary is not one.
        const broken = db.prepare(
          `SELECT 1 FROM replay_ledger
           WHERE run_id = ? AND position < ? AND summary_id IS NULL AND outcome = 'compacted'
           LIMIT 1`,
        ).get(prev.runId, anchor.position);
        if (broken) {
          dropped = content;
        } else {
          restored = content;
        }
      }
    }

    return {
      runId: prev.runId,
      previousRunId: prev.runId,
      previousModel: prev.model,
      doneCount: doneRows.length,
      remaining,
      positions: positionOf,
      restoredPreviousSummary: restored,
      droppedPreviousSummary: dropped,
      changedSessionIds,
      manifestOrder: order,
      manifestAppends: appended,
    };
  } catch {
    return null;
  } finally {
    closeDb(opened);
  }
}

/**
 * Compute the resume plan for a replay run, spanning every project the
 * sessions belong to. Sessions are grouped by their own cwd; each group is
 * planned against that project's database. When `restart` is set or a project
 * has no previous run, its sessions are all remaining and the caller creates a
 * fresh manifest for it (see createReplayRun).
 */
export function planReplayResume<T extends { sessionId: string; cwd: string }>(opts: {
  sessions: T[];
  paths?: LcmPaths;
  lcmDir?: string;
  command: ReplayCommand;
  fingerprint: (session: T) => string | null;
  restart?: boolean;
}): ReplayResumePlan<T> {
  const plan: ReplayResumePlan<T> = {
    runIds: new Map(),
    manifests: new Map(),
    positions: new Map(),
    manifestAppends: new Map(),
    freshCwds: new Set(),
    remaining: [],
    doneCount: 0,
    previousModel: null,
    restoredPreviousSummaries: new Map(),
    droppedPreviousSummaries: new Map(),
    changedSessionIds: [],
  };

  // Group by project, preserving input order within each group.
  const byCwd = new Map<string, T[]>();
  for (const session of opts.sessions) {
    const list = byCwd.get(session.cwd) ?? [];
    list.push(session);
    byCwd.set(session.cwd, list);
  }

  const firstInputIdxByCwd = new Map<string, number>();
  opts.sessions.forEach((session, index) => {
    if (!firstInputIdxByCwd.has(session.cwd)) firstInputIdxByCwd.set(session.cwd, index);
  });

  const remainingByCwd = new Map<string, T[]>();

  for (const [cwd, sessions] of byCwd) {
    const project: ProjectPlan<T> = planProject({
      cwd,
      paths: replayPaths(opts),
      command: opts.command,
      sessions,
      fingerprint: opts.fingerprint,
      restart: opts.restart,
    }) ?? {
      // DB unusable — treat as fresh; resume is best-effort.
      runId: replayRunId(),
      previousRunId: null,
      previousModel: null,
      doneCount: 0,
      remaining: [...sessions],
      positions: new Map<string, number>(),
      restoredPreviousSummary: undefined,
      droppedPreviousSummary: undefined,
      changedSessionIds: [],
      manifestOrder: sessions.map((s) => s.sessionId),
      manifestAppends: [],
    };

    plan.runIds.set(cwd, project.runId);
    plan.manifests.set(cwd, project.manifestOrder);
    plan.manifestAppends.set(cwd, project.manifestAppends);
    if (project.previousRunId === null) {
      plan.freshCwds.add(cwd);
      const positions = new Map<string, number>();
      project.manifestOrder.forEach((sid, i) => positions.set(sid, i));
      plan.positions.set(cwd, positions);
    } else {
      plan.positions.set(cwd, project.positions);
      plan.doneCount += project.doneCount;
      if (project.previousModel) plan.previousModel = project.previousModel;
      if (project.changedSessionIds.length > 0) plan.changedSessionIds.push(...project.changedSessionIds);
      if (project.restoredPreviousSummary !== undefined) {
        plan.restoredPreviousSummaries.set(cwd, project.restoredPreviousSummary);
      }
      if (project.droppedPreviousSummary !== undefined) {
        plan.droppedPreviousSummaries.set(cwd, project.droppedPreviousSummary);
      }
    }
    remainingByCwd.set(cwd, project.remaining);
  }

  // Keep project discovery order from input; within each project, use manifest order.
  const projectOrder = new Map<string, number>();
  let projectCursor = 0;
  for (const s of opts.sessions) {
    if (!projectOrder.has(s.cwd)) {
      projectOrder.set(s.cwd, projectCursor++);
    }
  }
  const flattenedRemaining: T[] = [];
  for (const [cwd, list] of remainingByCwd) {
    for (const session of list) flattenedRemaining.push(session);
  }
  plan.remaining = flattenedRemaining.sort((a, b) => {
    const projectRank = (projectOrder.get(a.cwd) ?? Number.MAX_SAFE_INTEGER) - (projectOrder.get(b.cwd) ?? Number.MAX_SAFE_INTEGER);
    if (projectRank !== 0) return projectRank;
    const posA = plan.positions.get(a.cwd)?.get(a.sessionId) ?? Number.MAX_SAFE_INTEGER;
    const posB = plan.positions.get(b.cwd)?.get(b.sessionId) ?? Number.MAX_SAFE_INTEGER;
    if (posA !== posB) return posA - posB;
    return (firstInputIdxByCwd.get(a.cwd) ?? Number.MAX_SAFE_INTEGER) - (firstInputIdxByCwd.get(b.cwd) ?? Number.MAX_SAFE_INTEGER);
  });

  return plan;
}

/** A mid-flight socket drop: the connection was accepted but then torn down
 * before a response arrived. Distinct from `ECONNREFUSED` (nobody was
 * listening at all) — this can mean the daemon just died, but it can equally
 * mean the daemon is alive and merely wedged (its event loop blocked on a
 * slow query, say) and RSTing every request it cannot service, `/health`
 * included. DaemonClient normalizes network failures to a TypeError whose
 * `cause` is the original Node error carrying `.code`; undici's
 * `UND_ERR_SOCKET` is kept for the same case from a prior fetch-based client. */
const SOCKET_DROP_CODES = new Set(["ECONNRESET", "EPIPE", "UND_ERR_SOCKET"]);

/** The original Node error's `.code`, unwrapped from DaemonClient's normalized TypeError. */
function causeCode(err: unknown): string | undefined {
  if (!(err instanceof Error)) return undefined;
  const code = (err.cause as { code?: unknown } | undefined)?.code;
  return typeof code === "string" ? code : undefined;
}

/**
 * True when the client gave up on a daemon call (timeout/abort) rather than
 * the daemon reporting a failure. DaemonClient preserves these error names.
 * A mid-flight socket drop (see `SOCKET_DROP_CODES`) counts too: the daemon
 * may still be persisting the summary, so the caller should re-read rather
 * than break the chain — but only once `isConnectionDroppedError` has been
 * checked and the daemon confirmed alive; a wedged daemon RSTs every request
 * the same way and this function alone cannot tell the two apart.
 */
export function isClientGaveUpError(err: unknown): boolean {
  if (!(err instanceof Error)) return false;
  if (err.name === "TimeoutError" || err.name === "AbortError") return true;
  const code = causeCode(err);
  return code !== undefined && SOCKET_DROP_CODES.has(code);
}

/**
 * True when the daemon refused the connection outright — nothing is
 * listening, as opposed to `isClientGaveUpError`'s "the call gave up, but the
 * daemon may still be working" cases. Once this fires, every following call
 * in the same batch will fail identically until the daemon comes back, so a
 * replay/batch loop must stop rather than burn through the remaining
 * sessions marking each one failed and breaking its own chain. DaemonClient
 * normalizes connection failures to a TypeError whose `cause` is the
 * original Node error carrying `.code`.
 */
export function isDaemonUnreachableError(err: unknown): boolean {
  return causeCode(err) === "ECONNREFUSED";
}

/**
 * True for a mid-flight socket drop whose cause is ambiguous on its own — the
 * daemon dying and a wedged daemon RSTing every request look identical from
 * here. A caller matching this must resolve the ambiguity itself (typically
 * with a short `client.health()` probe) before deciding whether to keep
 * going: a healthy answer means treat the error as an ordinary give-up
 * (`isClientGaveUpError`); no answer means treat it like
 * `isDaemonUnreachableError` and stop the run. TimeoutError/AbortError are
 * deliberately excluded — those are the client's own timeout firing, not
 * evidence the daemon is unresponsive, so they keep going through
 * `isClientGaveUpError` unprobed as before.
 */
export function isConnectionDroppedError(err: unknown): boolean {
  const code = causeCode(err);
  return code !== undefined && SOCKET_DROP_CODES.has(code);
}

/**
 * Latest persisted summary for a session, read straight from the project DB.
 *
 * Used when the client gave up on a /compact call (timeout/abort) but the
 * daemon may have finished the work anyway: the chain follows what was
 * persisted, not whether the HTTP call returned in time. Ordering mirrors the
 * daemon's own "latest summary" fallback (`getSummariesByConversation`, last).
 *
 * Pass `notBefore` (a timestamp captured just before the /compact call) to
 * only accept summaries persisted after the call started: a pre-existing
 * summary from an earlier run or hook must not be mistaken for the in-flight
 * call's result. Summaries store `created_at` as `datetime('now')` (whole
 * seconds, UTC), so `notBefore` is rounded DOWN to the second: a summary
 * persisted later in the same second the call started is still recovered,
 * while anything from an earlier second is certainly stale.
 *
 * Returns three distinct token metrics that callers must not conflate:
 * - `sourceMessageTokenCount`: tokens of the messages folded into this one
 *   summary (not the conversation's total).
 * - `summaryTokenCount`: size of the summary text itself.
 * - `contextTokenCount`: the conversation's current total context tokens
 *   (tail messages + summaries), i.e. the same metric `/compact` reports as
 *   `tokensAfter`.
 */
export async function loadLatestSessionSummary(opts: {
  cwd: string;
  paths?: LcmPaths;
  lcmDir?: string;
  sessionId: string;
  /** Epoch ms; only summaries persisted at or after this time are returned. */
  notBefore?: number;
}): Promise<{
  summaryId: string;
  content: string;
  summaryTokenCount: number;
  sourceMessageTokenCount: number;
  contextTokenCount: number;
} | null> {
  const opened = openProjectDb(projectDbPathFor(opts.cwd, replayPaths(opts)));
  if (opened.kind !== "ready") {
    if (opened.kind === "error") {
      console.error(`  ⚠️ [replay] could not read latest summary for session ${opts.sessionId}: project database failed to open`);
    }
    return null;
  }
  const { db } = opened;
  try {
    const conv = db
      .prepare("SELECT conversation_id FROM conversations WHERE session_id = ?")
      .get(opts.sessionId) as { conversation_id: number } | undefined;
    if (!conv) return null;
    const summaryStore = new SummaryStore(db);
    let summaries = await summaryStore.getSummariesByConversation(conv.conversation_id);
    if (opts.notBefore !== undefined) {
      // created_at has whole-second precision; floor the boundary so a summary
      // persisted later in the same second the call started is not excluded.
      const cutoff = new Date(Math.floor(opts.notBefore / 1000) * 1000);
      summaries = summaries.filter((s) => s.createdAt >= cutoff);
    }
    const latest = summaries[summaries.length - 1];
    if (!latest) return null;
    const contextTokenCount = await summaryStore.getContextTokenCount(conv.conversation_id);
    return {
      summaryId: latest.summaryId,
      content: latest.content,
      summaryTokenCount: latest.tokenCount,
      sourceMessageTokenCount: latest.sourceMessageTokenCount,
      contextTokenCount,
    };
  } catch (err) {
    console.error(`  ⚠️ [replay] could not read latest summary for session ${opts.sessionId}: ${err instanceof Error ? err.message : String(err)}`);
    return null;
  } finally {
    closeDb(opened);
  }
}

/**
 * Record a completed session compaction.
 *
 * `outcome` distinguishes a session that produced a summary from one that had
 * no work to do; both are complete, so both are skipped on resume. `summaryId`
 * is the threading anchor and is null for a no-work session — the anchor search
 * walks back past it rather than treating it as a broken chain.
 */
export function recordReplayProgress(opts: {
  cwd: string;
  paths?: LcmPaths;
  lcmDir?: string;
  runId: string;
  sessionId: string;
  position: number;
  contentFingerprint: string;
  outcome: ReplayOutcome;
  summaryId?: string | null;
  model?: string | null;
}): void {
  const opened = openProjectDb(projectDbPathFor(opts.cwd, replayPaths(opts)));
  if (opened.kind !== "ready") return;
  const { db } = opened;
  try {
    db.prepare(`
      INSERT INTO replay_ledger (run_id, session_id, position, content_fingerprint, summary_id, outcome, model)
      VALUES (?, ?, ?, ?, ?, ?, ?)
      ON CONFLICT (run_id, session_id) DO UPDATE SET
        position = excluded.position,
        content_fingerprint = excluded.content_fingerprint,
        summary_id = excluded.summary_id,
        outcome = excluded.outcome,
        model = excluded.model,
        completed_at = datetime('now')
    `).run(
      opts.runId,
      opts.sessionId,
      opts.position,
      opts.contentFingerprint,
      opts.summaryId ?? null,
      opts.outcome,
      opts.model ?? null,
    );
  } catch { /* ledger writes are best-effort — the next run re-does the work */ }
  finally { closeDb(opened); }
}

/** Read the sessions whose compaction guards a daemon replay reset must hold. */
export function replaySessionsToClear(cwd: string, paths: LcmPaths, command: ReplayCommand): string[] {
  const dbPath = projectDbPathFor(cwd, paths);
  if (!existsSync(dbPath)) return [];
  const db = openStandaloneLcmConnection(dbPath, { readOnly: true });
  try {
    if (!db.prepare("SELECT 1 FROM sqlite_master WHERE type = 'table' AND name = 'replay_manifest'").get()) return [];
    return (db.prepare("SELECT DISTINCT session_id FROM replay_manifest WHERE command = ? ORDER BY session_id")
      .all(command) as { session_id: string }[]).map((row) => row.session_id);
  } finally {
    db.close();
  }
}

/**
 * `--restart`: drop this command's replay runs and undo their compaction.
 * Ledger rows of the other command for the same sessions are dropped as well,
 * since the summaries they point at are gone.
 *
 * Undo is wholesale, not surgical: every summary in a touched conversation is
 * removed and its context rebuilt from messages, including summaries written
 * outside a replay. That is sound because no information is lost — messages are
 * never deleted and context_items is a projection over them — and necessary
 * because a replay summary can absorb an earlier one as a parent, so scoping
 * deletes to replay-owned ids leaves the conversation missing them anyway.
 *
 * Returns false when the clear could not complete, so callers can warn instead
 * of silently keeping state.
 */
export async function clearReplayState(opts: {
  cwd: string;
  paths?: LcmPaths;
  lcmDir?: string;
  command: ReplayCommand;
  /** Route through the daemon when one is available. */
  client?: Pick<DaemonClient, "post">;
  /** Reports the number of summaries discarded (before the local reset, after a daemon reset). */
  onSummaryCount?: (count: number) => void;
}): Promise<boolean> {
  if (opts.client) {
    try {
      const result = await opts.client.post<{ cleared: boolean; summaryCount: number }>("/replay-reset", {
        cwd: opts.cwd, command: opts.command,
      });
      opts.onSummaryCount?.(result.summaryCount);
      return result.cleared;
    } catch (err) {
      // Only a refused connection proves that no daemon can be compacting.
      if (!isDaemonUnreachableError(err)) throw err;
    }
  }
  const opened = openProjectDb(projectDbPathFor(opts.cwd, replayPaths(opts)));
  if (opened.kind === "missing") return true; // nothing to clear
  if (opened.kind === "error") return false; // existing DB could not be opened
  const { db } = opened;
  try {
    const conversationIds = loadReplayConversationIds(db, opts.command);
    const store = new SummaryStore(db);

    if (opts.onSummaryCount) {
      let total = 0;
      for (const conversationId of conversationIds) {
        total += await store.countSummaries(conversationId);
      }
      opts.onSummaryCount(total);
    }

    // Each conversation resets in its own transaction. A failure part-way
    // leaves earlier conversations reset and the ledger intact, so the next
    // --restart retries the rest rather than losing track of them.
    for (const conversationId of conversationIds) {
      await store.resetConversationContext(conversationId);
    }

    db.exec("BEGIN");
    try {
      // Summaries are shared across commands, so every ledger row for a wiped
      // session goes too, whichever command wrote it. The other command keeps
      // its manifest and re-enqueues the suffix from the first wiped session.
      db.prepare(
        "DELETE FROM replay_ledger WHERE session_id IN (SELECT session_id FROM replay_manifest WHERE command = ?)",
      ).run(opts.command);
      db.prepare("DELETE FROM replay_manifest WHERE command = ?").run(opts.command);
      db.exec("COMMIT");
      return true;
    } catch (err) {
      db.exec("ROLLBACK");
      throw err;
    }
  } catch {
    return false;
  } finally {
    closeDb(opened);
  }
}

/** Conversations touched by any run of this command, via its frozen manifest. */
function loadReplayConversationIds(db: DatabaseSync, command: ReplayCommand): number[] {
  const rows = db
    .prepare(
      `SELECT DISTINCT c.conversation_id
       FROM replay_manifest m
       JOIN conversations c ON c.session_id = m.session_id
       WHERE m.command = ?`,
    )
    .all(command) as unknown as { conversation_id: number }[];
  return rows.map((row) => row.conversation_id);
}
