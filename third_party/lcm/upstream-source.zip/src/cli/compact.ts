import { exit, stdout } from "node:process";
import { Option } from "commander";
import type { Command } from "commander";
import type { DaemonClient } from "../daemon/client.js";
import { lcmHome } from "../lcm-home.js";
import { replayParallelism } from "../replay-projects.js";
import { createLcmPaths } from "../lcm-paths.js";
import { fail, readStdin, showHelpAndExit } from "./support.js";

export interface CompactCommandDeps {
  createDaemonClientOrExit: (spawnTimeoutMs?: number) => Promise<DaemonClient>;
}

export function registerCompactCommand(program: Command, deps: CompactCommandDeps): void {
  const { createDaemonClientOrExit } = deps;

  // ─── compact ───────────────────────────────────────────────────────────────
  program
    .command("compact")
    .description("Compact conversation context into DAG summary nodes")
    .option("--all", "Compact all tracked projects")
    .option("--dry-run", "Show what would be compacted without writing")
    .option("--replay", "Compact sequentially with threaded context")
    .option("--parallel <N>", "With --replay: process N projects concurrently", "1")
    .option("--replay-provider <provider>", "With --replay: use session-pool without changing live compactions")
    .option("--restart", "Discard recorded replay progress and start from scratch")
    .option("--no-promote", "Skip the automatic promote step")
    .option("-v, --verbose", "Show per-session token details")
    .addOption(new Option("--hook", "Hook dispatch mode (internal)").hideHelp())
    .helpOption(false)
    .option("-h, --help", "Show help")
    .action(async (opts) => {
      if (opts.help) await showHelpAndExit("compact");
      const all: boolean = opts.all ?? false;
      const dryRun: boolean = opts.dryRun ?? false;
      const verbose: boolean = opts.verbose ?? false;
      const replay: boolean = opts.replay ?? false;
      const restart: boolean = opts.restart ?? false;
      const parallel = /^\d+$/.test(opts.parallel) ? Number(opts.parallel) : NaN;
      const replayProvider = opts.replayProvider as "session-pool" | undefined;
      try { replayParallelism({ replay, parallel, replayProvider }); }
      catch (error) { fail(error instanceof Error ? error.message : String(error)); }
      // Hook dispatch only when --hook is explicit; all other invocations go to batch.
      const hook: boolean = opts.hook ?? false;
      if (!hook) {
        const { batchCompact } = await import("../batch-compact.js");
        const { loadDaemonConfig } = await import("../daemon/config.js");
        const { join } = await import("node:path");
        const paths = createLcmPaths(lcmHome());
        const config = loadDaemonConfig(paths.configPath);
        const port = config.daemon?.port ?? 3737;
        const client = await createDaemonClientOrExit(10000);
        const noPromote: boolean = !opts.promote;
        const minTokens = config.compaction.autoCompactMinTokens;
        const cwd = all ? undefined : process.cwd();
        const tokenPath = paths.tokenPath;

        const { NinjaRenderer } = await import("./pipeline-runner.js");
        const { makeProgressState } = await import("./progress-state.js");
        const isTTY = process.stdout.isTTY ?? false;
        const renderOpts = { isTTY, width: process.stdout.columns ?? 80, color: isTTY, verbose };
        const compactState = makeProgressState({ phases: [{ name: "Compact", status: "active" }], dryRun });
        const compactRenderer = new NinjaRenderer({ state: compactState, renderOpts });
        compactRenderer.start();

        const { configuredSummaryModel } = await import("../daemon/summarizer.js");
        const replayModel = configuredSummaryModel(config, replayProvider ?? config.llm.provider);
        const { compacted, daemonUnreachable } = await batchCompact({
          paths, minTokens, dryRun, port, cwd, replay, restart, verbose, tokenPath,
          replayModel, parallel, replayProvider,
          onBeforeSession: () => !compactRenderer.shouldStop,
          trackInFlight: () => compactRenderer.trackInFlight(),
          onProgress: (patch) => {
            if (patch.resumed) {
              const model = patch.resumed.model ? `, ${patch.resumed.model}` : "";
              console.log(`  resuming: ${patch.resumed.doneCount}/${patch.resumed.totalCount} done, ${patch.resumed.totalCount - patch.resumed.doneCount} remaining${model}`);
            }
            Object.assign(compactState, patch);
            if (patch.lastResult) compactRenderer.sessionDone();
          },
        });

        compactRenderer.stop();
        if (isTTY) {
          compactState.phases[0].status = "done";
          compactRenderer.printSummary();
        }

        // Auto-promote after a successful compact: new summaries are prime promotion
        // candidates. Skipped when the daemon went unreachable mid-run — it would
        // still be down (or wedged) for the POST, which DaemonClient gives no
        // timeout, and could hang the command right after it reported stopping.
        if (compacted > 0 && !noPromote && !daemonUnreachable) {
          const { readdirSync, existsSync } = await import("node:fs");
          const { readProjectMetaIn } = await import("../daemon/project-meta.js");
          const promoteCwds: string[] = [];
          if (cwd) {
            promoteCwds.push(cwd);
          } else {
            const projectsDir = paths.projectsDir;
            if (existsSync(projectsDir)) {
              for (const entry of readdirSync(projectsDir, { withFileTypes: true })) {
                if (!entry.isDirectory()) continue;
                const cwd = readProjectMetaIn(join(projectsDir, entry.name))?.cwd;
                if (cwd) promoteCwds.push(cwd);
              }
            }
          }

          let totalPromoted = 0;
          for (const promoteCwd of promoteCwds) {
            try {
              const result = await client.post<{ processed: number; promoted: number }>("/promote", {
                cwd: promoteCwd,
                dry_run: dryRun,
              });
              totalPromoted += result.promoted;
            } catch { /* non-fatal: promote is best-effort */ }
          }

          if (totalPromoted > 0) {
            console.log(`  → ${totalPromoted} insight${totalPromoted !== 1 ? "s" : ""} promoted`);
          }
        }
        return;
      }
      // Piped stdin — hook dispatch (PreCompact hook invocation)
      const { dispatchHook } = await import("../hooks/dispatch.js");
      const input = await readStdin();
      const r = await dispatchHook("compact", input);
      if (r.stdout) stdout.write(r.stdout);
      exit(r.exitCode);
    });
}
