import { exit } from "node:process";
import type { Command } from "commander";
import type { DaemonClient } from "../daemon/client.js";
import { lcmHome } from "../lcm-home.js";
import { replayParallelism } from "../replay-projects.js";
import { createLcmPaths } from "../lcm-paths.js";
import { fail, showHelpAndExit } from "./support.js";

export interface ImportCommandDeps {
  createDaemonClientOrExit: (spawnTimeoutMs?: number) => Promise<DaemonClient>;
}

export function registerImportCommand(program: Command, deps: ImportCommandDeps): void {
  const { createDaemonClientOrExit } = deps;

  // ─── import ────────────────────────────────────────────────────────────────
  program
    .command("import")
    .description("Import Claude Code, Codex, or OMP session transcripts into lossless memory")
    .option("--provider <provider>", "Transcript source: claude, codex, omp, all (default: all)")
    .option("--codex", "Import Codex transcripts (alias for --provider codex)")
    .option("--omp", "Import OMP transcripts (alias for --provider omp)")
    .option("--all", "Import all projects")
    .option("--verbose", "Show per-session import detail")
    .option("--dry-run", "Preview without importing")
    .option("--replay", "Replay compaction for each imported session")
    .option("--no-promote", "Skip the automatic promote step after compaction")
    .option("--parallel <N>", "With --replay: process N projects concurrently", "1")
    .option("--replay-provider <provider>", "With --replay: use session-pool without changing live compactions")
    .option("--restart", "Discard recorded replay progress and start from scratch")
    .option("--backfill-event-times", "Fill unknown transcript event times in bounded batches, without model calls")
    .option("--rebuild", "Repair Claude history or historical NUL-cut Codex and OMP rows")
    .option("--retry-blocked", "With --provider codex: clear terminal capture guards")
    .option("--yes", "With --rebuild: apply it (default: preview)")
    .option("--session <id>", "With --rebuild or --retry-blocked: only this session")
    .helpOption(false)
    .option("-h, --help", "Show help")
    .action(async (opts) => {
      if (opts.help) await showHelpAndExit("import");
      const all: boolean = opts.all ?? false;
      const verbose: boolean = opts.verbose ?? false;
      const dryRun: boolean = opts.dryRun ?? false;
      const replay: boolean = opts.replay ?? false;
      if (opts.backfillEventTimes && (replay || opts.restart || opts.rebuild || opts.retryBlocked)) fail("  --backfill-event-times cannot be combined with --replay, --restart, --rebuild or --retry-blocked");
      const restart: boolean = opts.restart ?? false;
      const parallel = /^\d+$/.test(opts.parallel) ? Number(opts.parallel) : NaN;
      const replayProvider = opts.replayProvider as "session-pool" | undefined;
      try { replayParallelism({ replay, parallel, replayProvider }); }
      catch (error) { fail(error instanceof Error ? error.message : String(error)); }

      const { DaemonClient } = await import("../daemon/client.js");
      const { loadDaemonConfig } = await import("../daemon/config.js");
      const { configuredSummaryModel } = await import("../daemon/summarizer.js");
      const { NinjaRenderer } = await import("./pipeline-runner.js");
      const { makeProgressState } = await import("./progress-state.js");
      const { join } = await import("node:path");
      const { homedir } = await import("node:os");
      const { importSessions, resolveImportProvider } = await import("../import.js");
      const paths = createLcmPaths(lcmHome());
      const provider = (() => {
        try {
          return resolveImportProvider({ provider: opts.provider, codex: opts.codex, omp: opts.omp });
        } catch (err) {
          return fail(`  ${err instanceof Error ? err.message : String(err)}`);
        }
      })();

      if (opts.retryBlocked) {
        if (provider !== "codex") fail("  --retry-blocked requires --provider codex");
        if (replay || opts.rebuild || dryRun) fail("  --retry-blocked cannot be combined with --replay, --rebuild or --dry-run");
        if (all && opts.session !== undefined) fail("  --all and --session cannot be combined with --retry-blocked");
        if (opts.session !== undefined && !opts.session.trim()) fail("  --session must not be empty");
        if (opts.yes) fail("  --yes applies only with --rebuild");
        const cwds: string[] = [];
        if (all) {
          const { existsSync, readdirSync } = await import("node:fs");
          const { readProjectMetaIn } = await import("../daemon/project-meta.js");
          if (existsSync(paths.projectsDir)) {
            for (const entry of readdirSync(paths.projectsDir, { withFileTypes: true })) {
              if (!entry.isDirectory()) continue;
              const cwd = readProjectMetaIn(join(paths.projectsDir, entry.name))?.cwd;
              // A vanished directory has no capture to retry, and the daemon rejects its cwd.
              if (cwd && existsSync(cwd)) cwds.push(cwd);
            }
          }
        } else {
          cwds.push(process.cwd());
        }
        const client = await createDaemonClientOrExit();
        let cleared = 0;
        for (const cwd of cwds) {
          const result = await client.post<{ cleared: number }>("/capture-retry", {
            cwd, ...(opts.session !== undefined ? { session_id: opts.session } : { all: true }),
          });
          cleared += result.cleared;
          if (all && result.cleared) console.log(`${cwd}: cleared ${result.cleared}`);
        }
        console.log(`Cleared ${cleared} terminal Codex guards; the next capture will recheck alignment.`);
        return;
      }

      const config = loadDaemonConfig(paths.configPath);
      if (opts.rebuild) {
        if (provider === "all") fail("  --rebuild requires --provider claude, codex, or omp");
        if (replay || restart) fail("  --rebuild cannot be combined with --replay or --restart; replay after the rebuild");
        if (dryRun && opts.yes) fail("  --dry-run cannot be combined with --yes");
        const { rebuildClaudeSessions, repairCutRows } = await import("../import.js");
        const { printRebuildSummary, printCutRepairSummary } = await import("../import-summary.js");
        const apply = opts.yes === true;
        // A preview reads the project databases directly and never starts the daemon.
        const client = apply ? await createDaemonClientOrExit() : undefined;
        const options = { paths, all, apply, sessionId: opts.session, sensitivePatterns: config.security?.sensitivePatterns ?? [] };
        if (provider === "claude") {
          const run = await rebuildClaudeSessions(client, options);
          printRebuildSummary(run, { apply });
          if (run.failedProjects.length > 0 || run.sessions.some((s) => s.error)) exit(1);
        } else {
          const run = await repairCutRows(client, { ...options, provider });
          printCutRepairSummary(run, { apply, provider });
          if (run.failedProjects.length > 0 || run.sessions.some((s) => s.error)) exit(1);
        }
        return;
      }
      if (opts.yes || opts.session !== undefined) fail("  --yes applies only with --rebuild; --session applies only with --rebuild or --retry-blocked");
      const port = config.daemon?.port ?? 3737;
      const previewClient = new DaemonClient(`http://127.0.0.1:${port}`, paths.tokenPath);
      const preview = await importSessions(previewClient, { paths, all, provider, dryRun: true, verbose: dryRun && verbose, replay, backfillEventTimes: opts.backfillEventTimes });
      if (dryRun) {
        console.log(`  [dry-run] ${preview.imported} ${provider} sessions selected (${all ? "all projects" : "current project"})${replay ? "; would compact each session" : ""}. No changes written.`);
        if (preview.skippedCwdMissing) console.log(`  Skipped (cwd missing): ${preview.skippedCwdMissing}`);
        if (preview.ompRootsScanned) console.log(`  OMP roots scanned: ${preview.ompRootsScanned.join(", ")}`);
        if (preview.ompDuplicatesSkipped) console.log(`  OMP duplicates skipped (session id also in another root): ${preview.ompDuplicatesSkipped.join(", ")}`);
        return;
      }
      const client = await createDaemonClientOrExit();

      const isTTY = process.stdout.isTTY ?? false;
      const renderOpts = { isTTY, width: process.stdout.columns ?? 80, color: isTTY, verbose };
      const state = makeProgressState({
        phases: [{ name: "Import", status: "active" }],
        total: preview.imported,
        dryRun,
      });
      const renderer = new NinjaRenderer({ state, renderOpts });

      const providerLabel =
        provider === "codex" ? "Codex CLI" :
        provider === "omp"   ? "OMP" :
        provider === "all"   ? "Claude Code + Codex CLI + OMP" :
                               "Claude Code";
      console.log(`\n  Importing ${providerLabel} sessions${all ? " (all projects)" : ""}...\n`);
      renderer.start();

      const result = await importSessions(client, {
        paths, all, verbose, dryRun, replay, restart, provider, backfillEventTimes: opts.backfillEventTimes, noPromote: !opts.promote,
        parallel, replayProvider,
        replayModel: configuredSummaryModel(config, replayProvider ?? config.llm.provider),
        onBeforeSession: () => !renderer.shouldStop,
        trackInFlight: () => renderer.trackInFlight(),
        onProgress: (patch) => {
          if (patch.resumed) {
            const model = patch.resumed.model ? `, ${patch.resumed.model}` : "";
            console.log(`  resuming: ${patch.resumed.doneCount}/${patch.resumed.totalCount} done, ${patch.resumed.totalCount - patch.resumed.doneCount} remaining${model}`);
          }
          Object.assign(state, patch);
          if (patch.lastResult) renderer.sessionDone();
        },
      });

      renderer.stop();
      if (opts.backfillEventTimes) console.log(`  Event times repaired: ${result.backfilledEventTimes ?? 0}; still unknown: ${result.unknownEventTimes ?? 0}`);

      if (isTTY && !verbose) {
        state.phases[0].status = "done";
        renderer.printSummary();
        if (result.skippedCwdMissing) console.log(`  Skipped (cwd missing): ${result.skippedCwdMissing}`);
      } else {
        const { printImportSummary } = await import("../import-summary.js");
        if (dryRun) console.log("  [dry-run] No changes written.\n");
        printImportSummary(result, { replay });
        console.log();
      }
    });
}

export interface KnowledgeCommandDeps {
  admitCliDatabaseWork: () => Promise<void>;
  createDaemonClientOrExit: (spawnTimeoutMs?: number) => Promise<DaemonClient>;
}

export function registerKnowledgeCommands(program: Command, deps: KnowledgeCommandDeps): void {
  const { admitCliDatabaseWork, createDaemonClientOrExit } = deps;

  // ─── promote ───────────────────────────────────────────────────────────────
  program
    .command("promote")
    .description("Scan summaries and promote durable insights to long-term memory")
    .option("--all", "Promote across all tracked projects")
    .option("--verbose", "Show per-project counts")
    .option("--dry-run", "Preview promotions without writing")
    .helpOption(false)
    .option("-h, --help", "Show help")
    .action(async (opts) => {
      if (opts.help) await showHelpAndExit("promote");
      const all: boolean = opts.all ?? false;
      const verbose: boolean = opts.verbose ?? false;
      const dryRun: boolean = opts.dryRun ?? false;

      const { loadDaemonConfig } = await import("../daemon/config.js");
      const { join } = await import("node:path");
      const paths = createLcmPaths(lcmHome());

      const config = loadDaemonConfig(paths.configPath);
      const port = config.daemon?.port ?? 3737;
      const client = await createDaemonClientOrExit();
      const { readdirSync, existsSync } = await import("node:fs");
      const { readProjectMetaIn } = await import("../daemon/project-meta.js");

      if (dryRun) console.log("  [dry-run] No changes will be written.\n");

      // Collect project cwds to promote
      const cwds: string[] = [];
      if (all) {
        const projectsDir = paths.projectsDir;
        if (existsSync(projectsDir)) {
          for (const entry of readdirSync(projectsDir, { withFileTypes: true })) {
            if (!entry.isDirectory()) continue;
            const cwd = readProjectMetaIn(join(projectsDir, entry.name))?.cwd;
            if (cwd) cwds.push(cwd);
          }
        }
      } else {
        cwds.push(process.cwd());
      }

      let totalProcessed = 0;
      let totalPromoted = 0;
      const total = cwds.length;

      for (let i = 0; i < cwds.length; i++) {
        const cwd = cwds[i];
        if (total > 1) {
          process.stdout.write(`\r  scanning project ${i + 1}/${total}...`);
        } else {
          process.stdout.write(`\r  scanning...`);
        }

        try {
          const result = await client.post<{ processed: number; promoted: number; conversations?: number }>("/promote", {
            cwd,
            dry_run: dryRun,
          });

          totalProcessed += result.processed;
          totalPromoted += result.promoted;

          if (verbose) {
            process.stdout.write("\r");
            const convLabel = result.conversations !== undefined ? `, ${result.conversations} conversation${result.conversations !== 1 ? "s" : ""}` : "";
            console.log(`  ${cwd}: ${result.processed} scanned${convLabel}, ${result.promoted} promoted`);
          }
        } catch (err) {
          if (verbose) console.error(`  promote failed for ${cwd}: ${err instanceof Error ? err.message : "request failed"}`);
          continue;
        }
      }
      // Clear the progress line
      process.stdout.write("\r  \r");

      if (totalPromoted === 0) {
        console.log("  Nothing to promote — no new insights found.");
      } else {
        console.log(`  ${totalPromoted} insight${totalPromoted !== 1 ? "s" : ""} promoted to long-term memory`);
      }
      if (verbose) console.log(`  (${totalProcessed} summaries scanned across ${cwds.length} project${cwds.length !== 1 ? "s" : ""})`);
      if (dryRun) console.log("  [dry-run] No changes written.");
      console.log();
    });

  // ─── export ────────────────────────────────────────────────────────────────
  program
    .command("export")
    .description("Export promoted knowledge to a portable JSON file")
    .option("--all", "Export all projects (one JSON per project, written to files)")
    .option("--tags <tags>", "Only export entries matching these comma-separated tags")
    .option("--since <date>", "Only export entries created on or after this ISO date (e.g. 2026-01-01)")
    .option("--output <file>", "Write output to file instead of stdout")
    .option("--format <format>", "Output format: json (default)", "json")
    .helpOption(false)
    .option("-h, --help", "Show help")
    .action(async (opts) => {
      if (opts.help) await showHelpAndExit("export");

      await admitCliDatabaseWork();
      const { exportKnowledge } = await import("../portable-knowledge.js");
      const { join } = await import("node:path");
      const { existsSync, readdirSync } = await import("node:fs");
      const { readProjectMetaIn } = await import("../daemon/project-meta.js");
      const paths = createLcmPaths(lcmHome());

      const tags: string[] | undefined = opts.tags
        ? (opts.tags as string).split(",").map((t: string) => t.trim()).filter(Boolean)
        : undefined;
      const since: string | undefined = opts.since;
      const output: string | undefined = opts.output;
      const all: boolean = opts.all ?? false;

      const cwds: string[] = [];
      if (all) {
        const projectsDir = paths.projectsDir;
        if (existsSync(projectsDir)) {
          for (const entry of readdirSync(projectsDir, { withFileTypes: true })) {
            if (!entry.isDirectory()) continue;
            const cwd = readProjectMetaIn(join(projectsDir, entry.name))?.cwd;
            if (cwd) cwds.push(cwd);
          }
        }
      } else {
        cwds.push(process.cwd());
      }

      let total = 0;
      for (const cwd of cwds) {
        let outFile: string | undefined = output;
        if (all && output === undefined) {
          // When --all and no --output, generate filenames automatically
          const slug = cwd.replace(/[^a-zA-Z0-9]/g, "-").replace(/-+/g, "-").slice(-40);
          outFile = join(process.cwd(), `lcm-export-${slug}.json`);
        }
        try {
          const result = await exportKnowledge(cwd, paths, { tags, since, output: outFile });
          total += result.exported;
          if (all) {
            console.log(`  ${cwd}: ${result.exported} entries → ${outFile}`);
          } else if (outFile) {
            console.log(`  Exported ${result.exported} entries to ${outFile}`);
          }
        } catch (err: any) {
          process.stderr.write(`  Warning: ${err.message}\n`);
        }
      }

      if (all) console.log(`\n  Total: ${total} entries exported`);
    });

  // ─── import-knowledge ──────────────────────────────────────────────────────
  program
    .command("import-knowledge <file>")
    .description("Import exported knowledge JSON into lossless memory")
    .option("--merge", "Merge with existing entries, deduplicating (default)")
    .option("--dry-run", "Preview import without writing anything")
    .option("--confidence <n>", "Override confidence for all imported entries (0.0–1.0)")
    .helpOption(false)
    .option("-h, --help", "Show help")
    .action(async (file: string, opts) => {
      if (opts.help) await showHelpAndExit("import-knowledge");

      await admitCliDatabaseWork();
      const { importKnowledge } = await import("../portable-knowledge.js");
      const { readFileSync } = await import("node:fs");
      const paths = createLcmPaths(lcmHome());

      const dryRun: boolean = opts.dryRun ?? false;
      const confidence: number | undefined = opts.confidence !== undefined
        ? parseFloat(opts.confidence as string)
        : undefined;

      if (confidence !== undefined && (isNaN(confidence) || confidence < 0 || confidence > 1)) {
        fail("  --confidence must be a number between 0.0 and 1.0");
      }

      let raw: string;
      try {
        raw = readFileSync(file, "utf-8");
      } catch (err: any) {
        fail(`  Cannot read file: ${err.message}`);
      }

      let doc: any;
      try {
        doc = JSON.parse(raw);
      } catch {
        fail("  Invalid JSON in export file");
      }

      if (!doc || typeof doc.version !== "number" || !Array.isArray(doc.entries)) {
        fail("  File does not look like an lcm export (missing version or entries)");
      }

      const cwd = process.cwd();

      if (dryRun) {
        console.log(`\n  [dry-run] Would import ${doc.entries.length} entries into ${cwd}`);
        console.log("  No changes written.\n");
        exit(0);
      }

      try {
        const result = await importKnowledge(cwd, paths, doc, { merge: true, dryRun, confidence });
        if (result.dryRun) {
          console.log(`\n  [dry-run] Would import ${result.total} entries. No changes written.\n`);
        } else {
          console.log(`\n  Imported ${result.imported} entries (${result.skipped} skipped) into ${cwd}\n`);
        }
      } catch (err: any) {
        fail(`  Import failed: ${err.message}`);
      }
    });
}
