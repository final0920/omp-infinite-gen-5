import { stdout } from "node:process";
import { Command } from "commander";
import { fail, helpRequested, showHelpAndExit } from "./support.js";
import type { ConnectorScope } from "../connectors/types.js";

function scopeOf(opts: { global?: boolean }): ConnectorScope {
  return opts.global ? "global" : "project";
}

export function registerConnectorsCommands(program: Command): void {
  // ─── connectors ────────────────────────────────────────────────────────────
  const connectorsCmd = new Command("connectors").description("Manage connectors for coding agents");
  connectorsCmd.helpOption(false).option("-h, --help", "Show help");
  connectorsCmd.action(async (opts) => {
    if (helpRequested(connectorsCmd, opts)) await showHelpAndExit("connectors");
    fail("Usage: lcm connectors <list|install|remove|doctor> [options]");
  });

  connectorsCmd
    .command("list")
    .description("List available agents and installed connectors")
    .option("--format <format>", "Output format: text or json", "text")
    .option("--global", "Inspect the global agent config in your home directory")
    .helpOption(false)
    .option("-h, --help", "Show help")
    .action(async (opts) => {
      if (helpRequested(connectorsCmd, opts)) await showHelpAndExit("connectors");
      const format: string = opts.format ?? "text";
      const { listConnectors } = await import("../connectors/installer.js");
      const { AGENTS } = await import("../connectors/registry.js");
      const installed = listConnectors({ scope: scopeOf(opts) });

      if (format === "json") {
        const result = AGENTS.map((a: any) => ({
          id: a.id,
          name: a.name,
          category: a.category,
          defaultType: a.defaultType,
          supportedTypes: a.supportedTypes,
          installed: installed.filter((c: any) => c.agentId === a.id).map((c: any) => c.type),
        }));
        stdout.write(JSON.stringify({ agents: result }, null, 2) + "\n");
      } else {
        console.log("\n  Available agents:\n");
        console.log("  %-20s %-15s %-15s %s", "Agent", "Installed", "Default", "Supported");
        console.log("  " + "─".repeat(70));
        for (const agent of AGENTS) {
          const agentInstalled = installed.filter((c: any) => c.agentId === (agent as any).id);
          const installedStr = (agentInstalled as any[]).length > 0
            ? (agentInstalled as any[]).map((c: any) => c.type).join(", ")
            : "-";
          console.log("  %-20s %-15s %-15s %s",
            (agent as any).name, installedStr, (agent as any).defaultType, (agent as any).supportedTypes.join(", "));
        }
        console.log();
      }
    });

  connectorsCmd
    .command("install [agent]")
    .description("Install a connector for an agent")
    .option("--type <type>", "Connector type: rules, mcp, skill, or hooks")
    .option("--global", "Install into the global agent config in your home directory")
    .helpOption(false)
    .option("-h, --help", "Show help")
    .action(async (agentName: string | undefined, opts) => {
      if (helpRequested(connectorsCmd, opts)) await showHelpAndExit("connectors");
      if (!agentName) fail("Usage: lcm connectors install <agent> [--type rules|mcp|skill|hooks] [--global]");
      const type: any = opts.type;
      const { installConnector } = await import("../connectors/installer.js");
      try {
        const result = installConnector({ agent: agentName, type, scope: scopeOf(opts) });
        if ((result as any).manual) {
          console.log(`\n  ${(result as any).manual}\n`);
        } else {
          console.log(`\n  ✓ Installed ${type ?? "default"} connector for ${agentName}`);
          console.log(`    Path: ${(result as any).path}`);
          if ((result as any).requiresRestart) console.log("    Restart the agent to activate.");
          if (result.notice) console.log(`    ${result.notice}`);
          console.log();
        }
      } catch (err: any) {
        fail(`  Error: ${err.message}`);
      }
    });

  connectorsCmd
    .command("remove [agent]")
    .description("Remove a connector for an agent")
    .option("--type <type>", "Connector type: rules, mcp, skill, or hooks")
    .option("--global", "Remove from the global agent config in your home directory")
    .helpOption(false)
    .option("-h, --help", "Show help")
    .action(async (agentName: string | undefined, opts) => {
      if (helpRequested(connectorsCmd, opts)) await showHelpAndExit("connectors");
      if (!agentName) fail("Usage: lcm connectors remove <agent> [--type rules|mcp|skill|hooks] [--global]");
      const type: any = opts.type;
      const { removeConnector } = await import("../connectors/installer.js");
      try {
        const removed = removeConnector({ agent: agentName, type, scope: scopeOf(opts) });
        if (removed) {
          console.log(`\n  ✓ Removed connector for ${agentName}\n`);
        } else {
          console.log(`\n  No connector found for ${agentName}\n`);
        }
      } catch (err: any) {
        fail(`  Error: ${err.message}`);
      }
    });

  connectorsCmd
    .command("doctor [agent]")
    .description("Check connector health")
    .option("--global", "Inspect the global agent config in your home directory")
    .helpOption(false)
    .option("-h, --help", "Show help")
    .action(async (agentName: string | undefined, opts) => {
      if (helpRequested(connectorsCmd, opts)) await showHelpAndExit("connectors");
      const { AGENTS } = await import("../connectors/registry.js");
      const { listConnectors, diagnoseConnector } = await import("../connectors/installer.js");
      const { findAgent } = await import("../connectors/registry.js");
      const found = agentName ? findAgent(agentName) : undefined;
      const agents = found ? [found] : agentName ? [] : AGENTS;

      if (agents.length === 0) fail(`  Unknown agent: ${agentName}`);

      console.log("\n  Connector health:\n");
      const installed = listConnectors({ scope: scopeOf(opts) });
      for (const agent of agents) {
        const hasDetailedHooks = agent.supportedTypes.includes("hooks");
        if (hasDetailedHooks) {
          const diagnosis = diagnoseConnector({ agent: agent.id, type: "hooks", scope: scopeOf(opts) });
          console.log(`  ${diagnosis.status === "installed" ? "○" : "⚠"} ${agent.name}: ${diagnosis.message}`);
          console.log(`    Path: ${diagnosis.path}`);
          for (const issue of diagnosis.issues) console.log(`    ${issue}`);
        }
        const agentConnectors = installed.filter((c) => c.agentId === agent.id);
        if (agentConnectors.length === 0) {
          console.log(`  ⚠ ${agent.name}: no connectors installed`);
        } else {
          for (const c of agentConnectors) {
            if (hasDetailedHooks && c.type === "hooks") continue;
            console.log(`  ✓ ${agent.name}: ${c.type} at ${c.path}`);
          }
        }
      }
      console.log();

    });
  program.addCommand(connectorsCmd);
}
