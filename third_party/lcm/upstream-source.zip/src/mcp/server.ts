import { excludedWorkerContext } from "../worker-session.js";
import { createAgentWorkerTransport, type AgentSubmission } from "../agent-worker-transport.js";
import { WORKER_WARNING, workerDisplayId, workerRefusal } from "../worker-warning.js";
import { Server } from "@modelcontextprotocol/server";
import { serveStdio } from "@modelcontextprotocol/server/stdio";
import { cliEntrypoint } from "../cli-entrypoint.js";
import { daemonNotice } from "../hooks/fail-open.js";
import { DaemonClient } from "../daemon/client.js";
import { loadDaemonConfig } from "../daemon/config.js";
import { ensureDaemon, registerDaemonActivity } from "../daemon/lifecycle.js";
import { readHold } from "../daemon/hold.js";
import { PKG_VERSION } from "../daemon/version.js";
import { pivotLanguagesFor } from "../search/pivot-language.js";
import { createToolCatalog, getMcpToolDefinitions } from "./tool-catalog.js";
import type { LocalHandlers } from "./tool-catalog.js";
import { lcmHome } from "../lcm-home.js";
import { createLcmPaths } from "../lcm-paths.js";
import type { LcmPaths } from "../lcm-paths.js";

function localTools(paths: LcmPaths): LocalHandlers { return {
  stats: async (args: Record<string, unknown>): Promise<string> => {
    const { collectStats, formatNumber, formatSubagentShare } = await import("../stats.js");
    const stats = collectStats(paths);
    const verbose = args.verbose === true;
    const lines: string[] = [];

    if (stats.workers?.length) {
      lines.push(WORKER_WARNING);
      for (const worker of stats.workers) lines.push(`Worker ${workerDisplayId(worker.session_id)}: ${worker.state}; last activity ${worker.last_activity}`);
    }
    // Memory section
    lines.push("## 🧠 Memory");
    lines.push("");
    lines.push("| Metric | Value |");
    lines.push("|--------|-------|");
    lines.push(`| Projects | ${stats.projects} |`);
    lines.push(`| Conversations | ${stats.conversations} |`);
    lines.push(`| Messages | ${formatNumber(stats.messages)} |`);
    lines.push(`| Summaries | ${formatNumber(stats.summaries)} |`);
    lines.push(`| DAG depth | ${stats.maxDepth} |`);
    lines.push(`| Promoted memories | ${stats.promotedCount} |`);
    lines.push(`| Subagent | ${formatSubagentShare(stats)} |`);
    if (stats.eventsCaptured > 0) {
      lines.push(`| Events | ${formatNumber(stats.eventsCaptured)} captured (${stats.eventsUnprocessed} unprocessed, ${stats.eventsErrors} errors (30d)) |`);
    }

    // Compression section (only when summarization has happened)
    if (stats.summaries > 0) {
      lines.push("");
      lines.push("## Compression");
      lines.push("");
      lines.push("| Metric | Value |");
      lines.push("|--------|-------|");

      const rawStr = formatNumber(stats.rawTokens);
      const sumStr = formatNumber(stats.summaryTokens);
      const savedPct = stats.rawTokens > 0
        ? ((1 - stats.summaryTokens / stats.rawTokens) * 100).toFixed(1)
        : "0.0";
      const ratio = stats.ratio > 0 ? stats.ratio.toFixed(1) + "x" : "–";

      const barWidth = 30;
      const filled = stats.rawTokens > 0
        ? Math.round((1 - stats.summaryTokens / stats.rawTokens) * barWidth)
        : 0;
      const bar = "█".repeat(filled) + "░".repeat(barWidth - filled);

      lines.push(`| Compacted | ${stats.compactedConversations} of ${stats.conversations} conversations |`);
      lines.push(`| Tokens | ${rawStr} → ${sumStr} |`);
      lines.push(`| Ratio | ${ratio} |`);
      lines.push(`| | ${savedPct}% compressed |`);
      lines.push(`| | \`${bar}\` |`);

      // Per Conversation (verbose, compacted-only)
      if (verbose) {
        const compactedDetails = stats.conversationDetails.filter((c) => c.summaries > 0);
        if (compactedDetails.length > 0) {
          lines.push("");
          lines.push("## Per Conversation");
          lines.push("");
          lines.push("| # | msgs | sums | depth | tokens | ratio |");
          lines.push("|---|------|------|-------|--------|-------|");
          for (const c of compactedDetails) {
            const tokensStr = `${formatNumber(c.rawTokens)} → ${formatNumber(c.summaryTokens)}`;
            const r = c.ratio > 0 ? c.ratio.toFixed(1) + "x" : "–";
            lines.push(`| ${c.conversationId} | ${c.messages} | ${c.summaries} | ${c.maxDepth} | ${tokensStr} | ${r} |`);
          }
        }
      }
    }

    // Security section (always shown)
    {
      const rc = stats.redactionCounts;
      lines.push("");
      lines.push("## 🔒 Security");
      lines.push("");
      lines.push("| Metric | Value |");
      lines.push("|--------|-------|");
      if (rc.total === 0) {
        lines.push(`| Redactions | 0 |`);
      } else {
        lines.push(`| Redactions | ${rc.total} total (built-in: ${rc.builtIn}  global: ${rc.global}  project: ${rc.project}) |`);
      }
    }

    // A memory's content is agent-written: a `|` or a newline in it would otherwise shift
    // the counts into the wrong column or row of the table below.
    const cell = (value: string): string => value.replace(/\|/g, "\\|").replace(/\r?\n/g, " ");

    // Promotion candidates (always shown when non-empty: a human decides, not the tool)
    if (stats.promotionCandidates.length > 0) {
      lines.push("");
      lines.push("## Promotion candidates");
      lines.push("");
      lines.push("| Memory ID | Memory | Owner | Uses | +1 | -1 |");
      lines.push("|-----------|--------|-------|------|----|----|");
      for (const c of stats.promotionCandidates) {
        const preview = c.content.length > 80 ? c.content.slice(0, 80) + "…" : c.content;
        lines.push(`| ${c.id} | ${cell(preview)} | ${c.ownerProjectId} | ${c.useCount} | ${c.plusOne} | ${c.minusOne} |`);
      }
    }

    // Contested memories (at least one -1)
    if (stats.contested.length > 0) {
      lines.push("");
      lines.push("## Contested");
      lines.push("");
      for (const c of stats.contested) {
        const preview = c.content.length > 80 ? c.content.slice(0, 80) + "…" : c.content;
        lines.push(`- ${c.id}: ${cell(preview)} (owner: ${c.ownerProjectId})`);
        for (const o of c.objections) {
          lines.push(`  - -1 (${o.voteId}, owner: ${o.ownerProjectId}): ${cell(o.reason)}`);
        }
      }
      lines.push("");
      lines.push("Resolve by archiving the memory, superseding it with a corrected `lcm_store`, or dismissing a single objection by archiving its vote id via `POST /review-stale` (`action: \"archive\"`).");
    }

    return lines.join("\n");
  },
  doctor: async (): Promise<string> => {
    const { runDoctor, formatResultsPlain } = await import("../doctor/doctor.js");
    const results = await runDoctor();
    return formatResultsPlain(results);
  },
}; }

export { getMcpToolDefinitions };

export type DaemonRequestOpts = {
  port: number;
  pidFilePath: string;
  spawnCommand?: string;
  spawnArgs?: string[];
  expectedVersion?: string;
  _ensureDaemon?: typeof ensureDaemon;
};

/** Returns true if the error is a network/connection failure (not a daemon HTTP error). */
function isNetworkError(err: unknown): boolean {
  return err instanceof TypeError;
}

/**
 * One restart attempt per port at a time — concurrent network failures share the same
 * restart promise instead of each spawning a separate daemon process.
 */
const restartInFlight = new Map<number, Promise<unknown>>();

/** Exported for testing. Calls a daemon route with auto-restart + retry on network failure. */
export async function handleDaemonRequest(
  client: Pick<DaemonClient, "post">,
  route: string,
  body: Record<string, unknown>,
  opts: DaemonRequestOpts,
): Promise<{ content: Array<{ type: "text"; text: string }>; isError?: boolean }> {
  let result: unknown;
  try {
    result = await client.post(route, body);
  } catch (err) {
    // Only retry on network/connection errors, not daemon HTTP errors (4xx/5xx)
    if (!isNetworkError(err)) {
      const msg = err instanceof Error ? err.message : String(err);
      return { content: [{ type: "text", text: `lcm error: ${msg}` }], isError: true };
    }
    // Daemon crashed — attempt auto-restart then retry once.
    // Coalesce concurrent restart attempts so only one ensureDaemon() runs per port.
    const ensure = opts._ensureDaemon ?? ensureDaemon;
    if (!restartInFlight.has(opts.port)) {
      const p = ensure({
          port: opts.port, pidFilePath: opts.pidFilePath, spawnTimeoutMs: 10000,
          expectedVersion: opts.expectedVersion,
          spawnCommand: opts.spawnCommand,
          spawnArgs: opts.spawnArgs,
        })
        .catch(() => { /* non-fatal */ })
        .finally(() => { restartInFlight.delete(opts.port); });
      restartInFlight.set(opts.port, p);
    }
    await restartInFlight.get(opts.port)!.catch(() => { /* non-fatal */ });
    try {
      result = await client.post(route, body);
    } catch (retryErr) {
      const msg = retryErr instanceof Error ? retryErr.message : String(retryErr);
      return { content: [{ type: "text", text: `lcm daemon unavailable: ${msg}` }], isError: true };
    }
  }
  return { content: [{ type: "text", text: JSON.stringify(result, null, 2) }] };
}

export async function handleAgentWorkerTool(
  client: Pick<DaemonClient, "get" | "post">, action: "claim" | "submit", args: Record<string, unknown>,
  env: NodeJS.ProcessEnv = process.env, cwd = process.cwd(),
): Promise<{ content: Array<{ type: "text"; text: string }>; isError?: boolean }> {
  try {
    const worker = createAgentWorkerTransport(client, "mcp", env, cwd);
    const result = action === "claim" ? await worker.claim() : await worker.submit(args as AgentSubmission);
    return { content: [{ type: "text", text: JSON.stringify(result, null, 2) }] };
  } catch (error) { return { isError: true, content: [{ type: "text", text: workerRefusal(error).message }] }; }
}

export async function startMcpServer(): Promise<void> {
  const paths = createLcmPaths(lcmHome());
  const catalog = createToolCatalog(localTools(paths));
  const config = loadDaemonConfig(paths.configPath);
  const port = config.daemon.port;
  const pidFilePath = paths.pidPath;

  const lcmBin = cliEntrypoint();
  const daemon = await ensureDaemon({
    port, pidFilePath, spawnTimeoutMs: 10000,
    expectedVersion: PKG_VERSION,
    spawnCommand: process.execPath,
    spawnArgs: [lcmBin, "daemon", "start", "--automatic"],
  });
  // Newest wins: an incompatible newer daemon is never used. The server still answers
  // tools/list so the client stays connected, but every call reports the repair. One
  // helper interprets every ownership verdict for hooks and this server alike.
  const notice = daemonNotice(daemon, PKG_VERSION);
  if (notice) process.stderr.write(`${notice.line}\n`);
  const incompatibleNotice = notice && !notice.usable ? notice.line : undefined;

  const client = new DaemonClient(`http://127.0.0.1:${port}`, paths.tokenPath);
  const server = new Server({ name: "lcm", version: PKG_VERSION ?? "unknown" }, { capabilities: { tools: {} } });

  // The search tool is described per project: a caller must be told the author
  // and pivot languages before its first search, not after an empty result.
  server.setRequestHandler("tools/list", async () => {
    const languages = pivotLanguagesFor(process.env.PWD ?? process.cwd(), config.search.pivotLanguage, paths);
    return { tools: catalog.list(languages) };
  });

  server.setRequestHandler("tools/call", async (req) => {
    if (incompatibleNotice) return { content: [{ type: "text", text: incompatibleNotice }], isError: true };
    if (req.params.name === "lcm_store" && excludedWorkerContext(paths)) {
      return { isError: true, content: [{ type: "text", text: `Worker sessions cannot store promoted memory. ${WORKER_WARNING}` }] };
    }
    const rawArgs = req.params.arguments ?? {};
    // Guard: ensure rawArgs is a plain object
    if (typeof rawArgs !== "object" || rawArgs === null || Array.isArray(rawArgs)) {
      return { content: [{ type: "text", text: `Invalid arguments for tool ${req.params.name}: must be an object` }], isError: true };
    }
    const resolved = catalog.resolve(req.params.name, rawArgs as Record<string, unknown>);
    const localCall = resolved?.destination.kind === "local"
      ? { handler: resolved.destination.handler, args: resolved.args }
      : undefined;
    // Register before admission so a held stop drains work that already began.
    const unregister = localCall ? registerDaemonActivity(pidFilePath) : undefined;
    try {
      const hold = readHold(pidFilePath);
      if (hold) {
        return { content: [{ type: "text", text: `lcm daemon held down until ${hold.until}. Release it with: lcm daemon start` }], isError: true };
      }
      if (localCall) {
        try {
          const text = await localCall.handler(localCall.args);
          return { content: [{ type: "text", text }] };
        } catch (err) {
          const msg = err instanceof Error ? err.message : String(err);
          return { content: [{ type: "text", text: `lcm error: ${msg}` }], isError: true };
        }
      }
    } finally {
      unregister?.();
    }

    if (!resolved) return { content: [{ type: "text", text: `Unknown tool: ${req.params.name}` }], isError: true };
    if (resolved.destination.kind === "worker") return handleAgentWorkerTool(client, resolved.destination.action, resolved.args);
    if (resolved.destination.kind !== "daemon") throw new Error("Unreachable local tool destination");
    const args = resolved.destination.route === "/store"
      ? {
        ...resolved.args,
        metadata: {
          ...resolved.args.metadata as Record<string, unknown> | undefined,
          sessionId: (resolved.args.metadata as Record<string, unknown> | undefined)?.sessionId
            ?? (process.env.CLAUDE_CODE_SESSION_ID || process.env.CODEX_THREAD_ID || "manual"),
        },
      }
      : resolved.args;
    const body = { ...args, cwd: process.env.PWD ?? process.cwd() };
    return handleDaemonRequest(client, resolved.destination.route, body, {
      port, pidFilePath,
      spawnCommand: process.execPath,
      spawnArgs: [lcmBin, "daemon", "start", "--automatic"],
      expectedVersion: PKG_VERSION,
    });
  });

  serveStdio(() => server, { legacy: "serve" });
}
