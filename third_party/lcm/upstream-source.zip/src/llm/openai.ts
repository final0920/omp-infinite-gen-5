import OpenAI from "openai";
import type { LcmSummarizeFn, SummarizeContext, SummarizerUsage } from "./types.js";
import { buildSummaryPrompt } from "./prompt.js";
import { acceptSummaryText, rejectCutSummary, SummaryRejectedError } from "./summary-rejection.js";
import { DEFAULT_HTTP_TIMEOUT_MS, isRequestTimeout, withRequestDeadline } from "./http-timeout.js";
import { completionFetch } from "./http-fetch.js";
import { withEndpointSlot } from "./endpoint-concurrency.js";
import {
  LCM_SUMMARIZER_SYSTEM_PROMPT,
  resolveTargetTokens,
  resolveMaxOutputTokens,
} from "../summarize.js";

type OpenAISummarizerOptions = {
  model: string;
  /** Absent means the SDK's own default (OPENAI_BASE_URL, else the OpenAI API). */
  baseURL?: string;
  apiKey?: string;
  /** Extra top-level request fields (`reasoning`, `thinking`, ...), validated at config load. */
  body?: Record<string, unknown>;
  /** Names this endpoint in a rejection; the provider type when unset. */
  label?: string;
  timeoutMs?: number;
  maxConcurrent?: number;
  _clientOverride?: any;
  _retryDelayMs?: number;
};

function sleep(ms: number): Promise<void> {
  return new Promise((r) => setTimeout(r, ms));
}

/** A 4xx other than a timeout or a rate limit: a refused key or request, not a transient failure. */
function isClientError(err: any): boolean {
  const status = err?.status;
  return typeof status === "number" && status >= 400 && status < 500 && status !== 408 && status !== 429;
}

/**
 * Every provider charges; OpenRouter is the only OpenAI-compatible endpoint
 * that REPORTS the charge back (`usage.cost`), and only when the request opts
 * in. Plain servers reject unknown top-level fields, so the flag is host-scoped.
 */
function isOpenRouter(baseURL: string | undefined): boolean {
  if (!baseURL) return false;
  try {
    return new URL(baseURL).hostname.endsWith("openrouter.ai");
  } catch {
    return false;
  }
}

/**
 * OpenAI reports `cached_tokens` as a SUBSET of `prompt_tokens`, which is
 * already the normalized convention: no re-basing needed, unlike Anthropic.
 */
function toUsage(response: any, fallbackModel: string): SummarizerUsage | undefined {
  const usage = response?.usage;
  if (!usage) return undefined;
  const inputTokens = usage.prompt_tokens;
  const outputTokens = usage.completion_tokens;
  const choice = response.choices?.[0];
  const content = choice?.message?.content;
  // The same judgement acceptSummaryText makes: content that is not text is no answer.
  const rejectionReason = choice?.finish_reason === "length" ? "length"
    : typeof content !== "string" || !content.trim() ? "whitespace" : undefined;
  const timing = (value: unknown): number | undefined =>
    typeof value === "number" && Number.isFinite(value) && value >= 0 ? value : undefined;
  return {
    provider: "openai",
    model: response.model || fallbackModel,
    inputTokens,
    cachedInputTokens: usage.prompt_tokens_details?.cached_tokens,
    outputTokens,
    tokensUsed: usage.total_tokens ?? (inputTokens ?? 0) + (outputTokens ?? 0),
    // Absent stays absent: a consumer must read it as "unknown", not "free".
    costUsd: typeof usage.cost === "number" ? usage.cost : undefined,
    prefillMs: timing(response.timings?.prompt_ms),
    decodeMs: timing(response.timings?.predicted_ms),
    ...(rejectionReason ? { failed: true, rejectionReason } : {}),
  };
}

export function createOpenAISummarizer(opts: OpenAISummarizerOptions): LcmSummarizeFn {
  const client =
    opts._clientOverride ??
    new OpenAI({
      ...(opts.baseURL ? { baseURL: opts.baseURL } : {}),
      apiKey: opts.apiKey || "local", // many local servers require a non-empty key
      maxRetries: 0,
      fetch: completionFetch,
    });
  const retryDelayMs = opts._retryDelayMs ?? 1000;
  const MAX_RETRIES = 3;
  const askForCostAccounting = isOpenRouter(opts.baseURL);

  return async function summarize(text, aggressive, ctx: SummarizeContext = {}): Promise<string> {
    const estimatedInputTokens = Math.ceil(text.length / 4);
    const targetTokens =
      ctx.targetTokens ??
      resolveTargetTokens({
        inputTokens: estimatedInputTokens,
        mode: aggressive ? "aggressive" : "normal",
        isCondensed: ctx.isCondensed ?? false,
        condensedTargetTokens: 2000,
      });

    const prompt = buildSummaryPrompt(text, aggressive, { ...ctx, targetTokens });
    const maxOutputTokens = ctx.maxOutputTokens ?? resolveMaxOutputTokens(targetTokens);

    let lastError: Error | undefined;

    for (let attempt = 0; attempt < MAX_RETRIES; attempt++) {
      try {
        const timeoutMs = opts.timeoutMs ?? DEFAULT_HTTP_TIMEOUT_MS;
        const response = await withEndpointSlot(opts.label ?? "openai", opts.maxConcurrent, timeoutMs, () => withRequestDeadline<any>(timeoutMs, (options) => client.chat.completions.create({
          // Vendor fields absent from the OpenAI SDK types go first, so every field
          // generated below wins. Nothing extra is sent when unset: servers that
          // reject unknown fields keep working.
          ...opts.body,
          model: opts.model,
          ...(askForCostAccounting ? { usage: { include: true } } : {}),
          max_tokens: maxOutputTokens,
          // Merge system content into user message for compatibility with local
          // servers (e.g. MLX/llama.cpp) that don't support role:"system".
          messages: [
            { role: "user", content: `${ctx.taskPrompt ?? LCM_SUMMARIZER_SYSTEM_PROMPT}\n\n${prompt}` },
          ],
        }, options)), ctx.workClass);

        // Reported before the answer is judged: a reasoning model that spends
        // the whole budget thinking still charged for those tokens.
        const usage = toUsage(response, opts.model);
        if (usage) ctx.onUsage?.(usage);

        const choice = response.choices[0];
        // A length stop is a cut-off tail, not a summary, however readable it looks.
        if (choice?.finish_reason === "length") {
          rejectCutSummary({
            reason: "length", provider: opts.label ?? "openai", model: response.model || opts.model, maxOutputTokens,
            outputTokens: usage?.outputTokens, text: choice?.message?.content,
          }, ctx.onCut);
        }
        // Empty content is a failure, not a summary: falling back to a slice of
        // the input would persist raw conversation text as a fake summary.
        return acceptSummaryText(choice?.message?.content ?? "", opts.label ?? "openai", usage?.model ?? opts.model);
      } catch (err: any) {
        if (isRequestTimeout(err)) throw err;
        if (isClientError(err)) throw err; // the same request fails the same way: no retry
        if (err instanceof SummaryRejectedError && !err.retryable) throw err;
        lastError = err;
        if (attempt < MAX_RETRIES - 1) await sleep(retryDelayMs * Math.pow(2, attempt));
      }
    }
    throw lastError;
  };
}
