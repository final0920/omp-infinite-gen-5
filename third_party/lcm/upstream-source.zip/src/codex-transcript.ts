/**
 * Parser for Codex CLI session transcript files.
 *
 * Codex stores sessions in ~/.codex/sessions/YYYY/MM/DD/rollout-*.jsonl
 * and archives them in ~/.codex/archived_sessions/<name>.jsonl.
 *
 * Each JSONL line is an event object with a top-level `type` and `payload`:
 *
 *   { type: "session_meta", payload: { id, cwd, ... } }
 *   { type: "response_item", payload: { type: "message", role: "user"|"assistant"|..., content: [...] } }
 *   { type: "event_msg", payload: { ... } }
 *   ...
 *
 * Content blocks for user messages use `type: "input_text"` and for assistant
 * messages use `type: "output_text"` (both carry a `text` string field).
 */

import { readdirSync, readFileSync, existsSync, lstatSync, openSync, readSync, closeSync, type Dirent } from "node:fs";
import { join, basename } from "node:path";
import { homedir } from "node:os";
import { StringDecoder } from "node:string_decoder";
import { TextDecoder } from "node:util";
import { isWorkerClaim, workerPayloadJobIds } from "./worker-markers.js";
import { transcriptToolInvocation, transcriptToolResult, type TranscriptToolCall } from "./tool-calls.js";
import { estimateTokens, transcriptEventTime } from "./transcript.js";
import type { ParsedMessage } from "./transcript.js";

// ---------------------------------------------------------------------------
// Types matching the Codex JSONL event format
// ---------------------------------------------------------------------------

interface CodexContentBlock {
  type?: string;
  text?: string;
}

interface CodexResponseItemPayload {
  type?: string;
  role?: string;
  content?: string | CodexContentBlock[];
  /** Tool name on a `function_call` / `custom_tool_call`. */
  name?: string;
  /** Tool output on a `*_output` record. */
  output?: unknown;
  input?: unknown;
  is_error?: boolean;
  arguments?: unknown;
  call_id?: string;
}

export interface CodexSessionMeta {
  id?: string;
  cwd?: string;
  history_mode?: string;
  subagent_history_start_ordinal?: number;
  forked_from_id?: string;
  parent_thread_id?: string;
}

interface CodexLine {
  type?: string;
  timestamp?: string;
  payload?: CodexResponseItemPayload | CodexSessionMeta | Record<string, unknown>;
}

interface CodexTurnContext {
  turn_id?: string;
  model?: string;
}

export interface ParsedCodexTranscriptRecord {
  toolCalls?: TranscriptToolCall[];
  message?: ParsedMessage;
  sessionMeta?: CodexSessionMeta;
}

export interface ParseCodexTranscriptOptions {
  /** Include a valid final JSONL record even when the file has no trailing newline. */
  includeTrailingRecord?: boolean;
  /** Throw on unreadable input or malformed records instead of skipping them. */
  strict?: boolean;
}

const STRICT_UTF8_DECODER = new TextDecoder("utf-8", { fatal: true });

/** Decode transcript bytes without silently replacing invalid UTF-8. @internal */
export function decodeCodexTranscriptUtf8(bytes: Uint8Array, byteOffset?: number): string {
  try {
    return STRICT_UTF8_DECODER.decode(bytes);
  } catch {
    const location = byteOffset === undefined ? "" : ` at byte offset ${byteOffset}`;
    throw new Error(`Invalid Codex transcript UTF-8${location}`);
  }
}

// ---------------------------------------------------------------------------
// Text extraction
// ---------------------------------------------------------------------------

function extractCodexText(content: string | CodexContentBlock[] | undefined): string {
  if (typeof content === "string") return content.trim();
  if (!Array.isArray(content)) return "";
  return content
    .map((b) => {
      // Codex uses input_text (user) and output_text (assistant)
      if ((b.type === "input_text" || b.type === "output_text") && typeof b.text === "string") {
        return b.text;
      }
      // Plain text fallback
      if (b.type === "text" && typeof b.text === "string") {
        return b.text;
      }
      return "";
    })
    .filter(Boolean)
    .join("\n")
    .trim();
}

/** Records a tool call, by name. */
const TOOL_CALL_TYPES = new Set(["function_call", "custom_tool_call"]);
/** Records what a tool returned. */
const TOOL_OUTPUT_TYPES = new Set(["function_call_output", "custom_tool_call_output"]);

/**
 * Turns a Codex tool record into a `tool` message, or null when the payload is
 * not one.
 *
 * Codex never labels a message with the `tool` role: it emits the call and its
 * output as their own record types, which the parser used to drop outright —
 * 120 947 of them in a 300-transcript sample. Dropped, a Codex session arrives
 * with no tool rows at all, and the ingest would have to be done twice.
 *
 * A call keeps only its name in the message row. Selected input and result
 * evidence travel separately as tool-call structure, preserving the row shape.
 */
function parseCodexToolRecord(payload: CodexResponseItemPayload): ParsedMessage | null {
  const type = payload.type;
  if (typeof type !== "string") return null;

  if (TOOL_CALL_TYPES.has(type)) {
    const content = typeof payload.name === "string" && payload.name ? payload.name : type;
    let input: Record<string, unknown> | undefined;
    try { input = typeof payload.arguments === "string" ? JSON.parse(payload.arguments) : payload.arguments as Record<string, unknown>; } catch { /* An undecodable call is not a claim marker. */ }
    const workerClaims = payload.call_id && isWorkerClaim(payload.name, input) ? [payload.call_id] : undefined;
    return { role: "tool", content, tokenCount: estimateTokens(content), ...(workerClaims ? { workerClaims } : {}) };
  }

  if (!TOOL_OUTPUT_TYPES.has(type)) return null;
  const output = typeof payload.output === "string"
    ? payload.output
    : extractCodexText(payload.output as string | CodexContentBlock[] | undefined);
  if (!output.trim()) return null;
  const callId = payload.call_id;
  const workerPayloads = callId ? workerPayloadJobIds(output).map(jobId => ({ callId, jobId })) : [];
  return { role: "tool", content: output, tokenCount: estimateTokens(output), ...(workerPayloads.length ? { workerPayloads } : {}) };
}

function codexToolCalls(payload: CodexResponseItemPayload, message?: ParsedMessage): TranscriptToolCall[] {
  if (!payload.call_id) return [];
  if (TOOL_CALL_TYPES.has(payload.type!)) return [
    transcriptToolInvocation(payload.call_id, payload.name || payload.type!, payload.arguments ?? payload.input, message),
  ];
  if (!TOOL_OUTPUT_TYPES.has(payload.type!)) return [];
  const output = typeof payload.output === "string" ? payload.output : extractCodexText(payload.output as CodexContentBlock[]);
  return [{ ...transcriptToolResult(payload.call_id, "codex", { output, error: payload.is_error }), message }];
}

/**
 * Decode one syntactically complete Codex JSONL record.
 *
 * Invalid JSON is intentionally allowed to throw so each caller can apply its
 * own error policy. Valid non-message events and unsupported message roles
 * return an empty result.
 *
 * @internal
 */
export function parseCodexTranscriptRecord(record: string): ParsedCodexTranscriptRecord {
  const value: unknown = JSON.parse(record);
  if (!value || typeof value !== "object" || Array.isArray(value)) return {};

  const obj = value as CodexLine;
  if (obj.type === "session_meta") {
    const meta = obj.payload as CodexSessionMeta | undefined;
    const boundary = meta?.subagent_history_start_ordinal;
    const source = (obj.payload as { source?: { subagent?: { thread_spawn?: { parent_thread_id?: unknown } } } } | undefined)?.source;
    const parent = meta?.parent_thread_id ?? source?.subagent?.thread_spawn?.parent_thread_id;
    return {
      sessionMeta: {
        id: typeof meta?.id === "string" && meta.id ? meta.id : undefined,
        cwd: typeof meta?.cwd === "string" && meta.cwd ? meta.cwd : undefined,
        history_mode: typeof meta?.history_mode === "string" ? meta.history_mode : undefined,
        subagent_history_start_ordinal: typeof boundary === "number" && Number.isSafeInteger(boundary) && boundary >= 0 ? boundary : undefined,
        forked_from_id: typeof meta?.forked_from_id === "string" && meta.forked_from_id ? meta.forked_from_id : undefined,
        parent_thread_id: typeof parent === "string" && parent ? parent : undefined,
      },
    };
  }

  // Only response_item lines carry canonical user/assistant messages. Codex
  // also emits UI projection events which must not be ingested as duplicates.
  if (obj.type !== "response_item") return {};

  const payload = obj.payload as CodexResponseItemPayload | undefined;
  if (!payload) return {};

  const eventAt = transcriptEventTime(obj.timestamp);
  const tool = parseCodexToolRecord(payload);
  if (tool) {
    const message = { ...tool, ...(eventAt ? { eventAt } : {}) };
    const toolCalls = codexToolCalls(payload, message);
    return { message, ...(toolCalls.length ? { toolCalls } : {}) };
  }

  if (payload.type !== "message") {
    const toolCalls = codexToolCalls(payload);
    return toolCalls.length ? { toolCalls } : {};
  }

  const role = payload.role;
  // `tool` joins the two: a Codex transcript can also state the role outright.
  if (role !== "user" && role !== "assistant" && role !== "tool") return {};

  const content = extractCodexText(payload.content);
  if (!content.trim()) return {};

  return {
    message: { role, content, tokenCount: estimateTokens(content), ...(eventAt ? { eventAt } : {}) },
  };
}

// ---------------------------------------------------------------------------
// Exported parser
// ---------------------------------------------------------------------------

/**
 * Parse a Codex JSONL transcript file into the standard ParsedMessage format.
 *
 * The default mode is permissive: unreadable files return an empty array and
 * malformed JSON records are skipped. Strict mode throws sanitized read errors
 * and line-numbered JSON syntax errors. In either mode, syntactically valid
 * non-message events and unsupported message roles are ignored.
 *
 * A valid unterminated final record is included by default for historical
 * imports. Set `includeTrailingRecord: false` for a live file; its final record
 * is then deferred without validation until a newline makes it complete.
 */
export function parseCodexTranscript(
  transcriptPath: string,
  options: ParseCodexTranscriptOptions = {},
): ParsedMessage[] {
  let bytes: Buffer;
  try {
    bytes = readFileSync(transcriptPath);
  } catch {
    if (options.strict) throw new Error("Codex transcript is unreadable");
    return [];
  }
  const raw = options.strict
    ? decodeCodexTranscriptUtf8(bytes)
    : bytes.toString("utf8");

  const messages: ParsedMessage[] = [];
  const lines = raw.split("\n");
  if (options.includeTrailingRecord === false && !raw.endsWith("\n")) {
    // Active Codex sessions may be observed while their final JSONL record is
    // still being written. Defer it until a later capture sees the newline.
    lines.pop();
  }

  for (const [index, line] of lines.entries()) {
    const trimmed = line.trim();
    if (!trimmed) continue;

    let parsed: ParsedCodexTranscriptRecord;
    try {
      parsed = parseCodexTranscriptRecord(trimmed);
    } catch {
      if (options.strict) {
        throw new Error(`Invalid Codex transcript JSONL at line ${index + 1}`);
      }
      continue;
    }

    if (parsed.message) messages.push(parsed.message);
  }

  return messages;
}

/** Maps each Codex turn id to the model recorded in its `turn_context` entry. */
export function extractCodexTurnModels(transcriptPath: string): Map<string, string> {
  let raw: string;
  try {
    raw = readFileSync(transcriptPath, "utf-8");
  } catch {
    return new Map();
  }
  const models = new Map<string, string>();
  for (const line of raw.split("\n")) {
    try {
      const entry = JSON.parse(line) as { type?: unknown; payload?: CodexTurnContext };
      const turnId = entry.payload?.turn_id;
      const model = entry.payload?.model;
      if (entry.type === "turn_context" && typeof turnId === "string" && turnId && typeof model === "string" && model) {
        models.set(turnId, model);
      }
    } catch { /* skip malformed lines */ }
  }
  return models;
}

/**
 * Extract the working directory from a Codex session JSONL file.
 * Returns undefined if the session_meta line cannot be found/parsed.
 */
export function extractCodexSessionCwd(transcriptPath: string): string | undefined {
  return extractCodexSessionMeta(transcriptPath)?.cwd;
}

export function extractCodexSessionMeta(transcriptPath: string): CodexSessionMeta | undefined {
  let fd: number | undefined;
  try {
    fd = openSync(transcriptPath, "r");
    const buffer = Buffer.alloc(8192);
    const decoder = new StringDecoder("utf8");
    let pending = "";
    // session_meta is a header. Bound malformed/headerless transcript scanning.
    for (let bytes = 0; bytes < 1024 * 1024;) {
      const count = readSync(fd, buffer, 0, buffer.length, null);
      bytes += count;
      pending += count === 0 ? decoder.end() : decoder.write(buffer.subarray(0, count));
      const lines = pending.split("\n");
      pending = count === 0 ? "" : lines.pop() ?? "";
      for (const line of lines) {
        try {
          const meta = parseCodexTranscriptRecord(line).sessionMeta;
          if (meta) return meta;
        } catch { /* skip malformed lines */ }
      }
      if (count === 0) break;
    }
  } catch {
    return undefined;
  } finally {
    if (fd !== undefined) closeSync(fd);
  }

  return undefined;
}

// ---------------------------------------------------------------------------
// Session discovery
// ---------------------------------------------------------------------------

export interface CodexSessionFile {
  path: string;
  sessionId: string;
  mtime: number;
  cwd?: string;
}

/**
 * Discover Codex transcript files under a root directory.
 *
 * Supported layouts:
 *   - Flat:  <root>/<name>.jsonl         (archived_sessions/)
 *   - Nested: <root>/<id>/<id>.jsonl or <root>/YYYY/MM/DD/rollout-*.jsonl
 */
export function findCodexSessionFiles(rootDir: string): CodexSessionFile[] {
  const files: CodexSessionFile[] = [];
  let entries: Dirent[];
  try {
    if (!existsSync(rootDir) || lstatSync(rootDir).isSymbolicLink()) return files;
    entries = readdirSync(rootDir, { withFileTypes: true });
  } catch {
    // Discovery is best-effort: an unreadable directory must not abort the walk.
    return files;
  }

  for (const entry of entries) {
    // Flat layout: rootDir/<name>.jsonl
    if (entry.isFile() && !entry.isSymbolicLink() && entry.name.endsWith(".jsonl")) {
      try {
        const full = join(rootDir, entry.name);
        const st = lstatSync(full);
        if (st.isSymbolicLink()) continue; // skip symlinks
        const meta = extractCodexSessionMeta(full);
        files.push({
          path: full,
          sessionId: meta?.id ?? basename(entry.name, ".jsonl"),
          mtime: st.mtimeMs,
          cwd: meta?.cwd,
        });
      } catch {
        // skip unreadable entries
      }
      continue;
    }

    // Walk dated rollouts and legacy nested sessions without following symlinks.
    if (entry.isDirectory() && !entry.isSymbolicLink()) {
      files.push(...findCodexSessionFiles(join(rootDir, entry.name)));
    }
  }

  return files.sort((a, b) => {
    const d = a.mtime - b.mtime;
    if (d !== 0) return d;
    return a.sessionId.localeCompare(b.sessionId);
  });
}

/**
 * Collect all Codex transcript files from a Codex home directory.
 *
 * Searches:
 *   - <codexDir>/archived_sessions/*.jsonl  (flat layout)
 *   - <codexDir>/sessions/ recursively    (dated and legacy layouts)
 *
 * Defaults to ~/.codex when codexDir is omitted.
 */
export function findAllCodexTranscripts(codexDir?: string): CodexSessionFile[] {
  const root = codexDir ?? join(homedir(), ".codex");
  const results: CodexSessionFile[] = [];

  // Archived sessions (flat)
  results.push(...findCodexSessionFiles(join(root, "archived_sessions")));

  // Active sessions (nested)
  results.push(...findCodexSessionFiles(join(root, "sessions")));

  // Prefer the latest transcript for an identity, even if an older archive exists.
  // Archive order is a deterministic tie-breaker for equal modification times.
  const seen = new Map<string, CodexSessionFile>();
  for (const f of results) {
    const existing = seen.get(f.sessionId);
    if (!existing || f.mtime > existing.mtime) seen.set(f.sessionId, f);
  }

  return [...seen.values()].sort((a, b) => {
    const d = a.mtime - b.mtime;
    if (d !== 0) return d;
    return a.sessionId.localeCompare(b.sessionId);
  });
}
