export type MemoryHintCandidate = {
  id: string;
  hint: string;
  /** The project this hint was surfaced from, when it differs from the project being served. */
  projectId?: string;
};

export type MemoryHintSelection = {
  hints: string[];
  ids: string[];
  /** Parallel to `ids`: the source project of a hint that did not come from the served project, null otherwise. */
  projectIds: (string | null)[];
  availableHintBytes: number;
  usedHintBytes: number;
  dedupedCount: number;
  droppedForBudget: number;
};

const MEMORY_CONTEXT_INTRO =
  "Relevant context from previous sessions (use lcm_expand for details; an id suffixed @<projectId> came from another project — pass that as projectId to lcm_describe/lcm_expand):";

/** Renders one surfaced id in the form lcm_describe/lcm_expand accept: bare, or `<id>@<projectId>` when it did not come from the project being served. */
function renderSurfacedId(id: string, projectId: string | null | undefined): string {
  return projectId ? `${id}@${projectId}` : id;
}

function normalizeHint(hint: string): string {
  return hint.trim().replace(/\s+/g, " ").toLowerCase();
}

function isNearDuplicate(candidate: string, existing: string, minPrefix: number): boolean {
  if (candidate === existing) return true;
  const prefix = Math.max(1, minPrefix);
  return candidate.slice(0, prefix) === existing.slice(0, prefix);
}

function trimTrailingEllipsis(hint: string): string {
  return hint.endsWith("...") ? hint.slice(0, -3).trimEnd() : hint;
}

function fitHintWithinBudget(
  selected: MemoryHintCandidate[],
  candidate: MemoryHintCandidate,
  availableHintBytes: number,
): string | null {
  const selectedProjectIds = selected.map((entry) => entry.projectId ?? null);
  const fullBlock = buildMemoryContext(
    [...selected.map((entry) => entry.hint), candidate.hint],
    [...selected.map((entry) => entry.id), candidate.id],
    [...selectedProjectIds, candidate.projectId ?? null],
  );
  if (fullBlock && Buffer.byteLength(fullBlock, "utf8") <= availableHintBytes) {
    return candidate.hint;
  }

  const baseHint = trimTrailingEllipsis(candidate.hint);
  const baseHintCodePoints = Array.from(baseHint);

  // Binary search for the longest prefix (in Unicode code points) that fits within the budget.
  // Using code points ensures Buffer.byteLength is monotonically non-decreasing as prefix length grows,
  // avoiding issues with UTF-16 surrogate pairs that could break string.slice()-based truncation.
  let lo = 0;
  let hi = baseHintCodePoints.length - 1;
  let bestFit: string | null = null;

  while (lo <= hi) {
    const mid = (lo + hi) >>> 1;
    const truncatedBase = baseHintCodePoints.slice(0, mid + 1).join("");
    const truncated = `${truncatedBase.trimEnd()}...`;
    const block = buildMemoryContext(
      [...selected.map((entry) => entry.hint), truncated],
      [...selected.map((entry) => entry.id), candidate.id],
      [...selectedProjectIds, candidate.projectId ?? null],
    );
    if (block && Buffer.byteLength(block, "utf8") <= availableHintBytes) {
      bestFit = truncated;
      lo = mid + 1; // try a longer prefix
    } else {
      hi = mid - 1; // try a shorter prefix
    }
  }

  return bestFit;
}

/**
 * `notice` is a single line about how to search this project — today, that the
 * author's language differs from the search pivot language, so a query is worth
 * sending with its translation. It rides the block a caller already reads
 * rather than waiting for an empty search to reveal the mismatch.
 */
export function buildMemoryContext(
  hints: string[],
  ids: string[] = [],
  projectIds: (string | null | undefined)[] = [],
  notice?: string,
): string | null {
  if (hints.length === 0) return null;
  const snippets = hints.map((hint) => `- ${hint}`).join("\n");
  const noticeLine = notice ? `\n${notice}` : "";
  const idsComment = ids.length > 0
    ? `\n<!-- surfaced-memory-ids: ${ids.map((id, index) => renderSurfacedId(id, projectIds[index])).join(",")} -->`
    : "";
  return `<memory-context>\n${MEMORY_CONTEXT_INTRO}\n${snippets}${noticeLine}${idsComment}\n</memory-context>`;
}

export function selectMemoryHintsWithinBudget(
  candidates: MemoryHintCandidate[],
  options: {
    totalByteBudget: number;
    reservedForLearningInstruction: number;
    learningInstructionBytes: number;
    maxEmitted: number;
    dedupMinPrefix: number;
  },
): MemoryHintSelection {
  // Reserve the larger of the two: either the configured default or the actual learning instruction size.
  // This ensures hints always have room within the budget, never encroaching on learning instruction space.
  const reserve = Math.max(
    0,
    Math.floor(options.reservedForLearningInstruction),
    Math.floor(options.learningInstructionBytes),
  );
  const availableHintBytes = Math.max(0, Math.floor(options.totalByteBudget) - reserve);
  const maxEmitted = Math.max(0, Math.floor(options.maxEmitted));

  const deduped: MemoryHintCandidate[] = [];
  const seen: string[] = [];
  let dedupedCount = 0;

  for (const candidate of candidates) {
    const trimmedHint = candidate.hint.trim();
    if (!trimmedHint) continue;

    const normalized = normalizeHint(trimmedHint);
    if (seen.some((existing) => isNearDuplicate(normalized, existing, options.dedupMinPrefix))) {
      dedupedCount += 1;
      continue;
    }

    seen.push(normalized);
    deduped.push({ id: candidate.id, hint: trimmedHint, projectId: candidate.projectId });
  }

  const emitted: MemoryHintCandidate[] = [];
  let droppedForBudget = 0;

  for (const candidate of deduped) {
    if (emitted.length >= maxEmitted) {
      droppedForBudget += 1;
      continue;
    }

    const fittedHint = fitHintWithinBudget(emitted, candidate, availableHintBytes);
    if (!fittedHint) {
      droppedForBudget += 1;
      continue;
    }

    emitted.push({ id: candidate.id, hint: fittedHint, projectId: candidate.projectId });
  }

  const hints = emitted.map((candidate) => candidate.hint);
  const ids = emitted.map((candidate) => candidate.id);
  const projectIds = emitted.map((candidate) => candidate.projectId ?? null);
  const block = buildMemoryContext(hints, ids, projectIds);
  const usedHintBytes = block ? Buffer.byteLength(block, "utf8") : 0;

  return {
    hints,
    ids,
    projectIds,
    availableHintBytes,
    usedHintBytes,
    dedupedCount,
    droppedForBudget,
  };
}