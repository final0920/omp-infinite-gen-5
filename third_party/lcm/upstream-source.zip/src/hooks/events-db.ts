// src/hooks/events-db.ts
import type { DatabaseSync } from "node:sqlite";
import { mkdirSync } from "node:fs";
import { dirname } from "node:path";
import { createHash } from "node:crypto";
import type { ExtractedEvent } from "./extractors.js";
import { getLcmConnection, closeLcmConnection, isLcmConnectionOpen } from "../db/connection.js";
import { sanitizeError } from "../daemon/safe-error.js";
import type { SessionClient } from "../session-client.js";

/**
 * Tracks which db paths have already had migrations applied in this process.
 * When a pooled connection is reused (refs > 1), we skip the migration check
 * entirely — it already ran during the first open. Cleared on process exit or
 * when a path is explicitly evicted from the pool.
 */
const _migratedPaths = new Set<string>();

export interface EventRow {
  event_id: number;
  session_id: string;
  seq: number;
  type: string;
  category: string;
  data: string;
  priority: number;
  source_hook: string;
  tool_use_id: string | null;
  turn_id: string | null;
  prompt_hash: string | null;
  prev_event_id: number | null;
  processed_at: string | null;
  created_at: string;
  client: string;
  model: string | null;
}

export interface HealthStats {
  totalEvents: number;
  unprocessed: number;
  errors: number;
  lastCapture: string | null;
  lastError: string | null;
}

interface HookObservationBase {
  sessionId: string;
  harness: "claude-command" | "claude-function" | "codex" | "omp";
  hook: string;
  operation: string;
  reason?: string;
  failureCode?: string;
  operationId?: string;
}

export type HookObservation = HookObservationBase & (
  | { kind: "delivery"; status: "submitted" | "accepted" | "unconfirmed" | "rejected" }
  | { kind: "execution"; status: "completed" | "skipped" | "delegated" | "deferred" | "failed" }
);

export interface HookObservationSummary extends Omit<HookObservationBase, "reason" | "failureCode" | "operationId"> {
  kind: "delivery" | "execution";
  status: string;
  reason: string;
  count: number;
  firstSeen: string;
  lastSeen: string;
}

/** Read health counters without opening, migrating, or mutating the database. */
export function readEventHealthStats(db: DatabaseSync): HealthStats {
  const eventTotals = db.prepare(
    "SELECT COUNT(*) as totalEvents, MAX(created_at) as lastCapture FROM events"
  ).get() as { totalEvents: number; lastCapture: string | null };
  const unprocessedRow = db.prepare(
    "SELECT COUNT(*) as unprocessed FROM events WHERE processed_at IS NULL"
  ).get() as { unprocessed: number };
  // Version 1 sidecars predate error logging; inspection must not migrate them.
  const hasErrorLog = db.prepare(
    "SELECT 1 FROM sqlite_master WHERE type = 'table' AND name = 'error_log'"
  ).get();
  const errorTotals = hasErrorLog
    ? db.prepare(
      "SELECT COUNT(*) as errors, MAX(created_at) as lastError FROM error_log WHERE hook NOT LIKE 'maintenance:%' AND created_at >= datetime('now', '-30 days')"
    ).get() as { errors: number; lastError: string | null }
    : { errors: 0, lastError: null };

  return { ...eventTotals, unprocessed: unprocessedRow.unprocessed, ...errorTotals };
}

export interface PatternReinforcementStats {
  totalCount: number;
  distinctSessions: number;
}

const SCHEMA_VERSION = 9;

const HOOK_OBSERVATION_SQL = `
CREATE TABLE IF NOT EXISTS hook_observation_summary (
  session_id TEXT NOT NULL,
  harness TEXT NOT NULL,
  hook TEXT NOT NULL,
  operation TEXT NOT NULL,
  kind TEXT NOT NULL,
  status TEXT NOT NULL,
  reason TEXT NOT NULL DEFAULT '',
  count INTEGER NOT NULL DEFAULT 0,
  first_seen TEXT NOT NULL DEFAULT (datetime('now')),
  last_seen TEXT NOT NULL DEFAULT (datetime('now')),
  PRIMARY KEY (session_id, harness, hook, operation, kind, status, reason)
);
CREATE INDEX IF NOT EXISTS idx_hook_observation_last_seen ON hook_observation_summary(last_seen);
CREATE TABLE IF NOT EXISTS hook_observation_failures (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  session_id TEXT NOT NULL,
  harness TEXT NOT NULL,
  hook TEXT NOT NULL,
  operation TEXT NOT NULL,
  code TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_hook_observation_failures_session ON hook_observation_failures(session_id, id);
CREATE INDEX IF NOT EXISTS idx_hook_observation_failures_created ON hook_observation_failures(created_at);
CREATE TABLE IF NOT EXISTS hook_observation_seen (
  operation_id TEXT NOT NULL,
  kind TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  PRIMARY KEY (operation_id, kind)
);
CREATE INDEX IF NOT EXISTS idx_hook_observation_seen_created ON hook_observation_seen(created_at);
`;

const SCHEMA_SQL = `
CREATE TABLE IF NOT EXISTS schema_version (version INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS events (
  event_id      INTEGER PRIMARY KEY AUTOINCREMENT,
  session_id    TEXT NOT NULL,
  seq           INTEGER NOT NULL DEFAULT 0,
  type          TEXT NOT NULL,
  category      TEXT NOT NULL,
  data          TEXT NOT NULL,
  priority      INTEGER DEFAULT 3,
  source_hook   TEXT NOT NULL,
  tool_use_id   TEXT,
  turn_id       TEXT,
  prompt_hash   TEXT,
  prev_event_id INTEGER,
  processed_at  TEXT,
  created_at    TEXT DEFAULT (datetime('now')),
  client        TEXT NOT NULL DEFAULT 'claude',
  model         TEXT
);
CREATE INDEX IF NOT EXISTS idx_events_unprocessed ON events(processed_at) WHERE processed_at IS NULL;
CREATE INDEX IF NOT EXISTS idx_events_session ON events(session_id, created_at);
CREATE INDEX IF NOT EXISTS idx_events_pattern_lookup ON events(type, category, data, created_at);
CREATE INDEX IF NOT EXISTS idx_events_tool_use ON events(session_id, tool_use_id);
CREATE INDEX IF NOT EXISTS idx_events_turn ON events(session_id, turn_id);
CREATE INDEX IF NOT EXISTS idx_events_prompt ON events(session_id, prompt_hash);
CREATE TABLE IF NOT EXISTS error_log (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  hook       TEXT NOT NULL,
  error      TEXT NOT NULL,
  session_id TEXT,
  created_at TEXT DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_error_log_created ON error_log(created_at);
${HOOK_OBSERVATION_SQL}
`;

export class EventsDb {
  private db: DatabaseSync;
  private dbPath: string;

  constructor(dbPath: string) {
    mkdirSync(dirname(dbPath), { recursive: true, mode: 0o700 });
    this.dbPath = dbPath;
    // getLcmConnection returns the pooled (or newly-opened) DatabaseSync handle
    // and increments its ref-count. Connections are kept alive across EventsDb
    // instances so that high-frequency hooks (PostToolUse fires 50-200x/session)
    // reuse the same underlying connection instead of opening/closing each time.
    this.db = getLcmConnection(dbPath);
    if (!_migratedPaths.has(dbPath)) {
      try {
        this.db.exec("CREATE TABLE IF NOT EXISTS excluded_worker_sessions(session_id TEXT PRIMARY KEY)");
        this.migrate();
      } catch (e) {
        // Migration failed — release the pooled connection so the ref-count
        // doesn't leak. The constructor will re-throw, so callers see the error.
        closeLcmConnection(dbPath);
        const message = sanitizeError(e instanceof Error ? e.message : String(e));
        throw new Error(message);
      }
      _migratedPaths.add(dbPath);
    }
  }

  /** Enrollment never deletes sidecar history, including processed events. */
  enrollSessions(sessionIds: string[]): void {
    this.db.exec("BEGIN IMMEDIATE");
    try {
      for (const id of sessionIds) {
        if (this.db.prepare("SELECT 1 FROM events WHERE session_id = ? LIMIT 1").get(id)) {
          throw new Error("Worker enrollment refuses existing tool events. Start a fresh dedicated session.");
        }
        this.db.prepare("INSERT OR IGNORE INTO excluded_worker_sessions(session_id) VALUES (?)").run(id);
      }
      this.db.exec("COMMIT");
    } catch (error) { this.db.exec("ROLLBACK"); throw error; }
  }

  excludeSessions(sessionIds: string[], purgeHistory = false): void {
    this.db.exec("BEGIN IMMEDIATE");
    try {
      for (const id of sessionIds) {
        this.db.prepare("INSERT OR IGNORE INTO excluded_worker_sessions(session_id) VALUES (?)").run(id);
        if (purgeHistory) this.db.prepare("DELETE FROM events WHERE session_id = ?").run(id);
      }
      this.db.exec("COMMIT");
    } catch (error) { this.db.exec("ROLLBACK"); throw error; }
  }

  /** Rows written before the column existed have no key and never dedup against. */
  private ensureColumn(name: "tool_use_id" | "turn_id" | "prompt_hash" | "client" | "model", ddl?: string): void {
    const columns = this.db.prepare("PRAGMA table_info(events)").all() as { name: string }[];
    if (!columns.some((c) => c.name === name)) {
      this.db.exec(`ALTER TABLE events ADD COLUMN ${ddl ?? `${name} TEXT`}`);
    }
  }

  /** Rows written before provenance tracking existed read back as the harness that had it first. */
  private ensureProvenanceColumns(): void {
    this.ensureColumn("client", "client TEXT NOT NULL DEFAULT 'claude'");
    this.ensureColumn("model", "model TEXT");
  }

  private migrate(): void {
    // Check if schema_version table exists
    const row = this.db.prepare(
      "SELECT name FROM sqlite_master WHERE type='table' AND name='schema_version'"
    ).get() as { name: string } | undefined;

    if (!row) {
      this.db.exec(SCHEMA_SQL);
      this.db.prepare("INSERT INTO schema_version (version) VALUES (?)").run(SCHEMA_VERSION);
      return;
    }

    const versionRow = this.db.prepare("SELECT version FROM schema_version").get() as { version: number } | undefined;

    // Handle empty schema_version table (table exists but has no rows)
    if (!versionRow) {
      // One transaction: the version row and the repair below must land together, or a crash
      // between them leaves a database that claims v6 without the columns v6 means.
      this.db.exec("BEGIN EXCLUSIVE");
      try {
      this.db.prepare("INSERT INTO schema_version (version) VALUES (?)").run(SCHEMA_VERSION);
      // Ensure latest tables and indexes exist even in this edge case.
      this.db.exec(`
        CREATE TABLE IF NOT EXISTS error_log (
          id         INTEGER PRIMARY KEY AUTOINCREMENT,
          hook       TEXT NOT NULL,
          error      TEXT NOT NULL,
          session_id TEXT,
          created_at TEXT DEFAULT (datetime('now'))
        );
        CREATE INDEX IF NOT EXISTS idx_error_log_created ON error_log(created_at);
        CREATE INDEX IF NOT EXISTS idx_events_pattern_lookup ON events(type, category, data, created_at);
        ${HOOK_OBSERVATION_SQL}
      `);
      // The events table here may predate v4, so the columns have to exist before the indexes.
      this.ensureColumn("tool_use_id");
      this.ensureColumn("turn_id");
      this.ensureColumn("prompt_hash");
      this.ensureProvenanceColumns();
      this.db.exec(`
        CREATE INDEX IF NOT EXISTS idx_events_tool_use ON events(session_id, tool_use_id);
        CREATE INDEX IF NOT EXISTS idx_events_turn ON events(session_id, turn_id);
        CREATE INDEX IF NOT EXISTS idx_events_prompt ON events(session_id, prompt_hash);
      `);
        this.db.exec("COMMIT");
      } catch (e) {
        try { this.db.exec("ROLLBACK"); } catch { /* the transaction is already gone */ }
        throw e;
      }
      return;
    }

    const currentVersion = versionRow.version;

    if (currentVersion < SCHEMA_VERSION) {
      this.db.exec("BEGIN EXCLUSIVE");
      try {
        if (currentVersion < 2) {
          this.db.exec(`
            CREATE TABLE IF NOT EXISTS error_log (
              id         INTEGER PRIMARY KEY AUTOINCREMENT,
              hook       TEXT NOT NULL,
              error      TEXT NOT NULL,
              session_id TEXT,
              created_at TEXT DEFAULT (datetime('now'))
            );
            CREATE INDEX IF NOT EXISTS idx_error_log_created ON error_log(created_at);
          `);
        }
        if (currentVersion < 3) {
          this.db.exec(
            "CREATE INDEX IF NOT EXISTS idx_events_pattern_lookup ON events(type, category, data, created_at)"
          );
        }
        if (currentVersion < 4) {
          this.ensureColumn("tool_use_id");
          this.db.exec(
            "CREATE INDEX IF NOT EXISTS idx_events_tool_use ON events(session_id, tool_use_id)"
          );
        }
        if (currentVersion < 5) {
          this.ensureColumn("prompt_hash");
          this.db.exec(
            "CREATE INDEX IF NOT EXISTS idx_events_prompt ON events(session_id, prompt_hash)"
          );
        }
        if (currentVersion < 6) {
          this.ensureProvenanceColumns();
        }
        if (currentVersion < 7) {
          this.ensureColumn("turn_id");
          this.db.exec("CREATE INDEX IF NOT EXISTS idx_events_turn ON events(session_id, turn_id)");
        }
        if (currentVersion < 8) this.db.exec(HOOK_OBSERVATION_SQL);
        if (currentVersion < 9) this.db.exec(
          "CREATE INDEX IF NOT EXISTS idx_hook_observation_failures_created ON hook_observation_failures(created_at)"
        );
        this.db.prepare("UPDATE schema_version SET version = ?").run(SCHEMA_VERSION);
        this.db.exec("COMMIT");
      } catch (e) {
        try { this.db.exec("ROLLBACK"); } catch { /* ignore */ }
        const message = sanitizeError(e instanceof Error ? e.message : String(e));
        throw new Error(message);
      }
    }
  }

  /** The key a row dedups on: which one it is depends on what produced the event. */
  private insertRow(
    sessionId: string, event: ExtractedEvent, sourceHook: string,
    keys: { toolUseId?: string; turnId?: string; promptHash?: string; client?: SessionClient; model?: string | null } = {},
  ): number {
    if (this.db.prepare("SELECT 1 FROM excluded_worker_sessions WHERE session_id = ?").get(sessionId)) return 0;
    const stmt = this.db.prepare(`
      INSERT INTO events (session_id, seq, type, category, data, priority, source_hook, tool_use_id, turn_id, prompt_hash, client, model)
      VALUES (?, (SELECT COALESCE(MAX(seq), 0) + 1 FROM events WHERE session_id = ?),
              ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    const result = stmt.run(
      sessionId, sessionId,
      event.type, event.category, event.data, event.priority, sourceHook,
      keys.toolUseId ?? null, keys.turnId ?? null, keys.promptHash ?? null,
      keys.client ?? "claude", keys.model ?? null,
    );
    return Number(result.lastInsertRowid);
  }

  insertEvent(
    sessionId: string, event: ExtractedEvent, sourceHook: string, toolUseId?: string,
    client?: SessionClient, model?: string | null, turnId?: string,
  ): number {
    return this.insertRow(sessionId, event, sourceHook, { toolUseId, client, model, turnId });
  }

  /**
   * True when this tool call was already recorded, whichever path recorded it.
   * The command hook and the function-hooks module both receive `tool_use_id`, so a
   * session that runs both (Claude Code's remote gate loads the module without the
   * env var) records each call once instead of twice.
   */
  hasToolCall(sessionId: string, toolUseId: string): boolean {
    const row = this.db.prepare(
      "SELECT 1 FROM events WHERE session_id = ? AND tool_use_id = ? LIMIT 1"
    ).get(sessionId, toolUseId);
    return row !== undefined;
  }

  /**
   * Writes one tool call's events, or none when another path already recorded that call.
   * The check and the inserts share one write transaction: without it, two paths handling
   * the same call could both read "not present" and both insert.
   */
  insertToolCallEvents(
    sessionId: string, events: ExtractedEvent[], sourceHook: string, toolUseId?: string,
    client?: SessionClient, model?: string | null, turnId?: string,
  ): number {
    if (!toolUseId) {
      for (const event of events) this.insertEvent(sessionId, event, sourceHook, undefined, client, model, turnId);
      return events.length;
    }
    this.db.exec("BEGIN IMMEDIATE");
    try {
      if (this.db.prepare("SELECT 1 FROM excluded_worker_sessions WHERE session_id = ?").get(sessionId)) {
        this.db.exec("COMMIT"); return 0;
      }
      const recorded = this.writeToolCallEvents(sessionId, events, sourceHook, toolUseId, client, model, turnId);
      this.db.exec("COMMIT");
      return recorded;
    } catch (e) {
      try { this.db.exec("ROLLBACK"); } catch { /* the transaction is already gone */ }
      throw e;
    }
  }

  private writeToolCallEvents(
    sessionId: string, events: ExtractedEvent[], sourceHook: string, toolUseId?: string,
    client?: SessionClient, model?: string | null, turnId?: string,
  ): number {
    if (toolUseId && this.hasToolCall(sessionId, toolUseId)) return 0;
    for (const event of events) this.insertEvent(sessionId, event, sourceHook, toolUseId, client, model, turnId);
    return events.length;
  }

  /** Persist a tool call and its outcome together, including calls without an id. */
  recordToolCapture(input: {
    sessionId: string; events: ExtractedEvent[]; sourceHook: "PostToolUse" | "PostToolUseFailure";
    toolUseId?: string; client: SessionClient; model: string | null; turnId?: string;
    harness: HookObservation["harness"]; operationId?: string;
  }): number {
    this.db.exec("BEGIN IMMEDIATE");
    try {
      if (this.db.prepare("SELECT 1 FROM excluded_worker_sessions WHERE session_id = ?").get(input.sessionId)) {
        this.db.exec("COMMIT"); return 0;
      }
      const recorded = this.writeToolCallEvents(input.sessionId, input.events, input.sourceHook,
        input.toolUseId, input.client, input.model, input.turnId);
      this.writeHookObservation({
        sessionId: input.sessionId, harness: input.harness, hook: input.sourceHook,
        operation: "tool-capture", kind: "execution", status: "completed",
        reason: input.events.length === 0 ? "no-match" : recorded === 0 ? "duplicate" : "events",
        operationId: input.operationId,
      });
      this.db.exec("COMMIT");
      return recorded;
    } catch (e) {
      try { this.db.exec("ROLLBACK"); } catch { /* the transaction is already gone */ }
      throw e;
    }
  }

  /**
   * True when this session has tool-call events of one client still waiting for a `model`.
   * The daemon fills it from that client's transcript at the next ingest, so a hook whose
   * payload carries no model — Claude Code's never does — leaves the column null in the
   * meantime. Scoped to a client because a transcript only knows its own harness's models.
   */
  hasUnfilledModels(sessionId: string, client: SessionClient = "claude"): boolean {
    const row = this.db.prepare(
      "SELECT 1 FROM events WHERE session_id = ? AND model IS NULL AND tool_use_id IS NOT NULL AND client = ? LIMIT 1"
    ).get(sessionId, client);
    return row !== undefined;
  }

  /** Only call ids still awaiting a model; the transcript index can answer without a file scan. */
  unfilledToolUseIds(sessionId: string, client: SessionClient): string[] {
    const rows = this.db.prepare(`SELECT DISTINCT tool_use_id FROM events
      WHERE session_id = ? AND model IS NULL AND tool_use_id IS NOT NULL AND client = ?`)
      .all(sessionId, client) as Array<{ tool_use_id: string }>;
    return rows.map(row => row.tool_use_id);
  }

  /** The `turn_id`-keyed shape, used where the transcript records a per-turn model (Codex). */
  hasUnfilledTurnModels(sessionId: string, client: SessionClient = "codex"): boolean {
    const row = this.db.prepare(
      "SELECT 1 FROM events WHERE session_id = ? AND model IS NULL AND turn_id IS NOT NULL AND client = ? LIMIT 1",
    ).get(sessionId, client);
    return row !== undefined;
  }

  /**
   * Fills `model` on tool-call events a hook payload could not carry it on, joined by
   * `tool_use_id`. Never overwrites a model already recorded.
   *
   * Scoped to one client: the model is read from that client's transcript, so the update
   * touches only that client's rows. A call id that collides with another client's row is
   * left alone — stamping a model from the wrong harness would be worse provenance than
   * the null this column is allowed to hold. Claude and Oh My Pi both reach this by
   * `tool_use_id`; Codex uses {@link backfillTurnModels} instead.
   */
  backfillToolCallModels(sessionId: string, pairs: ReadonlyMap<string, string>, client: SessionClient = "claude"): number {
    if (pairs.size === 0) return 0;
    const stmt = this.db.prepare(
      "UPDATE events SET model = ? WHERE session_id = ? AND tool_use_id = ? AND model IS NULL AND client = ?"
    );
    let updated = 0;
    this.db.exec("BEGIN IMMEDIATE");
    try {
      for (const [toolUseId, model] of pairs) {
        updated += Number(stmt.run(model, sessionId, toolUseId, client).changes);
      }
      this.db.exec("COMMIT");
    } catch (e) {
      try { this.db.exec("ROLLBACK"); } catch { /* the transaction is already gone */ }
      throw e;
    }
    return updated;
  }

  /** Fills missing models from per-turn transcript records, without crossing turns or clients. */
  backfillTurnModels(sessionId: string, pairs: ReadonlyMap<string, string>, client: SessionClient = "codex"): number {
    if (pairs.size === 0) return 0;
    const stmt = this.db.prepare(
      "UPDATE events SET model = ? WHERE session_id = ? AND turn_id = ? AND model IS NULL AND client = ?",
    );
    let updated = 0;
    this.db.exec("BEGIN IMMEDIATE");
    try {
      for (const [turnId, model] of pairs) updated += Number(stmt.run(model, sessionId, turnId, client).changes);
      this.db.exec("COMMIT");
    } catch (e) {
      try { this.db.exec("ROLLBACK"); } catch { /* the transaction is already gone */ }
      throw e;
    }
    return updated;
  }

  /**
   * True when this prompt's events were already recorded, whichever path recorded them.
   *
   * Unlike a tool call, a prompt carries no id both paths can see: the command hook's
   * stdin has `prompt_id`, the module's `prompt.submit` has only the text. The content
   * hash is what they share. Two identical prompts in one session collapse to one row
   * set, which is right rather than lossy — the extractor is a pure function of the text,
   * so the second set would be a copy of the first.
   */
  hasPromptEvents(sessionId: string, promptHash: string): boolean {
    const row = this.db.prepare(
      "SELECT 1 FROM events WHERE session_id = ? AND prompt_hash = ? LIMIT 1"
    ).get(sessionId, promptHash);
    return row !== undefined;
  }

  /**
   * Writes one prompt's events, or none when another path already recorded that prompt.
   * The check and the inserts share one write transaction, as tool calls do.
   */
  insertPromptEvents(sessionId: string, events: ExtractedEvent[], promptHash?: string): number {
    if (!promptHash) {
      for (const event of events) this.insertRow(sessionId, event, "UserPromptSubmit");
      return events.length;
    }
    this.db.exec("BEGIN IMMEDIATE");
    try {
      const duplicate = this.hasPromptEvents(sessionId, promptHash);
      if (!duplicate) {
        for (const event of events) {
          this.insertRow(sessionId, event, "UserPromptSubmit", { promptHash });
        }
      }
      this.db.exec("COMMIT");
      return duplicate ? 0 : events.length;
    } catch (e) {
      try { this.db.exec("ROLLBACK"); } catch { /* the transaction is already gone */ }
      throw e;
    }
  }

  getUnprocessed(limit = 500): EventRow[] {
    return this.db.prepare(
      "SELECT * FROM events WHERE processed_at IS NULL ORDER BY session_id, seq LIMIT ?"
    ).all(limit) as unknown as EventRow[];
  }

  markProcessed(eventIds: number[]): void {
    if (eventIds.length === 0) return;
    const placeholders = eventIds.map(() => "?").join(",");
    this.db.prepare(
      `UPDATE events SET processed_at = datetime('now') WHERE event_id IN (${placeholders})`
    ).run(...eventIds);
  }

  pruneProcessed(olderThanDays: number): number {
    const result = this.db.prepare(
      `DELETE FROM events WHERE processed_at IS NOT NULL
       AND processed_at < datetime('now', '-' || ? || ' days')`
    ).run(olderThanDays);
    return Number(result.changes);
  }

  setPrevEventId(eventId: number, prevEventId: number): void {
    this.db.prepare("UPDATE events SET prev_event_id = ? WHERE event_id = ?")
      .run(prevEventId, eventId);
  }

  getPatternReinforcement(type: string, category: string, data: string, maxAgeDays = 90): PatternReinforcementStats {
    const row = this.db.prepare(
      `SELECT COUNT(*) as totalCount,
              COUNT(DISTINCT session_id) as distinctSessions
       FROM events
       WHERE type = ?
         AND category = ?
         AND data = ?
         AND created_at >= datetime('now', '-' || ? || ' days')`
    ).get(type, category, data, maxAgeDays) as unknown as PatternReinforcementStats | undefined;

    return row ?? { totalCount: 0, distinctSessions: 0 };
  }

  logHookError(hook: string, error: unknown, sessionId?: string): void {
    const msg = error instanceof Error ? error.message : String(error);
    this.db.prepare(
      "INSERT INTO error_log (hook, error, session_id) VALUES (?, ?, ?)"
    ).run(hook, msg, sessionId ?? null);
  }

  /** Aggregate operational metadata; a retained operation id counts only once. */
  recordHookObservation(observation: HookObservation): boolean {
    this.db.exec("BEGIN IMMEDIATE");
    try {
      const recorded = this.writeHookObservation(observation);
      this.db.exec("COMMIT");
      return recorded;
    } catch (e) {
      try { this.db.exec("ROLLBACK"); } catch { /* the transaction is already gone */ }
      throw e;
    }
  }

  private writeHookObservation(observation: HookObservation): boolean {
    const fields = [observation.harness, observation.hook, observation.operation, observation.kind,
      observation.status, observation.reason ?? "", observation.failureCode ?? ""];
    if (fields.some((value) => value.length > 80 || !/^[a-zA-Z0-9_.:-]*$/.test(value))) {
      throw new Error("invalid hook observation field");
    }
    if (observation.operationId && observation.operationId.length > 160) {
      throw new Error("hook operation id is too long");
    }
    const reason = observation.reason ?? "";
      if (observation.operationId) {
        const scopedId = createHash("sha256").update(JSON.stringify([
          observation.sessionId, observation.harness, observation.hook,
          observation.operation, observation.operationId,
        ])).digest("hex");
        const inserted = this.db.prepare(
          "INSERT OR IGNORE INTO hook_observation_seen (operation_id, kind) VALUES (?, ?)"
        ).run(scopedId, observation.kind);
        if (inserted.changes === 0) return false;
      }
      this.db.prepare(`
        INSERT INTO hook_observation_summary
          (session_id, harness, hook, operation, kind, status, reason, count)
        VALUES (?, ?, ?, ?, ?, ?, ?, 1)
        ON CONFLICT(session_id, harness, hook, operation, kind, status, reason)
        DO UPDATE SET count = count + 1, last_seen = datetime('now')
      `).run(observation.sessionId, observation.harness, observation.hook,
        observation.operation, observation.kind, observation.status, reason);
      if ((observation.status === "failed" || observation.status === "rejected") && observation.failureCode) {
        this.db.prepare(`
          INSERT INTO hook_observation_failures
            (session_id, harness, hook, operation, code)
          VALUES (?, ?, ?, ?, ?)
        `).run(observation.sessionId, observation.harness, observation.hook,
          observation.operation, observation.failureCode);
        this.db.prepare(`
          DELETE FROM hook_observation_failures
          WHERE session_id = ? AND id NOT IN (
            SELECT id FROM hook_observation_failures WHERE session_id = ? ORDER BY id DESC LIMIT 64
          )
        `).run(observation.sessionId, observation.sessionId);
      }
      this.pruneHookObservations();
      return true;
  }

  getHookObservationSummary(sessionId: string): HookObservationSummary[] {
    const rows = this.db.prepare(`
      SELECT session_id AS sessionId, harness, hook, operation, kind, status, reason,
             count, first_seen AS firstSeen, last_seen AS lastSeen
      FROM hook_observation_summary WHERE session_id = ?
      ORDER BY hook, operation, kind, status, reason
    `).all(sessionId);
    return rows as unknown as HookObservationSummary[];
  }

  pruneHookObservations(olderThanDays = 7): void {
    const age = `-${Math.max(1, Math.floor(olderThanDays))} days`;
    this.db.prepare("DELETE FROM hook_observation_summary WHERE last_seen < datetime('now', ?)").run(age);
    this.db.prepare("DELETE FROM hook_observation_failures WHERE created_at < datetime('now', ?)").run(age);
    this.db.prepare("DELETE FROM hook_observation_seen WHERE created_at < datetime('now', ?)").run(age);
  }

  getHealthStats(): HealthStats {
    return readEventHealthStats(this.db);
  }

  pruneUnprocessed(maxRows = 10_000, maxAgeDays = 30): { pruned: number } {
    let pruned = 0;
    this.db.exec("BEGIN");
    try {
      const ageCountRow = this.db.prepare(
        `SELECT COUNT(*) as c FROM events
         WHERE processed_at IS NULL
         AND created_at < datetime('now', '-' || ? || ' days')`
      ).get(maxAgeDays) as { c: number };
      const ageCount = ageCountRow.c;

      const totalUnprocessedRow = this.db.prepare(
        "SELECT COUNT(*) as c FROM events WHERE processed_at IS NULL"
      ).get() as { c: number };
      const totalUnprocessed = totalUnprocessedRow.c;

      const remainingAfterAge = totalUnprocessed - ageCount;
      let excess = 0;
      if (remainingAfterAge > maxRows) {
        excess = remainingAfterAge - maxRows;
      }

      pruned = ageCount + excess;

      if (pruned > 0) {
        this.db.prepare(
          "INSERT INTO error_log (hook, error, session_id) VALUES (?, ?, NULL)"
        ).run("maintenance:pruneUnprocessed", `pruned ${pruned} unprocessed events (age/cap limit)`);
      }

      if (ageCount > 0) {
        this.db.prepare(
          `DELETE FROM events WHERE processed_at IS NULL
           AND event_id IN (
             SELECT event_id FROM events WHERE processed_at IS NULL
             AND created_at < datetime('now', '-' || ? || ' days')
           )`
        ).run(maxAgeDays);
      }

      if (excess > 0) {
        this.db.prepare(
          `DELETE FROM events WHERE event_id IN (
             SELECT event_id FROM events WHERE processed_at IS NULL
             ORDER BY event_id ASC LIMIT ?
           )`
        ).run(excess);
      }

      this.db.exec("COMMIT");
    } catch (e) {
      try { this.db.exec("ROLLBACK"); } catch { /* ignore */ }
      throw e;
    }
    return { pruned };
  }

  pruneErrorLog(olderThanDays = 30): number {
    const result = this.db.prepare(
      "DELETE FROM error_log WHERE created_at < datetime('now', '-' || ? || ' days')"
    ).run(olderThanDays);
    return Number(result.changes);
  }

  /** Expose raw DB for testing only. */
  raw(): DatabaseSync {
    return this.db;
  }

  close(): void {
    // Decrement pool ref-count. The underlying connection stays open as long as
    // other callers hold a reference — it is only closed when refs reach 0.
    closeLcmConnection(this.dbPath);
    // If the connection was fully evicted from the pool, invalidate the
    // migration-done cache so the next open re-runs migrations on a fresh handle.
    if (!isLcmConnectionOpen(this.dbPath)) {
      _migratedPaths.delete(this.dbPath);
    }
  }
}

/**
 * Clear the migration-done cache. Intended for tests that create/destroy temp
 * databases and need migration to re-run on the same path.
 *
 * @internal
 */
export function _resetMigratedPathsForTesting(): void {
  _migratedPaths.clear();
}
