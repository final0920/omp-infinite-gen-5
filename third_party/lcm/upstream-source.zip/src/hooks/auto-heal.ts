import { readFileSync, writeFileSync, existsSync, mkdirSync, appendFileSync } from "node:fs";
import { homedir } from "node:os";
import { join, dirname } from "node:path";
import { REQUIRED_HOOKS, mergeClaudeSettings } from "../../installer/install.js";
import type { LcmPaths } from "../lcm-paths.js";

export interface AutoHealDeps {
  readFileSync: (path: string, encoding: string) => string;
  writeFileSync: (path: string, data: string) => void;
  existsSync: (path: string) => boolean;
  mkdirSync: (path: string, opts?: { recursive: boolean }) => void;
  appendFileSync: (path: string, data: string) => void;
  settingsPath: string;
  logPath: string;
}

function defaultDeps(paths: LcmPaths): AutoHealDeps {
  return {
    readFileSync: (p, enc) => readFileSync(p, enc as BufferEncoding),
    writeFileSync,
    existsSync,
    mkdirSync,
    appendFileSync,
    settingsPath: join(homedir(), ".claude", "settings.json"),
    logPath: join(paths.home, "auto-heal.log"),
  };
}

function hasHookCommand(entries: any[], command: string): boolean {
  return entries.some((entry: any) =>
    Array.isArray(entry.hooks) && entry.hooks.some((h: any) => h.command === command)
  );
}

export function validateAndFixHooks(pathsOrDeps: LcmPaths | AutoHealDeps, injectedDeps?: AutoHealDeps): void {
  const paths = "home" in pathsOrDeps ? pathsOrDeps : { home: dirname(pathsOrDeps.logPath) } as LcmPaths;
  const deps = "home" in pathsOrDeps ? (injectedDeps ?? defaultDeps(paths)) : pathsOrDeps;
  try {
    if (!deps.existsSync(deps.settingsPath)) return;

    const settings: any = JSON.parse(deps.readFileSync(deps.settingsPath, "utf-8"));

    // Hooks are owned by plugin.json — if they leaked into settings.json
    // (from old installer or manual edits), remove them to prevent double-firing.
    const hooks = settings.hooks ?? {};

    // Migration: rewrite "lcm compact" (without --hook) → append "--hook".
    // Only exact match "lcm compact" on PreCompact event to avoid changing semantics
    // for user-custom variants like "lcm compact --all" where --hook would make --all a no-op.
    let rewritten = false;
    for (const event of Object.keys(hooks)) {
      if (!Array.isArray(hooks[event])) continue;
      for (const entry of hooks[event]) {
        if (!Array.isArray(entry.hooks)) continue;
        for (const h of entry.hooks) {
          if (typeof h.command === "string") {
            const trimmed = h.command.trim();
            // Only rewrite the exact legacy duplicate "lcm compact" command on PreCompact,
            // to avoid changing semantics for user-custom variants like "lcm compact --all".
            if (event === "PreCompact" && trimmed === "lcm compact") {
              h.command = "lcm compact --hook";
              rewritten = true;
            }
          }
        }
      }
    }

    const hasDuplicates = REQUIRED_HOOKS.some(({ event, command }) => {
      const entries = hooks[event];
      return Array.isArray(entries) && hasHookCommand(entries, command);
    });
    if (!hasDuplicates && !rewritten) return;

    // Clean up: remove lcm hooks from settings.json (MCP config is preserved)
    const merged = mergeClaudeSettings(settings);
    deps.mkdirSync(dirname(deps.settingsPath), { recursive: true });
    deps.writeFileSync(deps.settingsPath, JSON.stringify(merged, null, 2));
  } catch (err) {
    try {
      deps.mkdirSync(dirname(deps.logPath), { recursive: true });
      const msg = `[${new Date().toISOString()}] auto-heal error: ${err instanceof Error ? err.message : String(err)}\n`;
      deps.appendFileSync(deps.logPath, msg);
    } catch {
      // Last resort: silently fail
    }
  }
}
