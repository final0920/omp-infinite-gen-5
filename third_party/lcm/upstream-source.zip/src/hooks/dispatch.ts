import { validateAndFixHooks } from "./auto-heal.js";
import { lcmHome } from "../lcm-home.js";
import { createLcmPaths } from "../lcm-paths.js";
import { resolveLcmConfig } from "../db/config.js";
import { setTimeout as delay } from "node:timers/promises";

const WORKER_ENROLLMENT_ATTEMPTS = 3;
const WORKER_ENROLLMENT_RETRY_MS = 100;

export const HOOK_COMMANDS = ["compact", "post-tool", "restore", "session-end", "session-snapshot", "user-prompt"] as const;
export type HookCommand = typeof HOOK_COMMANDS[number];

export function isHookCommand(cmd: string): cmd is HookCommand {
  return (HOOK_COMMANDS as readonly string[]).includes(cmd);
}

export async function dispatchHook(
  command: HookCommand,
  stdinText: string,
): Promise<{ exitCode: number; stdout: string }> {
  // `LCM_ENABLED=false` keeps the plugin registered but makes every hook a no-op.
  if (!resolveLcmConfig().enabled) return { exitCode: 0, stdout: "" };

  // The storage root, resolved once here and threaded to every handler below.
  const paths = createLcmPaths(lcmHome());

  if (process.env.LCM_SUMMARIZE_WORKER === "1") {
    try {
      const input = JSON.parse(stdinText || "{}");
      if (input.session_id && input.cwd && command === "restore" && (input.source === "startup" || input.source === "clear") && !input.session_id.startsWith("agent-")) {
        const { registerWorkerSession } = await import("../worker-session.js");
        const owner = (await import("./worker-owner.js")).workerHookOwner("claude");
        for (let attempt = 0; attempt < WORKER_ENROLLMENT_ATTEMPTS; attempt++) {
          try {
            const result = await registerWorkerSession(paths, { sessionId: input.session_id, cwd: input.cwd,
              client: "claude", source: input.source, owner });
            console.error(`[lcm] ${result.warning} Promotions without provenance: ${result.unprovenanced}.`);
            break;
          } catch (error) {
            const reason = error instanceof Error ? error.message : String(error);
            if (!/SQLITE_BUSY|SQLITE_LOCKED|database (?:is )?(?:locked|busy)/i.test(reason) ||
                attempt + 1 === WORKER_ENROLLMENT_ATTEMPTS) throw error;
            console.error(`[lcm] worker enrollment delayed: ${reason}; retrying.`);
            await delay(WORKER_ENROLLMENT_RETRY_MS * (attempt + 1));
          }
        }
      }
      if (command === "restore" && input.source !== "startup" && input.source !== "clear") {
        console.error("[lcm] worker enrollment refused; start a fresh dedicated session. Resume, compact, continue and fork cannot enroll.");
        if (input.source !== "compact" && input.session_id && input.cwd) {
          const { finishWorkerSession } = await import("../worker-session.js");
          await finishWorkerSession(paths, input.cwd, input.session_id);
        }
      }
      if (command === "session-end" && input.session_id && input.cwd) {
        const { finishWorkerSession } = await import("../worker-session.js");
        await finishWorkerSession(paths, input.cwd, input.session_id);
      }
    } catch (error) {
      console.error(`[lcm] worker enrollment refused: ${error instanceof Error ? error.message : String(error)}; no pool payload can be claimed. Use the native harness with lcm command hooks; function hooks require command-hook enrollment.`);
    }
    return { exitCode: 0, stdout: "" };
  }

  // Early return for post-tool — runs on EVERY tool call, must skip bootstrap for performance
  if (command === "post-tool") {
    const { handlePostToolUse } = await import("./post-tool.js");
    return handlePostToolUse(stdinText, paths);
  }

  // PreCompact expects an existing daemon; SessionEnd must never probe or
  // spawn one inside the host's short exit budget.
  if (command !== "compact" && command !== "session-end") {
    // Lazy bootstrap: create config + start daemon on first hook fire per session.
    // A session whose daemon is incompatible fails open: exit 0, nothing on stdout.
    try {
      const { session_id } = JSON.parse(stdinText || "{}");
      if (session_id) {
        const { ensureBootstrapped } = await import("../bootstrap.js");
        const { usable } = await ensureBootstrapped(session_id, paths);
        if (!usable) return { exitCode: 0, stdout: "" };
      }
    } catch {} // bootstrap failure must not block hooks
  }

  validateAndFixHooks(paths);

  const { DaemonClient } = await import("../daemon/client.js");
  const { loadDaemonConfig } = await import("../daemon/config.js");
  const config = loadDaemonConfig(paths.configPath);
  const port = config.daemon?.port ?? 3737;
  const client = new DaemonClient(`http://127.0.0.1:${port}`, paths.tokenPath);

  switch (command) {
    case "compact": {
      const { handlePreCompact } = await import("./compact.js");
      return handlePreCompact(stdinText, client, paths, port);
    }
    case "restore": {
      const { handleSessionStart } = await import("./restore.js");
      return handleSessionStart(stdinText, client, paths, port);
    }
    case "session-end": {
      const { handleSessionEnd } = await import("./session-end.js");
      return handleSessionEnd(stdinText, client, paths, port);
    }
    case "session-snapshot": {
      const { handleSessionSnapshot } = await import("./session-snapshot.js");
      return handleSessionSnapshot(stdinText, paths);
    }
    case "user-prompt": {
      const { handleUserPromptSubmit } = await import("./user-prompt.js");
      return handleUserPromptSubmit(stdinText, client, paths, port);
    }
    default:
      throw new Error(`Unknown hook command: ${command}`);
  }
}
