/**
 * CLI help text for lcm.
 *
 * Consumed by bin/lcm.ts:
 *   printHelp()           — full command reference (lcm --help)
 *   printHelp(command)    — per-command detail   (lcm compact --help)
 */

type FlagHelp = readonly [flag: string, description: string];
type ExampleHelp = readonly [command: string, description: string];

interface CommandHelp {
  summary: string;
  usage: string;
  options?: FlagHelp[];
  examples?: ExampleHelp[];
  notes?: string;
}

const HELP: Record<string, CommandHelp> = {
  timeline: {
    summary: "Reconcile and generate the current project's timeline within a call budget.",
    usage: "lcm timeline <enable|disable|teardown|settle> [--calls N] [--reconcile journal|full] [--remove-nodes]",
    options: [["--calls N", "Maximum summarizer calls (default 10); zero reconciles without generation"], ["--reconcile journal|full", "Explicit full reconciliation repairs tracking and checks aggregates"], ["--remove-nodes", "Teardown only: delete owner summaries and timeline nodes, retaining session sources"]],
    examples: [["lcm timeline settle --calls 0", "Report pending and stale nodes without model calls"], ["lcm timeline settle --calls 10", "Generate up to ten pending timeline nodes"]],
    notes: "Enable tracking with lcm timeline enable. Generation requires timeline.generationEnabled: true (default false) and ordered admission through session-pool or bounded named HTTP endpoints. Flat session-pool configuration requires llm.fallbackProvider: \"disabled\". Disable retains tracking; teardown removes references and triggers, retaining nodes unless --remove-nodes is passed. Remove nodes before downgrading: older lcm promotes them at every session end; re-upgrading archives those memories. Automatic work is debounced and runs one unit per tick. Status and doctor read persisted counts without reconciliation. Replacements preserve historical nodes by id.",
  },
  "summarize-claim": {
    summary: "Claim one pool job in a declared dedicated worker session.",
    usage: "lcm summarize-claim",
    notes: "Start Claude Code or Codex with LCM_SUMMARIZE_WORKER=1 and lcm hooks enabled. Identity comes from the harness environment. Returns job, worker_id and the permanent-exclusion warning; an empty pool returns no job. OMP CLI is unverified and refused.",
  },
  "summarize-submit": {
    summary: "Submit a summary or error for a claimed pool job.",
    usage: "lcm summarize-submit <job-id> --worker-id <id> --model <model> [--text <summary> | --error <message>] [--usage <json>]",
    options: [
      ["--worker-id <id>", "Worker id returned by summarize-claim"],
      ["--model <model>", "Model that produced the summary; recorded as session-pool:<model>"],
      ["--text <summary>", "Summary text (otherwise stdin)"],
      ["--error <message>", "Report a failed completion instead of a summary"],
      ["--usage <json>", "Optional input_tokens, output_tokens and estimated; defaults to estimated"],
    ],
    notes: "The same live enrolled session must submit. Late answers are discarded. Pool completion uses llm.poolCompletionMs (LCM_POOL_COMPLETION_MS), default 180000 ms from claim; the 20000 ms claim deadline stays separate.",
  },
  install: {
    summary: "Set up lcm for every harness on this machine: Claude Code (settings, MCP server, /memory skill, lcm.md, doctor) and, when `codex` is on PATH, the global Codex hooks, and when `omp` is on PATH the global Oh My Pi hook. Reports one outcome per harness and exits non-zero on any failure.",
    usage: "lcm install [--dry-run]",
    options: [
      ["--dry-run", "Preview all changes without writing anything, the shared core included"],
    ],
    examples: [
      ["lcm install", "Run the full setup wizard"],
      ["lcm install --dry-run", "Preview what install would do"],
    ],
  },

  uninstall: {
    summary: "Remove lcm hooks and MCP registration.",
    usage: "lcm uninstall [--dry-run]",
    options: [
      ["--dry-run", "Preview removals without writing anything"],
    ],
    examples: [
      ["lcm uninstall", "Remove all lcm integrations"],
      ["lcm uninstall --dry-run", "Preview what uninstall would do"],
    ],
  },

  daemon: {
    summary: "Start, stop or restart the context daemon that stores and processes memory.",
    usage: "lcm daemon <start [--detach] | stop [--hold] | restart [--release-hold]>",
    options: [
      ["--detach", "Run in the background; saves PID to ~/.lossless-claude/daemon.pid"],
      ["--hold", "On stop: keep it down, so session hooks cannot spawn it again"],
      ["--minutes <n>", "How long a hold lasts before it expires (default 30)"],
      ["--reason <text>", "Why the daemon is held down; shown to whoever runs into it"],
      ["--release-hold", "On restart: explicitly release an offline hold"],
    ],
    examples: [
      ["lcm daemon start --detach", "Start daemon in background (recommended); no-op if already running"],
      ["lcm daemon start", "Start daemon in foreground (for debugging)"],
      ["lcm daemon restart", "Stop the running daemon and start a fresh one (after an upgrade or rebuild)"],
      ["lcm daemon restart --release-hold", "Release an offline hold and restart the daemon"],
      ["lcm daemon stop", "Stop the background daemon"],
      ["lcm daemon stop --hold --reason \"migration\"", "Claim an offline window; release it with lcm daemon start"],
    ],
    notes: "The daemon runs on port 3737 by default. Configure via ~/.lossless-claude/config.json. Without --hold a stop does not last: every session hook spawns the daemon again within seconds. A restart preserves an active hold and refuses with its owner, reason and expiry. Release it with lcm daemon start or lcm daemon restart --release-hold, or wait for expiry.",
  },

  status: {
    summary: "Show daemon status, version, uptime, and project memory statistics.",
    usage: "lcm status [--json]",
    options: [
      ["--json", "Output structured JSON (useful for scripting)"],
    ],
    examples: [
      ["lcm status", "Show human-readable status"],
      ["lcm status --json", "Show machine-readable status"],
    ],
  },

  doctor: {
    summary: "Run diagnostics — daemon, hooks, MCP, summarizer, stale project stores and orphan summaries.",
    usage: "lcm doctor [--verbose] [--cleanup-stale-projects | --repair-manual-attribution] [--dry-run | --apply]",
    options: [
      ["-v, --verbose", "Show full store and event details"],
      ["--cleanup-stale-projects", "Preview trashing stores for missing temporary or test directories"],
      ["--repair-manual-attribution", "Trace active manual memories to Claude/Codex transcript store calls"],
      ["--dry-run", "Read-only cleanup or attribution preview (the default)"],
      ["--apply", "Apply cleanup or attribution repair; requires a stopped, held daemon"],
    ],
    examples: [
      ["lcm doctor", "Run all diagnostic checks"],
      ["lcm doctor --cleanup-stale-projects --dry-run", "Review stale stores without changing them"],
      ["lcm doctor --cleanup-stale-projects --apply", "Trash reviewed stores after lcm daemon stop --hold"],
      ["lcm doctor --repair-manual-attribution", "Preview session attribution from raw store calls"],
      ["lcm doctor --repair-manual-attribution --apply", "Back up and attribute unique matches after lcm daemon stop --hold"],
    ],
    notes: "Exits with code 1 if any check fails. Cleanup and attribution repair are separate, mutually exclusive modes and default to a dry run. Cleanup apply moves stores and event sidecars to <lcm-home>/trash/projects/<batch> and removes their group-index references; it never deletes their data. Attribution repair scans raw Claude/Codex transcripts across projects, matching normalized text/content arguments of calls whose name ends in lcm_store. Only one matching session permits a session_id update; ambiguous and unmatched memories stay unchanged. Apply retains each changed store's full database at the printed db.sqlite.bak-manual-attribution-* path. To revert, keep the daemon held offline, replace db.sqlite with its backup and remove db.sqlite-wal/db.sqlite-shm; this restores the entire database. Run lcm daemon start afterwards. Store lists and orphan ids show at most 20 entries followed by the remaining count; --verbose shows the full lists. Invalid project records are counted; cleanup preview lists them individually. Orphan summaries are reported without repair.",
  },

  search: {
    summary: "Search memory across episodic and promoted layers for the current project.",
    usage: "lcm search <query> [--limit N] [--layer episodic|promoted] [--tag <tag>] [--include-stale]",
    options: [
      ["--limit N", "Max results per layer (default: 5)"],
      ["--include-stale", "Include stale timeline nodes with their periods and reasons"],
      ["--layer <name>", "Layer to search: episodic or promoted (repeatable)"],
      ["--tag <tag>", "Filter to entries that include all specified tags (repeatable)"],
    ],
    examples: [
      ["lcm search \"authentication decision\"", "Search both memory layers for auth-related context"],
      ["lcm search \"sqlite migration\" --layer episodic", "Search only episodic memory"],
      ["lcm search \"hook failure\" --tag type:solution", "Filter by tag"],
    ],
  },

  grep: {
    summary: "Search raw messages and summaries by keyword or regex.",
    usage: "lcm grep <query> [--mode full_text|regex] [--scope messages|summaries|both] [--since <iso>]",
    options: [
      ["--mode <mode>", "Search mode: full_text (default) or regex"],
      ["--scope <scope>", "Scope: messages, summaries, or both (default: both)"],
      ["--since <iso>", "Only include matches on or after this ISO timestamp"],
    ],
    examples: [
      ["lcm grep \"ECONNREFUSED\"", "Search for an exact error string"],
      ["lcm grep \"createDaemon|startMcpServer\" --mode regex", "Regex search across history"],
      ["lcm grep \"migration\" --scope summaries", "Search only summaries"],
    ],
  },

  describe: {
    summary: "Inspect metadata, lineage and commit references for a session or summary.",
    usage: "lcm describe <nodeId>",
    examples: [
      ["lcm describe sum_abc123def456", "Show metadata for a summary node"],
    ],
    notes: "Use lcm search or lcm grep first to find a node ID worth inspecting. A session id or session:<id> shows its commit references.",
  },

  expand: {
    summary: "Expand a summary node back into lower-level source detail.",
    usage: "lcm expand <nodeId> [--depth N]",
    options: [
      ["--depth N", "Traversal depth (default: 1)"],
    ],
    examples: [
      ["lcm expand sum_abc123def456", "Expand a summary one level deep"],
      ["lcm expand sum_abc123def456 --depth 2", "Traverse deeper into the DAG"],
    ],
  },

  store: {
    summary: "Store a durable memory entry for the current project.",
    usage: "lcm store <text> [--tag <tag>]",
    options: [
      ["--tag <tag>", "Attach a tag to the stored memory (repeatable)"],
    ],
    examples: [
      ["lcm store \"Auth uses JWT with 24h expiry\"", "Store a plain-text memory"],
      ["lcm store \"Use ensureDaemon before background promote\" --tag type:solution --tag scope:lcm", "Store a tagged memory"],
    ],
  },

  compact: {
    summary: "Compact conversation context into DAG summary nodes.",
    usage: "lcm compact [--all] [--dry-run] [--replay] [--parallel <N>] [--replay-provider session-pool] [--restart] [--no-promote] [-v]",
    options: [
      ["--all", "Compact all tracked projects (default: current project only)"],
      ["--dry-run", "Show what would be compacted without writing anything"],
      ["--replay", "Compact each project sequentially, threading each summary through the prior context (resumes where the last run stopped)"],
      ["--parallel <N>", "With --replay: process N projects concurrently (default 1), retaining order within each project"],
      ["--replay-provider <provider>", "With --replay: use session-pool; live compactions keep their configured provider"],
      ["--restart", "With --replay: discard recorded progress and all summaries in the conversations the run touches, then start from scratch"],
      ["--no-promote", "Skip the automatic promote step that runs after compaction"],
      ["-v, --verbose", "Show per-session token details"],
    ],
    examples: [
      ["lcm compact", "Compact current project"],
      ["lcm compact --all", "Compact all tracked projects"],
      ["lcm compact --dry-run", "Preview compaction for current project"],
      ["lcm compact --all --replay", "Rebuild all projects with threaded context (slow)"],
      ["lcm compact --no-promote", "Compact without auto-promoting new insights"],
    ],
    notes: "When invoked via the PreCompact hook (piped stdin), runs automatically during Claude Code context compaction. After a successful compact, promote runs automatically to surface new insights to long-term memory.",
  },

  import: {
    summary: "Import Claude Code, Codex or Oh My Pi session transcripts into lossless memory.",
    usage: "lcm import [--provider claude|codex|omp|all | --codex | --omp] [--all] [--verbose] [--dry-run] [--replay] [--parallel <N>] [--replay-provider session-pool] [--restart] [--no-promote] [--backfill-event-times] [--rebuild [--yes] | --retry-blocked] [--session <id>]",
    options: [
      ["--provider <provider>", "Transcript source: claude, codex, omp, all (default: all)"],
      ["--codex", "Alias for --provider codex"],
      ["--omp", "Alias for --provider omp"],
      ["--all", "Import all projects (default: current project only)"],
      ["--verbose", "Show per-session import detail"],
      ["--dry-run", "Preview without importing"],
      ["--replay", "Replay compaction for each imported session (resumes where the last run stopped)"],
      ["--no-promote", "Skip the automatic promote step after compaction"],
      ["--parallel <N>", "With --replay: process N projects concurrently (default 1), retaining order within each project"],
      ["--replay-provider <provider>", "With --replay: use session-pool; live compactions keep their configured provider"],
      ["--restart", "With --replay: discard recorded progress and all summaries in the conversations the run touches, then start from scratch"],
      ["--backfill-event-times", "Repair unknown transcript or commit-anchor times and source bounds in bounded batches, without model calls"],
      ["--rebuild", "With --provider claude: replace repairable stored history; with --provider codex|omp: repair only verified rows cut at NUL (previews unless --yes)"],
      ["--retry-blocked", "With --provider codex: clear terminal capture guards (default: current project; --all: every project with a project record)"],
      ["--yes", "With --rebuild: apply it, after backing up each project database it changes"],
      ["--session <id>", "With --rebuild or --retry-blocked: only this session"],
    ],
    examples: [
      ["lcm import", "Import Claude Code, Codex and Oh My Pi sessions of the current project"],
      ["lcm import --all", "Import every provider across all projects"],
      ["lcm import --replay", "Import and replay every provider in the current project"],
      ["lcm import --all --replay", "Import and compact every provider across all projects"],
      ["lcm import --dry-run", "Preview what would be imported"],
      ["lcm import --provider codex --replay", "Import and compact current project Codex sessions"],
      ["lcm import --omp", "Import current project Oh My Pi sessions"],
      ["lcm import --backfill-event-times", "Fill verified event times for existing captured history"],
      ["lcm import --provider claude --rebuild", "Preview which compacted Claude Code sessions a rebuild would repair"],
      ["lcm import --provider claude --rebuild --yes", "Back up, then rebuild those sessions from their transcripts"],
      ["lcm import --provider codex --rebuild", "Preview historical Codex message rows cut at NUL"],
      ["lcm import --provider omp --rebuild --yes", "Back up, then repair historical OMP cut rows and full-text entries"],
      ["lcm import --provider codex --retry-blocked", "Clear terminal Codex guards in the current project"],
      ["lcm import --provider codex --retry-blocked --session <id>", "Clear one terminal Codex guard in the current project"],
      ["lcm import --provider codex --retry-blocked --all", "Clear terminal Codex guards in every project with a project record"],
    ],
    notes: "Claude transcripts come from ~/.claude/projects/; Codex transcripts from ~/.codex/sessions/ and ~/.codex/archived_sessions/; Oh My Pi session files from <agent dir>/sessions/ (PI_CODING_AGENT_DIR, default ~/.omp/agent). Codex requires session_meta.cwd and OMP requires the session header's cwd; unknown projects are skipped. Every provider is included unless --provider, --codex or --omp selects one. --all includes other projects. Dry-run never starts the daemon. After successful compaction, import automatically promotes insights for the projects it compacted; --no-promote skips that step. Use lcm promote --all to promote existing summaries without replaying. Codex and OMP import share incremental ingestion with their hooks, so later transcript growth is captured without duplicating prior messages. --backfill-event-times records main-chain Claude remote_session_change web URL declarations and repairs transcript times, then builds local commit references from stored tool output and exact declared-URL matches, including sessions whose transcripts are gone. Only messages whose own commit output names exactly one distinct, resolvable commit get committer times when unknown; trailer evidence never anchors and multiple outputs stay unknown. Sidechain attachments declare nothing and attachments create no message. Stored message content, tool output and prompts are never scanned for trailer URLs; several sessions declaring one URL all link. Trailer links occur once per session and commit. Each run scans trailer history once per session and exact declared URL. A separate one-time identity repair deletes all existing session-trailer links and re-derives declared ones without changing event times or summary bounds; sessions with no declaration keep no trailer link. The first enabled pass repairs legacy duplicate links and guessed anchors once, recomputing affected summary bounds. It yields between bounded batches and makes no model calls or remote fetches. commits.enabled=false disables the commit pass; rerun to resume. It cannot run with --replay, --restart, --rebuild or --retry-blocked. --rebuild requires one provider and never runs with --replay. For Claude it replaces repairable history and discards summaries; for Codex and OMP it updates verified NUL-cut message content, event timestamps and full-text entries, recomputing summary bounds while preserving summary text and cursors. --yes backs up the project database before changes. --retry-blocked requires --provider codex and cannot run with --replay, --rebuild or --dry-run, or with --all and --session together. Stored messages and summaries are preserved. The next capture rechecks alignment under current recovery and redaction rules; a mismatch is blocked again and recorded once. Recovery-rule changes automatically retry older guards once, including legacy guards without a rule version; unrelated upgrades keep guards. Guard clearing uses the daemon's project queue and mutation lease.",
  },

  promote: {
    summary: "Scan summaries and promote durable insights to long-term memory.",
    usage: "lcm promote [--all] [--verbose] [--dry-run]",
    options: [
      ["--all", "Promote across all tracked projects (default: current project)"],
      ["--verbose", "Show per-project counts"],
      ["--dry-run", "Preview promotions without writing"],
    ],
    examples: [
      ["lcm promote", "Promote insights for current project"],
      ["lcm promote --all", "Promote across all projects"],
      ["lcm promote --all --verbose", "Show detail for each project"],
      ["lcm promote --dry-run", "Preview what would be promoted"],
    ],
  },

  stats: {
    summary: "Show memory inventory: message counts, compression ratios, and summary statistics.",
    usage: "lcm stats [-v] [--warning-backtest | --pool [--json]]",
    options: [
      ["-v, --verbose", "Show per-conversation breakdown"],
      ["--pool", "Show connection pool statistics from the daemon"],
      ["--json", "Output structured JSON (use with --pool)"],
      ["--warning-backtest", "Offline environment-warning backtest for the current project; scans stored calls, warnings stay off"],
    ],
    examples: [
      ["lcm stats", "Summary view across all projects"],
      ["lcm stats -v", "Per-conversation detail"],
      ["lcm stats --warning-backtest", "Measure matches, precision, coverage and would-be context cost (no daemon or model)"],
      ["lcm stats --pool --json", "Connection pool statistics as JSON"],
    ],
  },

  diagnose: {
    summary: "Scan recent sessions for hook failures, MCP disconnects, and stale state.",
    usage: "lcm diagnose [--all] [--days N] [--verbose] [--json]",
    options: [
      ["--all", "Scan all tracked projects (default: current project)"],
      ["--days N", "Scan the last N days (default: 7)"],
      ["--verbose", "Include full event details in output"],
      ["--json", "Output structured JSON"],
    ],
    examples: [
      ["lcm diagnose", "Scan last 7 days for current project"],
      ["lcm diagnose --days 30", "Scan last 30 days"],
      ["lcm diagnose --all --verbose", "Full detail across all projects"],
      ["lcm diagnose --json", "Machine-readable output"],
    ],
  },

  connectors: {
    summary: "Manage connectors for coding agents (Claude Code, Codex, Gemini, etc.).",
    usage: "lcm connectors <list|install|remove|doctor> [options]",
    options: [
      ["list [--format text|json] [--global]", "List connectors in the current project or your global agent config"],
      ["install <agent> [--type rules|mcp|skill|hooks] [--global]", "Install a connector for an agent"],
      ["remove <agent> [--type rules|mcp|skill|hooks] [--global]", "Remove a connector for an agent"],
      ["doctor [agent] [--global]", "Check connector health in the current project or global agent config"],
    ],
    examples: [
      ["lcm connectors list", "Show all agents and their connector status"],
      ["lcm connectors list --global", "Show connectors from your global agent config"],
      ["lcm connectors list --format json", "Machine-readable connector list"],
      ["lcm connectors install github-copilot", "Install the GitHub Copilot workspace skill for VS Code"],
      ["lcm connectors install codex", "Install native Codex lifecycle hooks"],
      ["lcm connectors install codex --global", "Install Codex into ~/.codex instead of the current project"],
      ["lcm connectors install omp", "Install the Oh My Pi hook into this project's .omp/hooks"],
      ["lcm connectors install omp --global", "Install the Oh My Pi hook into your global OMP agent directory"],
      ["lcm connectors remove omp --global", "Remove the global Oh My Pi hook"],
      ["lcm connectors install codex --type rules", "Install rules-based connector for Codex"],
      ["lcm connectors remove codex", "Remove the Codex connector"],
      ["lcm connectors remove codex --global", "Remove Codex from your global config"],
      ["lcm connectors doctor", "Check health of all connectors"],
      ["lcm connectors doctor --global", "Check the global agent config"],
      ["lcm connectors doctor github-copilot", "Check GitHub Copilot connector health"],
      ["lcm connectors doctor codex", "Check Codex connector health"],
      ["lcm connectors doctor omp", "Check Oh My Pi connector health"],
    ],
    notes: "Codex defaults to native lifecycle hooks; review their trust in Codex /hooks after installation. Installation alone does not prove activation. Optional types: 'rules' (instructions), 'mcp' (server), 'skill' (guidance). Codex MCP setup remains manual. GitHub Copilot defaults to a repo-local skill. Oh My Pi defaults to a hook module written to <agent dir>/hooks/post/lcm.ts or <project>/.omp/hooks/post/lcm.ts; OMP loads it for every session of that agent directory, and its activation cannot be confirmed from the filesystem either.",
  },

  eval: {
    summary: "Compare summarizer endpoints on a stored session without writing its database.",
    usage: "lcm eval summarizer --session <id> --models <endpoint>,<endpoint> [options]",
    options: [
      ["--session <id>", "Stored session id (latest conversation after a clear)"],
      ["--models <endpoints>", "Comma-separated names from llm.providers or session-pool; run sequentially"],
      ["--project <path>", "Project directory (default: cwd)"],
      ["--runs <n>", "Positive number of repeats per session and endpoint (default: 1)"],
      ["--out <dir>", "Local directory for report.json and report.html (default: summarizer-report)"],
      ["--no-planted", "Omit the default synthetic planted-facts session"],
    ],
    examples: [
      ["lcm eval summarizer --session <id> --models local,hosted --out ./comparison", "Compare two configured endpoints"],
      ["lcm eval summarizer --session <id> --models local --runs 3 --no-planted", "Repeat on the stored session only"],
      ["lcm eval summarizer --session <id> --models session-pool,local", "Compare a dedicated worker with an endpoint"],
    ],
    notes: "Calls the configured endpoints and may incur their normal charges. Reports contain conversation content already scrubbed at capture: keep them local. Compaction uses production settings and effective project language in memory. Unsupported details are a deterministic hint, not proof of hallucination. Unknown cost is null, never free. For session-pool, keep the daemon and a dedicated worker running: CLAUDE_CODE_ENABLE_FUNCTION_HOOKS=1 LCM_SUMMARIZE_WORKER=1 LCM_SUMMARIZE_WORKER_MODEL=haiku claude (or LCM_SUMMARIZE_WORKER=1 LCM_SUMMARIZE_WORKER_MODEL=haiku omp). See docs/summarize-workers.md. Pool calls use daemon authentication, have no fallback, and fail if no worker claims within 20 s. Usage names the answering session-pool:<model>. The session provider stays rejected.",
  },

  sensitive: {
    summary: "Manage sensitive patterns for automatic redaction before memory storage.",
    usage: "lcm sensitive <list|add|remove|test|purge> [options]",
    options: [
      ["list", "List active redaction patterns (built-in and custom)"],
      [`add "<pattern>" [--global]`, "Add a regex pattern (project-local by default; --global applies to all projects)"],
      [`remove "<pattern>"`, "Remove a custom redaction pattern"],
      [`test "<text>"`, "Test text against active patterns, showing what would be redacted"],
      ["purge [--all] [--yes]", "IRREVERSIBLY delete the project data directory, including stored memory and custom patterns (--all: all projects; --yes: skip confirm)"],
    ],
    examples: [
      ["lcm sensitive list", "Show all active patterns"],
      ['lcm sensitive add "sk-[a-zA-Z0-9]+"', "Add a project-local pattern to redact API keys starting with 'sk-'"],
      ['lcm sensitive add --global "sk-[a-zA-Z0-9]+"', "Add a global pattern that applies across all projects"],
      ['lcm sensitive remove "sk-[a-zA-Z0-9]+"', "Remove that pattern"],
      ['lcm sensitive test "my key is sk-abc123"', "See what gets redacted"],
      ["lcm sensitive purge --yes", "IRREVERSIBLY delete all stored memory and patterns for current project"],
      ["lcm sensitive purge --all --yes", "IRREVERSIBLY delete all stored memory and patterns for ALL projects"],
    ],
    notes: "Built-in patterns cover common secrets (API keys, tokens, passwords). Project patterns are stored in ~/.lossless-claude/projects/<id>/sensitive-patterns.txt; global patterns are stored in config.json. The 'purge' subcommand deletes the entire project data directory (including stored memory) and cannot be undone.",
  },

  export: {
    summary: "Export promoted knowledge to a portable JSON file (secrets scrubbed).",
    usage: "lcm export [--all] [--tags <tags>] [--since <date>] [--output <file>]",
    options: [
      ["--all", "Export all projects (one file per project, auto-named)"],
      ["--tags <tags>", "Only export entries that have all these comma-separated tags"],
      ["--since <date>", "Only export entries created on or after this ISO date (e.g. 2026-01-01)"],
      ["--output <file>", "Write output to file instead of stdout"],
      ["--format <format>", "Output format: json (default)"],
    ],
    examples: [
      ["lcm export", "Print current project knowledge to stdout"],
      ["lcm export --output knowledge.json", "Write to a file"],
      ["lcm export --since 2026-01-01", "Only export entries from 2026 onward"],
      ["lcm export --tags decision,architecture", "Only export entries tagged with both tags"],
      ["lcm export --all", "Export all projects to auto-named JSON files"],
    ],
    notes: "Secrets are automatically scrubbed using the project's sensitive patterns before export. The JSON format is: { version, exportedAt, projectCwd, entries: [{content, tags, confidence, createdAt, sessionId}] }.",
  },

  "import-knowledge": {
    summary: "Import a portable JSON export back into lossless memory.",
    usage: "lcm import-knowledge <file> [--dry-run] [--confidence <n>]",
    options: [
      ["<file>", "Path to the JSON export file produced by lcm export"],
      ["--merge", "Merge with existing entries, deduplicating (default)"],
      ["--dry-run", "Preview what would be imported without writing anything"],
      ["--confidence <n>", "Override the confidence score for all imported entries (0.0–1.0)"],
    ],
    examples: [
      ["lcm import-knowledge knowledge.json", "Import entries into current project"],
      ["lcm import-knowledge knowledge.json --dry-run", "Preview without writing"],
      ["lcm import-knowledge knowledge.json --confidence 0.7", "Import with reduced confidence"],
    ],
    notes: "Deduplication is performed automatically: near-duplicate entries are merged rather than inserted twice. Run from the target project directory.",
  },

  mcp: {
    summary: "Start the lcm MCP server (used by Claude Code to expose memory tools).",
    usage: "lcm mcp",
    examples: [
      ["lcm mcp", "Start the MCP server (stdio transport)"],
    ],
    notes: "Normally launched automatically by Claude Code via the mcpServers config. No need to run manually.",
  },

  "codex-hook": {
    summary: "Dispatch a native Codex lifecycle hook.",
    usage: "lcm codex-hook",
    examples: [
      ["lcm codex-hook", "Read a Codex hook event from stdin and dispatch it"],
    ],
    notes: "Invoked automatically by the Codex hook integration. Not intended for direct use.",
  },

  restore: {
    summary: "Dispatch the restore hook — restores prior context at session start.",
    usage: "lcm restore",
    examples: [
      ["lcm restore", "Restore context for the current session (called by SessionStart hook)"],
    ],
    notes: "Invoked automatically by the Claude Code SessionStart hook. Not intended for direct use.",
  },

  "session-end": {
    summary: "Dispatch the session-end hook — finalizes and stores session memory.",
    usage: "lcm session-end",
    examples: [
      ["lcm session-end", "Finalize session memory (called by Stop hook)"],
    ],
    notes: "Invoked automatically by the Claude Code Stop hook. Not intended for direct use.",
  },

  "user-prompt": {
    summary: "Dispatch the user-prompt hook — records context on each user message.",
    usage: "lcm user-prompt",
    examples: [
      ["lcm user-prompt", "Record user prompt context (called by UserPromptSubmit hook)"],
    ],
    notes: "Invoked automatically by the Claude Code UserPromptSubmit hook. Not intended for direct use.",
  },

  "post-tool": {
    summary: "Dispatch the post-tool hook — records tool invocation events.",
    usage: "lcm post-tool",
    examples: [
      ["lcm post-tool", "Record post-tool events (called by PostToolUse hook)"],
    ],
    notes: "Invoked automatically by the Claude Code PostToolUse hook. Not intended for direct use.",
  },

  "session-snapshot": {
    summary: "Capture a rolling session snapshot.",
    usage: "lcm session-snapshot",
    examples: [
      ["lcm session-snapshot", "Read a session snapshot event from stdin"],
    ],
    notes: "Invoked automatically by the Stop hook. Not intended for direct use.",
  },
};

export function hasCommandHelp(command: string): boolean {
  return Object.hasOwn(HELP, command);
}

const GROUPS = [
  {
    label: "Setup",
    commands: [
      { name: "install [--dry-run]", summary: "Register hooks, configure daemon, connect MCP" },
      { name: "uninstall [--dry-run]", summary: "Remove hooks and MCP registration" },
    ],
  },
  {
    label: "Runtime",
    commands: [
      { name: "daemon start|stop|restart", summary: "Manage the context daemon" },
      { name: "status [--json]", summary: "Daemon status and project memory stats" },
      { name: "doctor", summary: "Diagnostics: daemon, hooks, MCP, summarizer" },
      { name: "eval summarizer", summary: "Compare summarizers in a local JSON and HTML report" },
      { name: "mcp", summary: "Start the MCP server (stdio transport)" },
    ],
  },
  {
    label: "Memory",
    commands: [
      { name: "search <query> [--limit N]", summary: "Search episodic and promoted memory" },
      { name: "grep <query> [--mode ...]", summary: "Search raw messages and summaries" },
      { name: "describe <nodeId>", summary: "Inspect metadata for a memory node" },
      { name: "expand <nodeId> [--depth N]", summary: "Expand a summary node into source detail" },
      { name: "timeline settle [--calls N]", summary: "Reconcile and generate the project timeline" },
      { name: "store <text> [--tag ...]", summary: "Store a durable memory entry" },
      { name: "compact [--all] [--dry-run] [--replay] [--parallel <N>] [--replay-provider session-pool] [--restart] [--no-promote]", summary: "Compact conversations into DAG summaries (auto-promotes after)" },
      { name: "import [--provider claude|codex|omp|all] [--all] [--verbose] [--dry-run] [--replay] [--parallel <N>] [--replay-provider session-pool] [--restart]", summary: "Import Claude Code, Codex or Oh My Pi session transcripts" },
      { name: "promote [--all] [--verbose] [--dry-run]", summary: "Promote insights to long-term memory" },
      { name: "summarize-claim", summary: "Claim pool work in a dedicated worker session" },
      { name: "summarize-submit <job-id>", summary: "Submit a claimed pool summary or error" },
      { name: "stats [-v]", summary: "Memory inventory and compression ratios" },
      { name: "diagnose [--all] [--days N] [--verbose] [--json]", summary: "Scan sessions for hook failures and issues" },
    ],
  },
  {
    label: "Connectors",
    commands: [
      { name: "connectors list [--format text|json]", summary: "List available agents and installed connectors" },
      { name: "connectors install <agent> [--type ...] [--global]", summary: "Install connector for a coding agent" },
      { name: "connectors remove <agent> [--type ...] [--global]", summary: "Remove connector for a coding agent" },
      { name: "connectors doctor [agent] [--global]", summary: "Check connector health" },
    ],
  },
  {
    label: "Portable Knowledge",
    commands: [
      { name: "export [--all] [--output <file>]", summary: "Export promoted knowledge to JSON (secrets scrubbed)" },
      { name: "import-knowledge <file>", summary: "Import exported knowledge JSON, deduplicating on merge" },
    ],
  },
  {
    label: "Portable Knowledge",
    commands: [
      { name: "export [--all] [--output <file>]", summary: "Export promoted knowledge to JSON (secrets scrubbed)" },
      { name: "import-knowledge <file>", summary: "Import exported knowledge JSON, deduplicating on merge" },
    ],
  },
  {
    label: "Sensitive",
    commands: [
      { name: "sensitive list", summary: "List active redaction patterns" },
      { name: "sensitive add <pattern>", summary: "Add a redaction pattern" },
      { name: "sensitive remove <pattern>", summary: "Remove a redaction pattern" },
      { name: "sensitive test <text>", summary: "Test text against active patterns" },
      { name: "sensitive purge [--all] [--yes]", summary: "Purge all project data (stored memory and patterns)" },
    ],
  },
  {
    label: "Hooks (internal)",
    commands: [
      { name: "codex-hook", summary: "Native Codex lifecycle — capture, restore, recall, and compact" },
      { name: "restore", summary: "SessionStart hook — restore prior context" },
      { name: "session-end", summary: "Stop hook — finalize and store session memory" },
      { name: "user-prompt", summary: "UserPromptSubmit hook — record user prompt context" },
      { name: "post-tool", summary: "PostToolUse hook — record tool invocation events" },
    ],
  },
];

function pad(str: string, width: number): string {
  return str.length >= width ? str : str + " ".repeat(width - str.length);
}

export function printHelp(command?: string): void {
  if (command) {
    printCommandHelp(command);
    return;
  }

  const lines: string[] = [
    "",
    "  lcm — lossless context management for coding agents",
    "",
    "  Usage: lcm <command> [options]",
    "",
  ];

  for (const group of GROUPS) {
    lines.push(`  ${group.label}`);
    const maxNameLen = Math.max(...group.commands.map(c => c.name.length));
    for (const cmd of group.commands) {
      lines.push(`    ${pad(cmd.name, maxNameLen + 2)}${cmd.summary}`);
    }
    lines.push("");
  }

  lines.push("  Flags");
  lines.push("    -V, --version            Show version");
  lines.push("    -h, --help               Show this help");
  lines.push("");
  lines.push("  Run 'lcm <command> --help' for options and examples.");
  lines.push("");

  process.stdout.write(lines.join("\n") + "\n");
}

function printCommandHelp(command: string): void {
  const h = HELP[command];
  if (!h) {
    process.stderr.write(`Unknown command: ${command}\n`);
    printHelp();
    return;
  }

  const lines: string[] = [
    "",
    `  lcm ${command} — ${h.summary}`,
    "",
    `  Usage: ${h.usage}`,
    "",
  ];

  if (h.options && h.options.length > 0) {
    lines.push("  Options:");
    const maxLen = Math.max(...h.options.map(([f]) => f.length));
    for (const [flag, desc] of h.options) {
      lines.push(`    ${pad(flag, maxLen + 2)}${desc}`);
    }
    lines.push("");
  }

  if (h.examples && h.examples.length > 0) {
    lines.push("  Examples:");
    const maxLen = Math.max(...h.examples.map(([cmd]) => cmd.length));
    for (const [cmd, desc] of h.examples) {
      lines.push(`    ${pad(cmd, maxLen + 2)}${desc}`);
    }
    lines.push("");
  }

  if (h.notes) {
    lines.push(`  Note: ${h.notes}`);
    lines.push("");
  }

  process.stdout.write(lines.join("\n") + "\n");
}
