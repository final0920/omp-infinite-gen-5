import { WorkerStore } from "../store/worker-store.js";
import { randomUUID } from "node:crypto";
import type { DatabaseSync } from "node:sqlite";
import {
  prepareFts5Query,
  shouldRetryWithLike,
  likePlanForPreparedQuery,
  type Fts5PreparedQuery,
} from "../store/fts5-query.js";
import { parseStoredTags, singleMemoryIdTag, voteTagsOf, type VoteDirection } from "./votes.js";

export type PromotedRow = {
  id: string;
  content: string;
  tags: string;
  source_summary_id: string | null;
  project_id: string;
  session_id: string | null;
  depth: number;
  confidence: number;
  created_at: string;
  archived_at: string | null;
};

export type InsertParams = {
  content: string;
  tags?: string[];
  sourceSummaryId?: string;
  projectId: string;
  sessionId?: string;
  depth?: number;
  confidence?: number;
};

export type SearchResult = {
  id: string;
  content: string;
  tags: string[];
  projectId: string;
  sessionId: string | null;
  confidence: number;
  createdAt: string;
  rank: number;
};

function serializeTags(tags: string[]): string {
  if (!Array.isArray(tags) || !tags.every((tag) => typeof tag === "string")) {
    throw new Error("tags must be an array of strings");
  }
  return JSON.stringify(tags);
}

export class PromotedStore {
  constructor(private db: DatabaseSync) {}

  insert(params: InsertParams): string {
    const tags = serializeTags(params.tags ?? []);
    const sessionId = params.sessionId ?? (params.sourceSummaryId
      ? (this.db.prepare("SELECT session_id FROM summaries JOIN conversations USING(conversation_id) WHERE summary_id = ?").get(params.sourceSummaryId) as { session_id: string } | undefined)?.session_id : undefined);
    if (sessionId && new WorkerStore(this.db).excluded(sessionId)) throw new Error("Worker session is excluded from promoted memory");
    const id = randomUUID();

    this.db.prepare(
      `INSERT INTO promoted (id, content, tags, source_summary_id, project_id, session_id, depth, confidence)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?)`
    ).run(
      id,
      params.content,
      tags,
      params.sourceSummaryId ?? null,
      params.projectId,
      params.sessionId ?? null,
      params.depth ?? 0,
      params.confidence ?? 1.0,
    );

    // Sync to FTS5
    const row = this.db.prepare("SELECT rowid FROM promoted WHERE id = ?").get(id) as { rowid: number } | undefined;
    if (row) {
      this.db.prepare(
        "INSERT INTO promoted_fts (rowid, content, tags) VALUES (?, ?, ?)"
      ).run(row.rowid, params.content, tags);
    }

    return id;
  }

  getById(id: string): PromotedRow | null {
    return (this.db.prepare("SELECT * FROM promoted WHERE id = ?").get(id) as PromotedRow) ?? null;
  }

  /** Repair an active manual memory's session without changing its other fields or full-text index. */
  attributeManual(id: string, sessionId: string): boolean {
    return this.db.prepare(
      "UPDATE promoted SET session_id = ? WHERE id = ? AND session_id = 'manual' AND archived_at IS NULL"
    ).run(sessionId, id).changes === 1;
  }

  /** Every row, archived and signal rows included. */
  count(): number {
    const row = this.db.prepare("SELECT COUNT(*) AS count FROM promoted").get() as { count: number } | undefined;
    return row?.count ?? 0;
  }

  search(query: string, limit: number, filterTags?: string[], projectId?: string, terms?: readonly string[]): SearchResult[] {
    const prepared = prepareFts5Query(query, terms);
    if (!prepared) return [];

    // OR (not AND): natural-language questions almost never co-occur in a
    // single memory, and a grep baseline that ORs terms must not win.
    const rows = this.searchFullText(prepared.or, limit, projectId);

    let results = rows.flatMap((r) => {
      const tags = parseStoredTags(r.tags);
      return tags ? [{
        id: r.id, content: r.content, tags, projectId: r.project_id,
        sessionId: r.session_id, confidence: r.confidence, createdAt: r.created_at, rank: r.rank,
      }] : [];
    });

    // Vocabulary-mismatch fallback: when the question's words don't overlap
    // the corpus at all (porter stems diverge), retry as a substring scan so
    // a natural-language question never returns empty by construction.
    if (results.length === 0 && shouldRetryWithLike(prepared)) {
      results = this.searchLikeTerms(prepared, limit, projectId);
    }

    if (filterTags && filterTags.length > 0) {
      results = results.filter((r) => filterTags.every((t) => r.tags.includes(t)));
    }

    return results;
  }

  private searchFullText(
    ftsExpression: string,
    limit: number,
    projectId?: string,
  ): Array<PromotedRow & { rank: number }> {
    const projectFilter = projectId ? "AND p.project_id = ?" : "";
    const queryParams: (string | number)[] = [ftsExpression];
    if (projectId) queryParams.push(projectId);
    queryParams.push(limit);

    // CROSS JOIN keeps promoted_fts as the outer loop. Given a project filter, the planner
    // otherwise walks the project's rows through promoted_project_idx and re-runs the MATCH
    // once per row, re-seeking every term each time.
    return this.db.prepare(
      `SELECT p.id, p.content, p.tags, p.project_id, p.session_id, p.confidence, p.created_at, rank
       FROM promoted_fts fts
       CROSS JOIN promoted p ON p.rowid = fts.rowid
       WHERE promoted_fts MATCH ?
         AND p.archived_at IS NULL
         AND p.tags NOT LIKE '%"signal:%'
         ${projectFilter}
       ORDER BY rank, p.confidence DESC, p.created_at ASC
       LIMIT ?`
    ).all(...queryParams) as Array<PromotedRow & { rank: number }>;
  }

  private searchLikeTerms(
    prepared: Fts5PreparedQuery,
    limit: number,
    projectId?: string,
  ): SearchResult[] {
    const plan = likePlanForPreparedQuery("content", prepared);
    if (plan.terms.length === 0) return [];

    const where: string[] = [`(${plan.where.join(" OR ")})`, "archived_at IS NULL", `tags NOT LIKE '%"signal:%'`];
    const args: Array<string | number> = [...plan.args];
    if (projectId) {
      where.push("project_id = ?");
      args.push(projectId);
    }
    args.push(limit);

    const rows = this.db.prepare(
      `SELECT id, content, tags, project_id, session_id, confidence, created_at
       FROM promoted
       WHERE ${where.join(" AND ")}
       ORDER BY confidence DESC, created_at ASC
       LIMIT ?`
    ).all(...args) as PromotedRow[];

    return rows.flatMap((r) => {
      const tags = parseStoredTags(r.tags);
      return tags ? [{
        id: r.id, content: r.content, tags, projectId: r.project_id,
        sessionId: r.session_id, confidence: r.confidence, createdAt: r.created_at, rank: 0,
      }] : [];
    });
  }

  getAll(opts?: { projectId?: string; since?: string; tags?: string[] }): PromotedRow[] {
    let sql = "SELECT * FROM promoted WHERE archived_at IS NULL";
    const params: (string | number)[] = [];

    if (opts?.projectId) {
      sql += " AND project_id = ?";
      params.push(opts.projectId);
    }
    if (opts?.since) {
      sql += " AND created_at >= ?";
      params.push(opts.since);
    }
    sql += " ORDER BY created_at ASC";

    let rows = this.db.prepare(sql).all(...params) as PromotedRow[];

    if (opts?.tags && opts.tags.length > 0) {
      rows = rows.filter((r) => {
        const rowTags = parseStoredTags(r.tags);
        return rowTags !== null && opts.tags!.every((t) => rowTags.includes(t));
      });
    }

    return rows;
  }

  /** Includes archived incoming rows so deduped summaries are not promoted again. */
  listSourceSummaryIds(): string[] {
    const rows = this.db.prepare(
      "SELECT DISTINCT source_summary_id FROM promoted WHERE source_summary_id IS NOT NULL"
    ).all() as Array<{ source_summary_id: string }>;
    return rows.map((r) => r.source_summary_id);
  }

  /** Legacy promotion used the first 100 characters of active memories. */
  listLegacyContentPrefixes(): string[] {
    const rows = this.db.prepare(
      "SELECT content FROM promoted WHERE archived_at IS NULL AND source_summary_id IS NULL"
    ).all() as Array<{ content: string }>;
    return rows.map((r) => r.content.slice(0, 100));
  }

  archive(id: string): void {
    const row = this.db.prepare("SELECT rowid FROM promoted WHERE id = ?").get(id) as { rowid: number } | undefined;
    this.db.prepare("UPDATE promoted SET archived_at = datetime('now') WHERE id = ?").run(id);
    if (row) {
      this.db.prepare("DELETE FROM promoted_fts WHERE rowid = ?").run(row.rowid);
    }
  }

  update(id: string, fields: { content?: string; confidence?: number; tags?: string[] }): void {
    const serializedTags = fields.tags === undefined ? undefined : serializeTags(fields.tags);
    const row = this.db.prepare("SELECT rowid, content, tags FROM promoted WHERE id = ?").get(id) as
      | { rowid: number; content: string; tags: string }
      | undefined;
    if (!row) return;

    if (fields.content !== undefined) {
      const newTags = serializedTags ?? row.tags;
      this.db.prepare(
        "UPDATE promoted SET content = ?, confidence = COALESCE(?, confidence), tags = ? WHERE id = ?"
      ).run(fields.content, fields.confidence ?? null, newTags, id);
      // Re-sync FTS5: delete old row and insert new one
      this.db.prepare("DELETE FROM promoted_fts WHERE rowid = ?").run(row.rowid);
      this.db.prepare("INSERT INTO promoted_fts (rowid, content, tags) VALUES (?, ?, ?)").run(
        row.rowid,
        fields.content,
        newTags,
      );
    } else {
      if (fields.confidence !== undefined) {
        this.db.prepare("UPDATE promoted SET confidence = ? WHERE id = ?").run(fields.confidence, id);
      }
      if (fields.tags !== undefined) {
        const newTags = serializedTags!;
        this.db.prepare("UPDATE promoted SET tags = ? WHERE id = ?").run(newTags, id);
        // Re-sync FTS5 tags
        this.db.prepare("DELETE FROM promoted_fts WHERE rowid = ?").run(row.rowid);
        this.db.prepare("INSERT INTO promoted_fts (rowid, content, tags) VALUES (?, ?, ?)").run(
          row.rowid,
          row.content,
          newTags,
        );
      }
    }
  }

  /**
   * Find promoted memories that are candidates for staleness review.
   * A memory is stale when it is old enough AND has not been acted upon recently.
   */
  findStale(opts: {
    staleAfterDays: number;
    staleSurfacingWithoutUseLimit: number;
    projectId?: string;
    legacyUsageCounts?: ReadonlyMap<string, number>;
    ambiguousIds?: ReadonlySet<string>;
  }): Array<PromotedRow & { surfacingCount: number; usageCount: number; daysSinceCreated: number }> {
    const cutoffMs = Date.now() - opts.staleAfterDays * 24 * 60 * 60 * 1000;
    // Use SQLite datetime format (YYYY-MM-DD HH:MM:SS) to match created_at,
    // which is stored via datetime('now'). ISO-8601 with T/Z sorts incorrectly.
    const cutoff = new Date(cutoffMs).toISOString().replace("T", " ").replace(/\.\d{3}Z$/, "");

    let sql = `SELECT * FROM promoted WHERE archived_at IS NULL AND created_at < ?`;
    const params: (string | number)[] = [cutoff];

    if (opts.projectId) {
      sql += " AND project_id = ?";
      params.push(opts.projectId);
    }
    sql += " ORDER BY created_at ASC";

    const rows = this.db.prepare(sql).all(...params) as PromotedRow[];
    if (rows.length === 0) return [];

    // Batch: get surfacing counts for all candidate IDs in one query
    const ids = rows.map((r) => r.id);
    const placeholders = ids.map(() => "?").join(",");

    const surfacingRows = this.db.prepare(
      `SELECT memory_id, COUNT(*) as count FROM recall_surfacing
       WHERE memory_id IN (${placeholders})
       GROUP BY memory_id`
    ).all(...ids) as Array<{ memory_id: string; count: number }>;
    const surfacingMap = new Map(surfacingRows.map((r) => [r.memory_id, r.count]));

    // Batch: count usage via signal:memory_used tags in one query

    const usageRows = this.db.prepare(
      `SELECT tags FROM promoted
       WHERE archived_at IS NULL
       AND tags LIKE '%"signal:memory_used"%'`
    ).all() as Array<{ tags: string }>;
    const usageMap = new Map<string, number>();
    for (const row of usageRows) {
      const tags = parseStoredTags(row.tags);
      if (!tags || !tags.includes("signal:memory_used")) continue;
      const memoryId = singleMemoryIdTag(tags);
      if (memoryId && ids.includes(memoryId)) usageMap.set(memoryId, (usageMap.get(memoryId) ?? 0) + 1);
    }

    const result: Array<PromotedRow & { surfacingCount: number; usageCount: number; daysSinceCreated: number }> = [];

    for (const row of rows) {
      const surfacingCount = surfacingMap.get(row.id) ?? 0;
      const usageCount = opts.ambiguousIds?.has(row.id) ? 0 : (usageMap.get(row.id) ?? 0) + (opts.legacyUsageCounts?.get(row.id) ?? 0);
      const daysSinceCreated = Math.floor((Date.now() - Date.parse(row.created_at)) / (24 * 60 * 60 * 1000));

      const surfacedWithoutUse = surfacingCount >= opts.staleSurfacingWithoutUseLimit && usageCount === 0;
      const purelyOld = surfacingCount === 0 && usageCount === 0;

      if (surfacedWithoutUse || purelyOld) {
        result.push({ ...row, surfacingCount, usageCount, daysSinceCreated });
      }
    }

    return result;
  }

  /**
   * Vote tallies per target memory, read from this database's own `signal:memory_vote`
   * records. A vote is always written into the database that holds its target (the store
   * route resolves that across the project's group before inserting), so no cross-database
   * join is needed here. Archived vote rows — the dismissal mechanism for a contested entry
   * — are excluded, same as any other archived row.
   */
  getVoteCounts(): Map<string, { plusOne: number; minusOne: number; objections: Array<{ voteId: string; reason: string; sessionId: string | null }> }> {
    const counts = new Map<string, { plusOne: number; minusOne: number; objections: Array<{ voteId: string; reason: string; sessionId: string | null }> }>();
    for (const vote of this.activeVotes()) {
      const entry = counts.get(vote.memoryId) ?? { plusOne: 0, minusOne: 0, objections: [] };
      if (vote.direction === "+1") {
        entry.plusOne += 1;
      } else {
        entry.minusOne += 1;
        entry.objections.push({ voteId: vote.id, reason: vote.reason, sessionId: vote.sessionId });
      }
      counts.set(vote.memoryId, entry);
    }
    return counts;
  }

  /** One session's active votes: what a later vote from the same session on the same memory reconciles against. */
  activeVotesBySession(sessionId: string): Array<{ id: string; memoryId: string; direction: VoteDirection }> {
    return this.activeVotes(sessionId).map(({ id, memoryId, direction }) => ({ id, memoryId, direction }));
  }

  /** The one reader of `signal:memory_vote` rows; how a vote is encoded in tags is decided here and in `votes.ts`. */
  private activeVotes(sessionId?: string): Array<{ id: string; memoryId: string; direction: VoteDirection; reason: string; sessionId: string | null }> {
    const sessionFilter = sessionId === undefined ? "" : "AND session_id = ?";
    const rows = this.db.prepare(
      `SELECT id, tags, content, session_id FROM promoted
       WHERE archived_at IS NULL
       AND tags LIKE '%"signal:memory_vote"%'
       ${sessionFilter}`
    ).all(...(sessionId === undefined ? [] : [sessionId])) as Array<{ id: string; tags: string; content: string; session_id: string | null }>;

    return rows.flatMap((row) => {
      const tags = parseStoredTags(row.tags);
      const vote = tags && voteTagsOf(tags);
      return vote ? [{ id: row.id, ...vote, reason: row.content, sessionId: row.session_id }] : [];
    });
  }

  /** Revive a previously archived memory back to active status. */
  revive(id: string): void {
    const row = this.db.prepare("SELECT rowid, content, tags FROM promoted WHERE id = ?").get(id) as
      | { rowid: number; content: string; tags: string }
      | undefined;
    if (!row) return;

    // Wrap in transaction so the row and FTS stay in sync
    this.db.exec("BEGIN");
    try {
      this.db.prepare("UPDATE promoted SET archived_at = NULL WHERE id = ?").run(id);
      // Re-add to FTS — ignore if already present
      try {
        this.db.prepare("INSERT INTO promoted_fts (rowid, content, tags) VALUES (?, ?, ?)").run(
          row.rowid, row.content, row.tags
        );
      } catch { /* already in FTS — non-fatal */ }
      this.db.exec("COMMIT");
    } catch (err) {
      this.db.exec("ROLLBACK");
      throw err;
    }
  }

  transaction(fn: () => void): void {
    this.db.exec("BEGIN");
    try {
      fn();
      this.db.exec("COMMIT");
    } catch (err) {
      this.db.exec("ROLLBACK");
      throw err;
    }
  }
}
