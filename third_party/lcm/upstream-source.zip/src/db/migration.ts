import { passiveTypeTag } from "../promotion/passive-tags.js";
import { decodeLegacyTags } from "./votes.js";
import type { DatabaseSync } from "node:sqlite";
import { randomUUID } from "node:crypto";
import { homedir } from "node:os";
import { join } from "node:path";
import { getLcmDbFeatures } from "./features.js";
import { ensureTranscriptCursorTable } from "./transcript-cursor.js";
import { ensureToolLessonIncrementalSchema } from "./tool-lesson-schema.js";
import { installProjectTimeline } from "./project-timeline.js";
import { installRecallUsage } from "./recall-usage.js";
import { walkSubagentTranscripts } from "../subagent-attribution.js";
import { extractCommandParts, type MessagePart } from "../transcript.js";

function defaultClaudeProjectsDir(): string {
  return join(homedir(), ".claude", "projects");
}

/** Disable foreign keys around a migration sweep (SQLite forbids toggling inside a transaction). */
export function withForeignKeysDisabled(db: DatabaseSync, fn: () => void): void {
  db.exec("PRAGMA foreign_keys = OFF");
  try {
    fn();
  } finally {
    db.exec("PRAGMA foreign_keys = ON");
  }
}

type SummaryColumnInfo = {
  name?: string;
};

type SummaryDepthRow = {
  summary_id: string;
  conversation_id: number;
  kind: "leaf" | "condensed";
  depth: number;
  token_count: number;
  created_at: string;
};

type SummaryMessageTimeRangeRow = {
  summary_id: string;
  known_event_count: number;
  earliest_at: string | null;
  latest_at: string | null;
  source_message_token_count: number | null;
};

type SummaryParentEdgeRow = {
  summary_id: string;
  parent_summary_id: string;
};

/**
 * Adds the normalized token breakdown to databases created before providers
 * reported input/cached/output separately. Existing rows keep their totals.
 */
/**
 * Adds replay_ledger.outcome to databases created before it existed.
 * 'compacted' is the right default: every pre-existing row was written on the
 * old code path, which only recorded a session after a real compaction.
 */
function ensureReplayLedgerOutcomeColumn(db: DatabaseSync): void {
  const columns = db.prepare(`PRAGMA table_info(replay_ledger)`).all() as SummaryColumnInfo[];
  if (!columns.some((col) => col.name === "outcome")) {
    db.exec(`ALTER TABLE replay_ledger ADD COLUMN outcome TEXT NOT NULL DEFAULT 'compacted'`);
  }
}

/**
 * `cost_usd_total` is deliberately nullable with no default: NULL means no
 * provider ever priced these calls, which must stay distinguishable from a
 * genuine zero. `calls_with_cost` says how many of `calls_total` carried a
 * price, so a consumer can tell a complete total from a partial one.
 */
const LLM_USAGE_ADDED_COLUMNS: ReadonlyArray<readonly [name: string, ddl: string]> = [
  ["tokens_input_total", "INTEGER NOT NULL DEFAULT 0"],
  ["tokens_cached_total", "INTEGER NOT NULL DEFAULT 0"],
  ["tokens_output_total", "INTEGER NOT NULL DEFAULT 0"],
  ["cost_usd_total", "REAL"],
  ["calls_with_cost", "INTEGER NOT NULL DEFAULT 0"],
  ["calls_estimated", "INTEGER NOT NULL DEFAULT 0"],
];

function ensureLlmUsageBreakdownColumns(db: DatabaseSync): void {
  const columns = db.prepare(`PRAGMA table_info(llm_usage_stats)`).all() as SummaryColumnInfo[];
  for (const [name, ddl] of LLM_USAGE_ADDED_COLUMNS) {
    if (!columns.some((col) => col.name === name)) {
      db.exec(`ALTER TABLE llm_usage_stats ADD COLUMN ${name} ${ddl}`);
    }
  }
}

function ensureSummaryDepthColumn(db: DatabaseSync): boolean {
  const summaryColumns = db.prepare(`PRAGMA table_info(summaries)`).all() as SummaryColumnInfo[];
  const hasDepth = summaryColumns.some((col) => col.name === "depth");
  if (!hasDepth) {
    db.exec(`ALTER TABLE summaries ADD COLUMN depth INTEGER NOT NULL DEFAULT 0`);
  }
  return !hasDepth;
}

function ensureSummaryMetadataColumns(db: DatabaseSync): boolean {
  const summaryColumns = db.prepare(`PRAGMA table_info(summaries)`).all() as SummaryColumnInfo[];
  const hasEarliestAt = summaryColumns.some((col) => col.name === "earliest_at");
  const hasLatestAt = summaryColumns.some((col) => col.name === "latest_at");
  const hasDescendantCount = summaryColumns.some((col) => col.name === "descendant_count");
  const hasDescendantTokenCount = summaryColumns.some((col) => col.name === "descendant_token_count");
  const hasSourceMessageTokenCount = summaryColumns.some(
    (col) => col.name === "source_message_token_count",
  );

  if (!hasEarliestAt) {
    db.exec(`ALTER TABLE summaries ADD COLUMN earliest_at TEXT`);
  }
  if (!hasLatestAt) {
    db.exec(`ALTER TABLE summaries ADD COLUMN latest_at TEXT`);
  }
  if (!hasDescendantCount) {
    db.exec(`ALTER TABLE summaries ADD COLUMN descendant_count INTEGER NOT NULL DEFAULT 0`);
  }
  if (!hasDescendantTokenCount) {
    db.exec(`ALTER TABLE summaries ADD COLUMN descendant_token_count INTEGER NOT NULL DEFAULT 0`);
  }
  if (!hasSourceMessageTokenCount) {
    db.exec(`ALTER TABLE summaries ADD COLUMN source_message_token_count INTEGER NOT NULL DEFAULT 0`);
  }
  return !hasEarliestAt || !hasLatestAt || !hasDescendantCount ||
    !hasDescendantTokenCount || !hasSourceMessageTokenCount;
}

/**
 * Added on its own so it never triggers the summary backfill: existing summaries keep 0
 * (bounds on capture time, as they were computed); compaction and recomputeTimeBounds set it.
 */
function ensureSummaryEventTimeFlag(db: DatabaseSync): void {
  const summaryColumns = db.prepare(`PRAGMA table_info(summaries)`).all() as SummaryColumnInfo[];
  if (!summaryColumns.some((col) => col.name === "has_event_time")) {
    db.exec("ALTER TABLE summaries ADD COLUMN has_event_time INTEGER NOT NULL DEFAULT 0");
  }
}

/** conversations.parent_session_id / subagent_type / subagent_desc — see docs/design/subagent-attribution-from-sidecar.md. */
function ensureSubagentAttributionColumns(db: DatabaseSync): void {
  const columns = db.prepare(`PRAGMA table_info(conversations)`).all() as SummaryColumnInfo[];
  const wanted = ["parent_session_id", "subagent_type", "subagent_desc"];
  for (const name of wanted) {
    if (!columns.some((col) => col.name === name)) {
      db.exec(`ALTER TABLE conversations ADD COLUMN ${name} TEXT DEFAULT NULL`);
    }
  }
}

/**
 * conversations.opened_by_entry_id: the transcript entry whose clear opened this conversation
 * (an OMP `reset_boundary`), NULL for a session's first. See docs/design/omp-clear-boundary.md.
 */
function ensureConversationBoundaryColumn(db: DatabaseSync): void {
  const columns = db.prepare(`PRAGMA table_info(conversations)`).all() as Array<{ name?: string }>;
  if (!columns.some((col) => col.name === "opened_by_entry_id")) {
    db.exec(`ALTER TABLE conversations ADD COLUMN opened_by_entry_id TEXT DEFAULT NULL`);
  }
}

/**
 * Marks the one-time subagent-attribution backfill done, so it never re-walks
 * `~/.claude/projects` again on this database. `unmatched_count` is the
 * number of `agent-%` conversations whose transcript was no longer on disk
 * when the sweep ran — those stay NULL forever, which is expected, not a bug.
 */
function ensureSubagentBackfillTable(db: DatabaseSync): void {
  db.exec(`
    CREATE TABLE IF NOT EXISTS subagent_attribution_backfill (
      id INTEGER PRIMARY KEY CHECK (id = 1),
      unmatched_count INTEGER NOT NULL DEFAULT 0,
      completed_at TEXT NOT NULL DEFAULT (datetime('now'))
    );
  `);
}

function hasUnresolvedAgentConversations(db: DatabaseSync): boolean {
  const row = db
    .prepare(`SELECT 1 FROM conversations WHERE session_id LIKE 'agent-%' AND parent_session_id IS NULL LIMIT 1`)
    .get();
  return row !== undefined;
}

type UnresolvedAgentConversationRow = { conversation_id: number; session_id: string };

function applySubagentAttributionBackfill(db: DatabaseSync, claudeProjectsDir: string): number {
  const bySessionId = new Map(walkSubagentTranscripts(claudeProjectsDir).map((e) => [e.sessionId, e.attribution]));
  const rows = db
    .prepare(`SELECT conversation_id, session_id FROM conversations WHERE session_id LIKE 'agent-%' AND parent_session_id IS NULL`)
    .all() as UnresolvedAgentConversationRow[];

  const updateStmt = db.prepare(
    `UPDATE conversations SET parent_session_id = ?, subagent_type = ?, subagent_desc = ? WHERE conversation_id = ?`,
  );
  let unmatched = 0;
  for (const row of rows) {
    const attribution = bySessionId.get(row.session_id);
    if (!attribution) {
      unmatched++; // transcript no longer on disk — stays NULL
      continue;
    }
    updateStmt.run(attribution.parentSessionId, attribution.subagentType, attribution.subagentDesc, row.conversation_id);
  }
  return unmatched;
}

/**
 * Runs once per database: re-walks `~/.claude/projects` to fill
 * `parent_session_id` / `subagent_type` / `subagent_desc` for every
 * `agent-%` conversation imported before those columns existed. `UPDATE`
 * only — `summary_messages.message_id` is `ON DELETE RESTRICT`, so a
 * compacted conversation can never be deleted and re-ingested.
 */
function backfillSubagentAttribution(db: DatabaseSync, claudeProjectsDir: string): void {
  ensureSubagentBackfillTable(db);
  if (db.prepare(`SELECT 1 FROM subagent_attribution_backfill WHERE id = 1`).get()) return;

  const unmatched = hasUnresolvedAgentConversations(db) ? applySubagentAttributionBackfill(db, claudeProjectsDir) : 0;
  db.prepare(`INSERT INTO subagent_attribution_backfill (id, unmatched_count) VALUES (1, ?)`).run(unmatched);
}

function parseTimestamp(value: string | null | undefined): Date | null {
  if (typeof value !== "string" || !value.trim()) {
    return null;
  }

  const direct = new Date(value);
  if (!Number.isNaN(direct.getTime())) {
    return direct;
  }

  const normalized = value.includes("T") ? value : `${value.replace(" ", "T")}Z`;
  const parsed = new Date(normalized);
  return Number.isNaN(parsed.getTime()) ? null : parsed;
}

function isoStringOrNull(value: Date | null): string | null {
  return value ? value.toISOString() : null;
}

function backfillSummaryDepths(db: DatabaseSync): void {
  // Leaves are always depth 0, even if legacy rows had malformed values.
  db.exec(`UPDATE summaries SET depth = 0 WHERE kind = 'leaf'`);

  const conversationRows = db
    .prepare(`SELECT DISTINCT conversation_id FROM summaries WHERE kind = 'condensed'`)
    .all() as Array<{ conversation_id: number }>;
  if (conversationRows.length === 0) {
    return;
  }

  const updateDepthStmt = db.prepare(`UPDATE summaries SET depth = ? WHERE summary_id = ?`);

  for (const row of conversationRows) {
    const conversationId = row.conversation_id;
    const summaries = db
      .prepare(
        `SELECT summary_id, conversation_id, kind, depth, token_count, created_at
         FROM summaries
         WHERE conversation_id = ?`,
      )
      .all(conversationId) as SummaryDepthRow[];

    const depthBySummaryId = new Map<string, number>();
    const unresolvedCondensedIds = new Set<string>();
    for (const summary of summaries) {
      if (summary.kind === "leaf") {
        depthBySummaryId.set(summary.summary_id, 0);
        continue;
      }
      unresolvedCondensedIds.add(summary.summary_id);
    }

    const edges = db
      .prepare(
        `SELECT summary_id, parent_summary_id
         FROM summary_parents
         WHERE summary_id IN (
           SELECT summary_id FROM summaries
           WHERE conversation_id = ? AND kind = 'condensed'
         )`,
      )
      .all(conversationId) as SummaryParentEdgeRow[];
    const parentsBySummaryId = new Map<string, string[]>();
    for (const edge of edges) {
      const existing = parentsBySummaryId.get(edge.summary_id) ?? [];
      existing.push(edge.parent_summary_id);
      parentsBySummaryId.set(edge.summary_id, existing);
    }

    while (unresolvedCondensedIds.size > 0) {
      let progressed = false;

      for (const summaryId of [...unresolvedCondensedIds]) {
        const parentIds = parentsBySummaryId.get(summaryId) ?? [];
        if (parentIds.length === 0) {
          depthBySummaryId.set(summaryId, 1);
          unresolvedCondensedIds.delete(summaryId);
          progressed = true;
          continue;
        }

        let maxParentDepth = -1;
        let allParentsResolved = true;
        for (const parentId of parentIds) {
          const parentDepth = depthBySummaryId.get(parentId);
          if (parentDepth == null) {
            allParentsResolved = false;
            break;
          }
          if (parentDepth > maxParentDepth) {
            maxParentDepth = parentDepth;
          }
        }

        if (!allParentsResolved) {
          continue;
        }

        depthBySummaryId.set(summaryId, maxParentDepth + 1);
        unresolvedCondensedIds.delete(summaryId);
        progressed = true;
      }

      // Guard against malformed cycles/cross-conversation references.
      if (!progressed) {
        for (const summaryId of unresolvedCondensedIds) {
          depthBySummaryId.set(summaryId, 1);
        }
        unresolvedCondensedIds.clear();
      }
    }

    for (const summary of summaries) {
      const depth = depthBySummaryId.get(summary.summary_id);
      if (depth == null) {
        continue;
      }
      updateDepthStmt.run(depth, summary.summary_id);
    }
  }
}

function backfillSummaryMetadata(db: DatabaseSync): void {
  const conversationRows = db
    .prepare(`SELECT DISTINCT conversation_id FROM summaries`)
    .all() as Array<{ conversation_id: number }>;
  if (conversationRows.length === 0) {
    return;
  }

  const updateMetadataStmt = db.prepare(
    `UPDATE summaries
     SET earliest_at = ?, latest_at = ?, has_event_time = ?, descendant_count = ?,
         descendant_token_count = ?, source_message_token_count = ?
     WHERE summary_id = ?`,
  );

  for (const conversationRow of conversationRows) {
    const conversationId = conversationRow.conversation_id;
    const summaries = db
      .prepare(
        `SELECT summary_id, conversation_id, kind, depth, token_count, created_at
         FROM summaries
         WHERE conversation_id = ?
         ORDER BY depth ASC, created_at ASC`,
      )
      .all(conversationId) as SummaryDepthRow[];
    if (summaries.length === 0) {
      continue;
    }

    const leafRanges = db
      .prepare(
        `SELECT
           sm.summary_id,
           COUNT(m.event_at) AS known_event_count,
           strftime('%Y-%m-%dT%H:%M:%fZ', COALESCE(MIN(julianday(m.event_at)), MIN(julianday(m.created_at)))) AS earliest_at,
           strftime('%Y-%m-%dT%H:%M:%fZ', COALESCE(MAX(julianday(m.event_at)), MAX(julianday(m.created_at)))) AS latest_at,
           COALESCE(SUM(m.token_count), 0) AS source_message_token_count
         FROM summary_messages sm
         JOIN messages m ON m.message_id = sm.message_id
         JOIN summaries s ON s.summary_id = sm.summary_id
         WHERE s.conversation_id = ? AND s.kind = 'leaf'
         GROUP BY sm.summary_id`,
      )
      .all(conversationId) as SummaryMessageTimeRangeRow[];
    const leafRangeBySummaryId = new Map(
      leafRanges.map((row) => [
        row.summary_id,
        {
          hasEventTime: row.known_event_count > 0,
          earliestAt: row.earliest_at,
          latestAt: row.latest_at,
          sourceMessageTokenCount: row.source_message_token_count,
        },
      ]),
    );

    const edges = db
      .prepare(
        `SELECT summary_id, parent_summary_id
         FROM summary_parents
         WHERE summary_id IN (
           SELECT summary_id FROM summaries WHERE conversation_id = ?
         )`,
      )
      .all(conversationId) as SummaryParentEdgeRow[];
    const parentsBySummaryId = new Map<string, string[]>();
    for (const edge of edges) {
      const existing = parentsBySummaryId.get(edge.summary_id) ?? [];
      existing.push(edge.parent_summary_id);
      parentsBySummaryId.set(edge.summary_id, existing);
    }

    const metadataBySummaryId = new Map<
      string,
      {
        hasEventTime: boolean;
        earliestAt: Date | null;
        latestAt: Date | null;
        descendantCount: number;
        descendantTokenCount: number;
        sourceMessageTokenCount: number;
      }
    >();
    const tokenCountBySummaryId = new Map(
      summaries.map((summary) => [summary.summary_id, Math.max(0, Math.floor(summary.token_count ?? 0))]),
    );

    for (const summary of summaries) {
      const fallbackDate = parseTimestamp(summary.created_at);
      if (summary.kind === "leaf") {
        const range = leafRangeBySummaryId.get(summary.summary_id);
        const earliestAt = parseTimestamp(range?.earliestAt ?? summary.created_at) ?? fallbackDate;
        const latestAt = parseTimestamp(range?.latestAt ?? summary.created_at) ?? fallbackDate;

        metadataBySummaryId.set(summary.summary_id, {
          hasEventTime: range?.hasEventTime ?? false,
          earliestAt,
          latestAt,
          descendantCount: 0,
          descendantTokenCount: 0,
          sourceMessageTokenCount: Math.max(
            0,
            Math.floor(range?.sourceMessageTokenCount ?? 0),
          ),
        });
        continue;
      }

      const parentIds = parentsBySummaryId.get(summary.summary_id) ?? [];
      if (parentIds.length === 0) {
        metadataBySummaryId.set(summary.summary_id, {
          hasEventTime: false,
          earliestAt: fallbackDate,
          latestAt: fallbackDate,
          descendantCount: 0,
          descendantTokenCount: 0,
          sourceMessageTokenCount: 0,
        });
        continue;
      }

      let earliestAt: Date | null = null;
      let latestAt: Date | null = null;
      let descendantCount = 0;
      let descendantTokenCount = 0;
      let sourceMessageTokenCount = 0;
      const hasEventTime = parentIds.some(id => metadataBySummaryId.get(id)?.hasEventTime);

      for (const parentId of parentIds) {
        const parentMetadata = metadataBySummaryId.get(parentId);
        if (!parentMetadata) {
          continue;
        }

        const parentEarliest = parentMetadata.earliestAt;
        if ((parentMetadata.hasEventTime || !hasEventTime) && parentEarliest && (!earliestAt || parentEarliest < earliestAt)) {
          earliestAt = parentEarliest;
        }

        const parentLatest = parentMetadata.latestAt;
        if ((parentMetadata.hasEventTime || !hasEventTime) && parentLatest && (!latestAt || parentLatest > latestAt)) {
          latestAt = parentLatest;
        }

        descendantCount += Math.max(0, parentMetadata.descendantCount) + 1;
        const parentTokenCount = tokenCountBySummaryId.get(parentId) ?? 0;
        descendantTokenCount +=
          Math.max(0, parentTokenCount) + Math.max(0, parentMetadata.descendantTokenCount);
        sourceMessageTokenCount += Math.max(0, parentMetadata.sourceMessageTokenCount);
      }

      metadataBySummaryId.set(summary.summary_id, {
        hasEventTime,
        earliestAt: earliestAt ?? fallbackDate,
        latestAt: latestAt ?? fallbackDate,
        descendantCount: Math.max(0, descendantCount),
        descendantTokenCount: Math.max(0, descendantTokenCount),
        sourceMessageTokenCount: Math.max(0, sourceMessageTokenCount),
      });
    }

    for (const summary of summaries) {
      const metadata = metadataBySummaryId.get(summary.summary_id);
      if (!metadata) {
        continue;
      }

      updateMetadataStmt.run(
        isoStringOrNull(metadata.earliestAt),
        isoStringOrNull(metadata.latestAt),
        Number(metadata.hasEventTime),
        Math.max(0, metadata.descendantCount),
        Math.max(0, metadata.descendantTokenCount),
        Math.max(0, metadata.sourceMessageTokenCount),
        summary.summary_id,
      );
    }
  }
}

/** Recompute legacy summaries once; new summary writers persist these fields on insert. */
function backfillSummaryFieldsOnce(db: DatabaseSync, columnsAdded: boolean): void {
  db.exec(`
    CREATE TABLE IF NOT EXISTS summary_backfill (
      id INTEGER PRIMARY KEY CHECK (id = 1),
      completed_at TEXT NOT NULL DEFAULT (datetime('now'))
    );
  `);
  if (!columnsAdded && db.prepare(`SELECT 1 FROM summary_backfill WHERE id = 1`).get()) return;

  backfillSummaryDepths(db);
  backfillSummaryMetadata(db);
  db.prepare(`INSERT OR REPLACE INTO summary_backfill (id) VALUES (1)`).run();
}

/**
 * `message_parts.part_type` gained `'skill'` and `'command'` in #421. A fresh
 * database is created with both already in its `CHECK`; this rebuilds an
 * existing table that predates them, preserving every row (compaction events
 * included) — see docs/design/message-parts-vs-events-db.md.
 */
function ensureMessagePartsSkillCommandTypes(db: DatabaseSync): void {
  const existing = db
    .prepare(`SELECT sql FROM sqlite_master WHERE type='table' AND name='message_parts'`)
    .get() as { sql?: string } | undefined;
  if (!existing?.sql || existing.sql.includes("'skill'")) return;

  const columns = (db.prepare(`PRAGMA table_info(message_parts)`).all() as Array<{ name: string }>)
    .map((c) => c.name)
    .join(", ");

  // A SAVEPOINT, not a bare sequence of statements: CREATE/INSERT/DROP/RENAME
  // each auto-commit on their own, so a crash between DROP and RENAME would
  // otherwise strand every row (compaction events included) in an orphaned
  // `message_parts_new`, invisible to the `'skill'`-in-CHECK guard above.
  db.exec("SAVEPOINT message_parts_rebuild");
  try {
    db.exec(`
      CREATE TABLE message_parts_new (
        part_id TEXT PRIMARY KEY,
        message_id INTEGER NOT NULL REFERENCES messages(message_id) ON DELETE CASCADE,
        session_id TEXT NOT NULL,
        part_type TEXT NOT NULL CHECK (part_type IN (
          'text', 'reasoning', 'tool', 'patch', 'file',
          'subtask', 'compaction', 'step_start', 'step_finish',
          'snapshot', 'agent', 'retry', 'skill', 'command'
        )),
        ordinal INTEGER NOT NULL,
        text_content TEXT,
        is_ignored INTEGER,
        is_synthetic INTEGER,
        tool_call_id TEXT,
        tool_name TEXT,
        tool_status TEXT,
        tool_input TEXT,
        tool_output TEXT,
        tool_error TEXT,
        tool_title TEXT,
        patch_hash TEXT,
        patch_files TEXT,
        file_mime TEXT,
        file_name TEXT,
        file_url TEXT,
        subtask_prompt TEXT,
        subtask_desc TEXT,
        subtask_agent TEXT,
        step_reason TEXT,
        step_cost REAL,
        step_tokens_in INTEGER,
        step_tokens_out INTEGER,
        snapshot_hash TEXT,
        compaction_auto INTEGER,
        metadata TEXT,
        UNIQUE (message_id, ordinal)
      );
    `);
    db.exec(`INSERT INTO message_parts_new (${columns}) SELECT ${columns} FROM message_parts;`);
    db.exec("DROP TABLE message_parts;");
    db.exec("ALTER TABLE message_parts_new RENAME TO message_parts;");
    db.exec(`
      CREATE INDEX IF NOT EXISTS message_parts_message_idx ON message_parts (message_id);
      CREATE INDEX IF NOT EXISTS message_parts_type_idx ON message_parts (part_type);
    `);
    db.exec("RELEASE SAVEPOINT message_parts_rebuild");
  } catch (err) {
    db.exec("ROLLBACK TO SAVEPOINT message_parts_rebuild");
    db.exec("RELEASE SAVEPOINT message_parts_rebuild");
    throw err;
  }
}

function ensureMessagePartsBackfillTable(db: DatabaseSync): void {
  db.exec(`
    CREATE TABLE IF NOT EXISTS message_parts_skill_command_backfill (
      id INTEGER PRIMARY KEY CHECK (id = 1),
      unmatched_skill_count INTEGER NOT NULL DEFAULT 0,
      completed_at TEXT NOT NULL DEFAULT (datetime('now'))
    );
  `);
}

function insertMessagePart(
  db: DatabaseSync,
  input: { messageId: number; sessionId: string; ordinal: number; part: MessagePart },
): void {
  db.prepare(
    `INSERT INTO message_parts (part_id, message_id, session_id, part_type, ordinal, tool_name, tool_input)
     VALUES (?, ?, ?, ?, ?, ?, ?)`,
  ).run(randomUUID(), input.messageId, input.sessionId, input.part.type, input.ordinal, input.part.name, input.part.args);
}

/**
 * Slash-command parts are fully recoverable from `messages.content`: the
 * `<command-name>`/`<command-args>` block is stored verbatim, so no disk
 * read is needed — same extractor `parseTranscript` uses, applied to what is
 * already in the database.
 */
function backfillCommandParts(db: DatabaseSync): void {
  const rows = db
    .prepare(
      `SELECT m.message_id, m.content, c.session_id
       FROM messages m JOIN conversations c ON c.conversation_id = m.conversation_id
       WHERE m.content LIKE '%<command-name>%'`,
    )
    .all() as Array<{ message_id: number; content: string; session_id: string }>;

  for (const row of rows) {
    extractCommandParts(row.content).forEach((part, ordinal) =>
      insertMessagePart(db, { messageId: row.message_id, sessionId: row.session_id, ordinal, part }),
    );
  }
}

const LAUNCHING_SKILL_PREFIX = "Launching skill: ";

/**
 * The bare tool name ("Skill") that `toolContent` keeps for a tool-only turn
 * loses the invocation's name, but Claude Code's own follow-up turn does not:
 * it opens with `Launching skill: <name>` verbatim (measured across every
 * project database: 1434 such rows, 33 projects, 128 distinct names), stored
 * as-is because that turn's content is a plain string, not a content-block
 * array `extractText`/`toolContent` would otherwise process. So this is
 * recoverable straight from `messages.content`, the same shape as commands —
 * no disk read needed. The name may itself contain a colon (`plugin:skill`);
 * only the newline that ends the line is the terminator.
 */
function backfillSkillParts(db: DatabaseSync): number {
  const rows = db
    .prepare(
      `SELECT m.message_id, m.content, c.session_id
       FROM messages m JOIN conversations c ON c.conversation_id = m.conversation_id
       WHERE m.content LIKE ?`,
    )
    .all(`${LAUNCHING_SKILL_PREFIX}%`) as Array<{ message_id: number; content: string; session_id: string }>;

  let unmatched = 0;
  for (const row of rows) {
    const name = row.content.slice(LAUNCHING_SKILL_PREFIX.length).split("\n")[0].trim();
    if (!name) {
      unmatched++;
      continue;
    }
    insertMessagePart(db, {
      messageId: row.message_id,
      sessionId: row.session_id,
      ordinal: 0,
      part: { type: "skill", name, args: null },
    });
  }
  return unmatched;
}

/**
 * Runs once per database: fills `message_parts` with `skill` and `command`
 * rows for every message already in the store, both recoverable straight
 * from `messages.content` — see backfillCommandParts and backfillSkillParts.
 * Pure `INSERT`: no existing row is ever deleted or rewritten.
 */
function backfillMessagePartsSkillCommand(db: DatabaseSync): void {
  ensureMessagePartsBackfillTable(db);
  if (db.prepare(`SELECT 1 FROM message_parts_skill_command_backfill WHERE id = 1`).get()) return;

  backfillCommandParts(db);
  const unmatchedSkillCount = backfillSkillParts(db);
  db.prepare(`INSERT INTO message_parts_skill_command_backfill (id, unmatched_skill_count) VALUES (1, ?)`)
    .run(unmatchedSkillCount);
}

function legacyPromotedTags(stored: string): string[] | null {
  try {
    return decodeLegacyTags(JSON.parse(stored));
  } catch {
    return null;
  }
}

/** Repair legacy encodings once, with row tags and their FTS entries committed together. */
function backfillPromotedTagsOnce(db: DatabaseSync, fts5Available: boolean): void {
  db.exec(`CREATE TABLE IF NOT EXISTS promoted_tags_backfill (
    id INTEGER PRIMARY KEY CHECK (id = 1),
    completed_at TEXT NOT NULL DEFAULT (datetime('now'))
  )`);
  if (db.prepare("SELECT 1 FROM promoted_tags_backfill WHERE id = 1").get()) return;

  // Reserve the write lock before reading: a deferred read-to-write upgrade
  // can return SQLITE_BUSY without running the connection's busy handler.
  db.exec("BEGIN IMMEDIATE");
  try {
    // Another connection may have completed the repair while the lock waited.
    if (db.prepare("SELECT 1 FROM promoted_tags_backfill WHERE id = 1").get()) {
      db.exec("COMMIT");
      return;
    }
    const update = db.prepare("UPDATE promoted SET tags = ? WHERE rowid = ?");
    const removeFts = fts5Available ? db.prepare("DELETE FROM promoted_fts WHERE rowid = ?") : null;
    const insertFts = fts5Available ? db.prepare("INSERT INTO promoted_fts(rowid, content, tags) VALUES (?, ?, ?)") : null;
    for (const row of db.prepare("SELECT rowid, content, tags, archived_at FROM promoted").iterate()) {
      const { rowid, content, tags: stored, archived_at } = row as {
        rowid: number; content: string; tags: string; archived_at: string | null;
      };
      let tags = legacyPromotedTags(stored);
      if (!tags) continue;
      if (tags.includes("source:passive-capture")) {
        const category = tags.find((tag) => tag.startsWith("category:"))?.slice("category:".length) ?? "";
        tags = tags.filter((tag) => !tag.startsWith("category:"));
        if (!tags.some((tag) => tag.startsWith("type:"))) tags.push(passiveTypeTag(category));
      }
      const normalized = JSON.stringify(tags);
      if (normalized === stored) continue;
      update.run(normalized, rowid);
      removeFts?.run(rowid);
      if (archived_at === null) insertFts?.run(rowid, content, normalized);
    }
    db.prepare("INSERT INTO promoted_tags_backfill (id) VALUES (1)").run();
    db.exec("COMMIT");
  } catch (err) {
    db.exec("ROLLBACK");
    throw err;
  }
}

/** Remove bare prompt labels only when passive-capture provenance establishes their origin. */
function removePassiveIntentLabelsOnce(db: DatabaseSync, fts5Available: boolean): void {
  db.exec(`CREATE TABLE IF NOT EXISTS passive_intent_repair (
    id INTEGER PRIMARY KEY CHECK (id = 1),
    completed_at TEXT NOT NULL DEFAULT (datetime('now'))
  )`);
  if (db.prepare("SELECT 1 FROM passive_intent_repair WHERE id = 1").get()) return;

  db.exec("BEGIN IMMEDIATE");
  try {
    if (db.prepare("SELECT 1 FROM passive_intent_repair WHERE id = 1").get()) {
      db.exec("COMMIT");
      return;
    }
    const remove = db.prepare("DELETE FROM promoted WHERE rowid = ?");
    const removeFts = fts5Available ? db.prepare("DELETE FROM promoted_fts WHERE rowid = ?") : null;
    for (const row of db.prepare(`SELECT rowid, tags FROM promoted
      WHERE content IN ('implement', 'investigate', 'review', 'refactor')
        AND session_id IS NOT 'manual'`).iterate()) {
      const { rowid, tags } = row as { rowid: number; tags: string };
      if (!legacyPromotedTags(tags)?.includes("source:passive-capture")) continue;
      removeFts?.run(rowid);
      remove.run(rowid);
    }
    db.prepare("INSERT INTO passive_intent_repair (id) VALUES (1)").run();
    db.exec("COMMIT");
  } catch (err) {
    db.exec("ROLLBACK");
    throw err;
  }
}

export interface LcmMigrationOptions {
  fts5Available?: boolean;
  /** Override for `~/.claude/projects` — tests only, so the backfill never walks the real disk. */
  claudeProjectsDir?: string;
}

export function runLcmMigrations(db: DatabaseSync, options?: LcmMigrationOptions): void {
  // Foreign keys can stall schema changes against legacy rows (e.g. FTS
  // rebuilds that reinsert messages) — disable them for the sweep.
  withForeignKeysDisabled(db, () => runLcmMigrationsInner(db, options));
}

function runLcmMigrationsInner(db: DatabaseSync, options?: LcmMigrationOptions): void {
  db.exec(`
    CREATE TABLE IF NOT EXISTS conversations (
      conversation_id INTEGER PRIMARY KEY AUTOINCREMENT,
      session_id TEXT NOT NULL,
      title TEXT,
      bootstrapped_at TEXT,
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      updated_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS messages (
      message_id INTEGER PRIMARY KEY AUTOINCREMENT,
      conversation_id INTEGER NOT NULL REFERENCES conversations(conversation_id) ON DELETE CASCADE,
      seq INTEGER NOT NULL,
      role TEXT NOT NULL CHECK (role IN ('system', 'user', 'assistant', 'tool')),
      content TEXT NOT NULL,
      token_count INTEGER NOT NULL,
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      UNIQUE (conversation_id, seq)
    );

    CREATE TABLE IF NOT EXISTS summaries (
      summary_id TEXT PRIMARY KEY,
      conversation_id INTEGER NOT NULL REFERENCES conversations(conversation_id) ON DELETE CASCADE,
      kind TEXT NOT NULL CHECK (kind IN ('leaf', 'condensed')),
      depth INTEGER NOT NULL DEFAULT 0,
      content TEXT NOT NULL,
      token_count INTEGER NOT NULL,
      earliest_at TEXT,
      latest_at TEXT,
      descendant_count INTEGER NOT NULL DEFAULT 0,
      descendant_token_count INTEGER NOT NULL DEFAULT 0,
      source_message_token_count INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      file_ids TEXT NOT NULL DEFAULT '[]'
    );

    CREATE TABLE IF NOT EXISTS message_parts (
      part_id TEXT PRIMARY KEY,
      message_id INTEGER NOT NULL REFERENCES messages(message_id) ON DELETE CASCADE,
      session_id TEXT NOT NULL,
      part_type TEXT NOT NULL CHECK (part_type IN (
        'text', 'reasoning', 'tool', 'patch', 'file',
        'subtask', 'compaction', 'step_start', 'step_finish',
        'snapshot', 'agent', 'retry', 'skill', 'command'
      )),
      ordinal INTEGER NOT NULL,
      text_content TEXT,
      is_ignored INTEGER,
      is_synthetic INTEGER,
      tool_call_id TEXT,
      tool_name TEXT,
      tool_status TEXT,
      tool_input TEXT,
      tool_output TEXT,
      tool_error TEXT,
      tool_title TEXT,
      patch_hash TEXT,
      patch_files TEXT,
      file_mime TEXT,
      file_name TEXT,
      file_url TEXT,
      subtask_prompt TEXT,
      subtask_desc TEXT,
      subtask_agent TEXT,
      step_reason TEXT,
      step_cost REAL,
      step_tokens_in INTEGER,
      step_tokens_out INTEGER,
      snapshot_hash TEXT,
      compaction_auto INTEGER,
      metadata TEXT,
      UNIQUE (message_id, ordinal)
    );

    CREATE TABLE IF NOT EXISTS summary_messages (
      summary_id TEXT NOT NULL REFERENCES summaries(summary_id) ON DELETE CASCADE,
      message_id INTEGER NOT NULL REFERENCES messages(message_id) ON DELETE RESTRICT,
      ordinal INTEGER NOT NULL,
      PRIMARY KEY (summary_id, message_id)
    );

    CREATE TABLE IF NOT EXISTS summary_parents (
      summary_id TEXT NOT NULL REFERENCES summaries(summary_id) ON DELETE CASCADE,
      parent_summary_id TEXT NOT NULL REFERENCES summaries(summary_id) ON DELETE RESTRICT,
      ordinal INTEGER NOT NULL,
      PRIMARY KEY (summary_id, parent_summary_id)
    );

    CREATE TABLE IF NOT EXISTS context_items (
      conversation_id INTEGER NOT NULL REFERENCES conversations(conversation_id) ON DELETE CASCADE,
      ordinal INTEGER NOT NULL,
      item_type TEXT NOT NULL CHECK (item_type IN ('message', 'summary')),
      message_id INTEGER REFERENCES messages(message_id) ON DELETE RESTRICT,
      summary_id TEXT REFERENCES summaries(summary_id) ON DELETE RESTRICT,
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      PRIMARY KEY (conversation_id, ordinal),
      CHECK (
        (item_type = 'message' AND message_id IS NOT NULL AND summary_id IS NULL) OR
        (item_type = 'summary' AND summary_id IS NOT NULL AND message_id IS NULL)
      )
    );

    CREATE TABLE IF NOT EXISTS large_files (
      file_id TEXT PRIMARY KEY,
      conversation_id INTEGER NOT NULL REFERENCES conversations(conversation_id) ON DELETE CASCADE,
      file_name TEXT,
      mime_type TEXT,
      byte_size INTEGER,
      storage_uri TEXT NOT NULL,
      exploration_summary TEXT,
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    -- Indexes
    CREATE INDEX IF NOT EXISTS conversations_session_idx ON conversations (session_id);
    CREATE INDEX IF NOT EXISTS messages_conv_seq_idx ON messages (conversation_id, seq);
    CREATE INDEX IF NOT EXISTS summaries_conv_created_idx ON summaries (conversation_id, created_at);
    CREATE INDEX IF NOT EXISTS message_parts_message_idx ON message_parts (message_id);
    CREATE INDEX IF NOT EXISTS message_parts_type_idx ON message_parts (part_type);
    CREATE INDEX IF NOT EXISTS summary_messages_message_idx ON summary_messages (message_id);
    CREATE INDEX IF NOT EXISTS summary_parents_parent_idx ON summary_parents (parent_summary_id);
    CREATE INDEX IF NOT EXISTS context_items_conv_idx ON context_items (conversation_id, ordinal);
    CREATE INDEX IF NOT EXISTS context_items_message_idx ON context_items (message_id);
    CREATE INDEX IF NOT EXISTS context_items_summary_idx ON context_items (summary_id);
    CREATE INDEX IF NOT EXISTS large_files_conv_idx ON large_files (conversation_id, created_at);
  `);

  // Forward-compatible conversations migration for existing DBs.
  const conversationColumns = db.prepare(`PRAGMA table_info(conversations)`).all() as Array<{
    name?: string;
  }>;
  const hasBootstrappedAt = conversationColumns.some((col) => col.name === "bootstrapped_at");
  if (!hasBootstrappedAt) {
    db.exec(`ALTER TABLE conversations ADD COLUMN bootstrapped_at TEXT`);
  }

  const messageColumns = db.prepare("PRAGMA table_info(messages)").all() as SummaryColumnInfo[];
  if (!messageColumns.some(column => column.name === "event_at")) db.exec("ALTER TABLE messages ADD COLUMN event_at TEXT");
  if (!messageColumns.some(column => column.name === "event_time_source")) {
    db.exec("ALTER TABLE messages ADD COLUMN event_time_source TEXT");
  }
  db.exec(`CREATE TABLE IF NOT EXISTS transcript_tool_calls (
    session_id TEXT NOT NULL,
    call_id TEXT NOT NULL,
    message_id INTEGER NOT NULL REFERENCES messages(message_id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    input TEXT,
    input_bytes INTEGER,
    truncated INTEGER NOT NULL DEFAULT 0 CHECK(truncated IN (0, 1)),
    outcome TEXT NOT NULL DEFAULT 'unknown' CHECK(outcome IN ('succeeded', 'failed', 'blocked', 'denied', 'interrupted', 'unknown')),
    harness_error INTEGER CHECK(harness_error IN (0, 1)),
    exit_code INTEGER,
    PRIMARY KEY(session_id, call_id)
  );
  CREATE INDEX IF NOT EXISTS transcript_tool_calls_message_idx ON transcript_tool_calls(message_id);`);
  const callColumns = db.prepare("PRAGMA table_info(transcript_tool_calls)").all() as SummaryColumnInfo[];
  if (!callColumns.some(column => column.name === "block_reason")) db.exec("ALTER TABLE transcript_tool_calls ADD COLUMN block_reason TEXT");
  db.exec(`CREATE INDEX IF NOT EXISTS transcript_tool_calls_session_message_idx ON transcript_tool_calls(session_id, message_id);
    CREATE TABLE IF NOT EXISTS tool_lesson_state (
      singleton INTEGER PRIMARY KEY CHECK(singleton = 1), generation INTEGER NOT NULL, calls_seen TEXT
    );
    CREATE TABLE IF NOT EXISTS tool_lessons (
      generation INTEGER NOT NULL, lesson_key TEXT NOT NULL,
      kind TEXT NOT NULL, retired INTEGER NOT NULL DEFAULT 0,
      last_seen TEXT NOT NULL, data TEXT NOT NULL,
      PRIMARY KEY(generation, lesson_key)
    );
    CREATE INDEX IF NOT EXISTS tool_lessons_recent_idx ON tool_lessons(generation, retired, last_seen DESC, lesson_key);`);
  db.exec(`CREATE TABLE IF NOT EXISTS session_web_urls (
    session_id TEXT NOT NULL, url TEXT NOT NULL, PRIMARY KEY(session_id, url)
  );
  CREATE TABLE IF NOT EXISTS session_commits (
    session_id TEXT NOT NULL, message_id INTEGER NOT NULL REFERENCES messages(message_id) ON DELETE CASCADE,
    hash TEXT NOT NULL, subject TEXT, author_at TEXT, committed_at TEXT, branch TEXT, resolved INTEGER NOT NULL CHECK(resolved IN (0, 1)),
    evidence TEXT NOT NULL CHECK(evidence IN ('commit-output', 'session-trailer')), evidence_value TEXT NOT NULL,
    PRIMARY KEY(message_id, evidence, evidence_value, hash)
  );
  CREATE INDEX IF NOT EXISTS session_commits_session_idx ON session_commits(session_id);`);
  const commitColumns = db.prepare("PRAGMA table_info(session_commits)").all() as SummaryColumnInfo[];
  if (!commitColumns.some(column => column.name === "committed_at")) db.exec("ALTER TABLE session_commits ADD COLUMN committed_at TEXT");
  const depthAdded = ensureSummaryDepthColumn(db);
  db.exec("CREATE INDEX IF NOT EXISTS summaries_conv_depth_id_idx ON summaries (conversation_id, depth, summary_id)");
  const metadataAdded = ensureSummaryMetadataColumns(db);
  ensureSummaryEventTimeFlag(db);
  backfillSummaryFieldsOnce(db, depthAdded || metadataAdded);
  ensureMessagePartsSkillCommandTypes(db);

  // Redaction stats (counts of secrets scrubbed per project per category).
  // v0.7.0 created this table with CHECK(category IN ('built_in', 'global', 'project')).
  // v0.8.0 adds 'gitleaks' to the enum. CREATE TABLE IF NOT EXISTS silently skips creation
  // on existing DBs, so we must detect the stale constraint and recreate.
  // redaction_stats is a pure counter table (no user data) — DROP/RECREATE is safe.
  const redactionStatsRow = db
    .prepare("SELECT sql FROM sqlite_master WHERE type='table' AND name='redaction_stats'")
    .get() as { sql?: string } | undefined;
  const needsRedactionStatsMigration =
    !redactionStatsRow ||
    (redactionStatsRow.sql !== undefined && !redactionStatsRow.sql.includes("'gitleaks'"));
  if (needsRedactionStatsMigration) {
    db.exec(`
      DROP TABLE IF EXISTS redaction_stats;
      CREATE TABLE redaction_stats (
        project_id TEXT NOT NULL,
        category TEXT NOT NULL CHECK(category IN ('built_in', 'global', 'project', 'gitleaks')),
        count INTEGER NOT NULL DEFAULT 0,
        PRIMARY KEY (project_id, category)
      );
    `);
  }

  // Session instructions (CLAUDE.md captured on startup)
  db.exec(`
    CREATE TABLE IF NOT EXISTS session_instructions (
      id INTEGER PRIMARY KEY CHECK (id = 1),
      content TEXT NOT NULL,
      content_hash TEXT NOT NULL,
      updated_at TEXT NOT NULL DEFAULT (datetime('now'))
    );
  `);

  // Compaction marks — one row per session that was just compacted, so the restore that
  // follows knows to replay the saved instructions instead of the episodic memory. In the
  // project DB rather than daemon memory because the daemon can restart inside the window.
  db.exec(`
    CREATE TABLE IF NOT EXISTS session_compactions (
      session_id TEXT PRIMARY KEY,
      compacted_at INTEGER NOT NULL
    );
  `);

  // Promoted memories (cross-session, agent-stored)
  db.exec(`
    CREATE TABLE IF NOT EXISTS promoted (
      id TEXT PRIMARY KEY,
      content TEXT NOT NULL,
      tags TEXT NOT NULL DEFAULT '[]',
      source_summary_id TEXT,
      project_id TEXT NOT NULL,
      session_id TEXT,
      depth INTEGER NOT NULL DEFAULT 0,
      confidence REAL NOT NULL DEFAULT 1.0,
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE INDEX IF NOT EXISTS promoted_project_idx ON promoted (project_id, created_at);
  `);

  // Whether a conversation's rows carry the role tagging that separates tool
  // output from what a person said. NULL means unknown: the rows predate the
  // tagging parser and cannot be re-tagged, because 75% of the sessions have
  // no transcript left on disk to re-read. Search must include them and say so
  // rather than hide 79% of history behind a filter that looks complete.
  const taggingColumns = db.prepare(`PRAGMA table_info(conversations)`).all() as Array<{ name?: string }>;
  if (!taggingColumns.some((col) => col.name === "role_tagging")) {
    db.exec(`ALTER TABLE conversations ADD COLUMN role_tagging TEXT DEFAULT NULL`);
  }
  // Existing rows may have been captured before or after a parser shape change.
  // Neither age nor role tagging establishes which count their rows represent.
  if (!taggingColumns.some((col) => col.name === "parser_shape")) {
    db.exec(`ALTER TABLE conversations ADD COLUMN parser_shape TEXT DEFAULT NULL`);
  }

  ensureSubagentAttributionColumns(db);
  ensureConversationBoundaryColumn(db);
  backfillSubagentAttribution(db, options?.claudeProjectsDir ?? defaultClaudeProjectsDir());
  backfillMessagePartsSkillCommand(db);

  // Add archived_at to promoted if not present
  const promotedColumns = db.prepare(`PRAGMA table_info(promoted)`).all() as Array<{ name?: string }>;
  const hasArchivedAt = promotedColumns.some((col) => col.name === "archived_at");
  if (!hasArchivedAt) {
    db.exec(`ALTER TABLE promoted ADD COLUMN archived_at TEXT DEFAULT NULL`);
  }

  db.exec(`CREATE TABLE IF NOT EXISTS worker_claim_markers (
    session_id TEXT NOT NULL, call_id TEXT NOT NULL, PRIMARY KEY(session_id, call_id)
  );`);
  // Jobs handed to this project's workers: only their ids make a claim result a copied claim.
  db.exec(`CREATE TABLE IF NOT EXISTS worker_issued_jobs (
    job_id TEXT PRIMARY KEY, issued_at TEXT NOT NULL DEFAULT (datetime('now'))
  );`);

  // A worker's exclusion is permanent; only its admission can be revoked.
  db.exec(`CREATE TABLE IF NOT EXISTS summarize_workers (
    session_id TEXT PRIMARY KEY, cwd TEXT NOT NULL, client TEXT NOT NULL,
    owner TEXT, state TEXT NOT NULL CHECK(state IN ('active', 'finished', 'abandoned')),
    exclusion_reason TEXT,
    last_activity TEXT NOT NULL DEFAULT (datetime('now'))
  );`);
  const workerColumns = db.prepare("PRAGMA table_info(summarize_workers)").all() as Array<{ name: string }>;
  ensureToolLessonIncrementalSchema(db);
  if (!workerColumns.some(column => column.name === "exclusion_reason")) {
    db.exec("ALTER TABLE summarize_workers ADD COLUMN exclusion_reason TEXT");
  }

  // Session ingest log — tracks which sessions are fully ingested
  db.exec(`
    CREATE TABLE IF NOT EXISTS session_ingest_log (
      session_id TEXT PRIMARY KEY,
      completed_at TEXT NOT NULL DEFAULT (datetime('now')),
      message_count INTEGER NOT NULL DEFAULT 0
    );
  `);

  db.exec(`
    CREATE TABLE IF NOT EXISTS llm_usage_stats (
      provider TEXT NOT NULL,
      model TEXT NOT NULL,
      calls_total INTEGER NOT NULL DEFAULT 0,
      calls_ok INTEGER NOT NULL DEFAULT 0,
      calls_failed INTEGER NOT NULL DEFAULT 0,
      tokens_spent_total INTEGER NOT NULL DEFAULT 0,
      tokens_input_total INTEGER NOT NULL DEFAULT 0,
      tokens_cached_total INTEGER NOT NULL DEFAULT 0,
      tokens_output_total INTEGER NOT NULL DEFAULT 0,
      -- NULL means no call was ever priced; never read a missing cost as zero.
      cost_usd_total REAL,
      calls_with_cost INTEGER NOT NULL DEFAULT 0,
      updated_at TEXT NOT NULL DEFAULT (datetime('now')),
      PRIMARY KEY (provider, model)
    );
  `);

  ensureLlmUsageBreakdownColumns(db);

  // Recall surfacing log — tracks when promoted memories are shown in user-prompt context
  db.exec(`
    CREATE TABLE IF NOT EXISTS recall_surfacing (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      memory_id TEXT NOT NULL,
      session_id TEXT,
      surfaced_at TEXT NOT NULL DEFAULT (datetime('now'))
    );
    CREATE INDEX IF NOT EXISTS recall_surfacing_memory_idx ON recall_surfacing (memory_id);
  `);

  // Replay manifest — the ordered session list frozen at the start of a replay run.
  // Makes "resume" deterministic: the same set in the same order across runs.
  db.exec(`
    CREATE TABLE IF NOT EXISTS replay_manifest (
      run_id TEXT NOT NULL,
      command TEXT NOT NULL,
      position INTEGER NOT NULL,
      session_id TEXT NOT NULL,
      model TEXT,
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      PRIMARY KEY (run_id, position)
    );
    CREATE INDEX IF NOT EXISTS replay_manifest_session_idx ON replay_manifest (run_id, session_id);
  `);

  // Replay ledger — one row per completed session compaction. A row is written
  // only after its summary is persisted, so a row is durable proof of done work.
  db.exec(`
    CREATE TABLE IF NOT EXISTS replay_ledger (
      run_id TEXT NOT NULL,
      session_id TEXT NOT NULL,
      position INTEGER NOT NULL,
      prev_session_id TEXT,
      content_fingerprint TEXT NOT NULL,
      summary_id TEXT,
      model TEXT,
      outcome TEXT NOT NULL DEFAULT 'compacted',
      completed_at TEXT NOT NULL DEFAULT (datetime('now')),
      PRIMARY KEY (run_id, session_id)
    );
    CREATE INDEX IF NOT EXISTS replay_ledger_position_idx ON replay_ledger (run_id, position);
  `);
  ensureReplayLedgerOutcomeColumn(db);
  ensureTranscriptCursorTable(db);
  installProjectTimeline(db);

  const fts5Available = options?.fts5Available ?? getLcmDbFeatures(db).fts5Available;
  if (!fts5Available) {
    backfillPromotedTagsOnce(db, false);
    removePassiveIntentLabelsOnce(db, false);
    installRecallUsage(db);
    return;
  }

  // Promoted FTS5
  const hasPromotedFts = db
    .prepare("SELECT name FROM sqlite_master WHERE type='table' AND name='promoted_fts'")
    .get();

  if (!hasPromotedFts) {
    db.exec(`
      CREATE VIRTUAL TABLE promoted_fts USING fts5(
        content,
        tags,
        tokenize='porter unicode61'
      );
      INSERT INTO promoted_fts(rowid, content, tags)
      SELECT rowid, content, tags FROM promoted WHERE archived_at IS NULL;
    `);
  }

  backfillPromotedTagsOnce(db, true);
  removePassiveIntentLabelsOnce(db, true);

  // FTS5 virtual tables for full-text search (cannot use IF NOT EXISTS, so check manually)
  const hasFts = db
    .prepare("SELECT name FROM sqlite_master WHERE type='table' AND name='messages_fts'")
    .get();

  if (hasFts) {
    // Check for stale schema: external-content FTS tables with content_rowid cause errors.
    // Drop and recreate as standalone FTS if the old schema is detected.
    const ftsSchema = (
      db
        .prepare("SELECT sql FROM sqlite_master WHERE type='table' AND name='messages_fts'")
        .get() as { sql: string } | undefined
    )?.sql;
    if (ftsSchema && ftsSchema.includes("content_rowid")) {
      db.exec("DROP TABLE messages_fts");
      db.exec(`
        CREATE VIRTUAL TABLE messages_fts USING fts5(
          content,
          tokenize='porter unicode61'
        );
        INSERT INTO messages_fts(rowid, content) SELECT message_id, content FROM messages;
      `);
    }
  } else {
    db.exec(`
      CREATE VIRTUAL TABLE messages_fts USING fts5(
        content,
        tokenize='porter unicode61'
      );
    `);
  }

  const summariesFtsInfo = db
    .prepare("SELECT sql FROM sqlite_master WHERE type='table' AND name='summaries_fts'")
    .get() as { sql?: string } | undefined;
  const summariesFtsSql = summariesFtsInfo?.sql ?? "";
  const summariesFtsColumns = db.prepare(`PRAGMA table_info(summaries_fts)`).all() as Array<{
    name?: string;
  }>;
  const hasSummaryIdColumn = summariesFtsColumns.some((col) => col.name === "summary_id");
  const shouldRecreateSummariesFts =
    !summariesFtsInfo ||
    !hasSummaryIdColumn ||
    summariesFtsSql.includes("content_rowid='summary_id'") ||
    summariesFtsSql.includes('content_rowid="summary_id"');
  if (shouldRecreateSummariesFts) {
    db.exec(`
      DROP TABLE IF EXISTS summaries_fts;
      CREATE VIRTUAL TABLE summaries_fts USING fts5(
        summary_id UNINDEXED,
        content,
        tokenize='porter unicode61'
      );
      INSERT INTO summaries_fts(summary_id, content)
      SELECT summary_id, content FROM summaries;
    `);
  }
  installRecallUsage(db);
}
