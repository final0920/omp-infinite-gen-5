// src/db/events-stats.ts
import { readdirSync, statSync } from "node:fs";
import { join } from "node:path";
import { eventsDir } from "./events-path.js";
import type { LcmPaths } from "../lcm-paths.js";
import { DatabaseSync } from "node:sqlite";
import { readEventHealthStats } from "../hooks/events-db.js";

export interface EventStats {
  captured: number;
  unprocessed: number;
  errors: number;
  lastCapture: string | null;
  /** Sidecar DBs actually read; smaller than `total` when the scan was capped or timed out. */
  scanned: number;
  /** Sidecar DBs present on disk. */
  total: number;
}

export interface DetailedEventStats extends EventStats {
  hookFailures: number;
  recentHookFailures: Array<{
    file: string; sessionId: string; harness: string; hook: string;
    operation: string; code: string; createdAt: string;
  }>;
  projects: Array<{
    file: string;
    captured: number;
    unprocessed: number;
    lastCapture: string | null;
  }>;
  recentErrors: Array<{ created_at: string; hook: string; error: string }>;
  recentHookObservations: Array<{
    file: string;
    sessionId: string;
    harness: string;
    hook: string;
    operation: string;
    kind: string;
    status: string;
    reason: string;
    count: number;
    lastSeen: string;
  }>;
}

const MAX_DBS = 50;

/** Sidecar DB filenames, most recently modified first, so a capped scan covers the active projects. */
function listEventDbsNewestFirst(dir: string): string[] {
  const files = readdirSync(dir).filter(f => f.endsWith(".db"));
  const mtime = (f: string): number => {
    try { return statSync(join(dir, f)).mtimeMs; } catch { return 0; }
  };
  return files
    .map(f => ({ f, m: mtime(f) }))
    .sort((a, b) => b.m - a.m)
    .map(({ f }) => f);
}

/**
 * Scan all sidecar DBs and aggregate event stats.
 * Used by both lcm doctor and lcm stats.
 * @param timeoutMs Total time budget for the scan (default 2000ms)
 */
export function collectEventStats(paths: LcmPaths, timeoutMs = 2000): EventStats {
  const result: EventStats = { captured: 0, unprocessed: 0, errors: 0, lastCapture: null, scanned: 0, total: 0 };
  const dir = eventsDir(paths);
  // Listing and sorting the sidecars counts against the budget too.
  const deadline = Date.now() + timeoutMs;

  let files: string[];
  try {
    files = listEventDbsNewestFirst(dir);
  } catch {
    return result; // events dir doesn't exist
  }
  result.total = files.length;

  let scanned = 0;

  for (const file of files) {
    if (scanned >= MAX_DBS || Date.now() >= deadline) break;
    try {
      const db = new DatabaseSync(join(dir, file), { readOnly: true });
      // Override busy_timeout for scan connections (500ms instead of default 5000ms)
      db.exec("PRAGMA busy_timeout = 500");
      try {
        const stats = readEventHealthStats(db);
        result.captured += stats.totalEvents;
        result.unprocessed += stats.unprocessed;
        result.errors += stats.errors;
        if (stats.lastCapture && (!result.lastCapture || stats.lastCapture > result.lastCapture)) {
          result.lastCapture = stats.lastCapture;
        }
      } finally {
        db.close();
      }
      scanned++;
    } catch {
      scanned++;
    }
  }

  result.scanned = scanned;
  return result;
}

/**
 * Detailed scan for verbose doctor output — returns per-project breakdown + recent errors.
 */
export function collectDetailedEventStats(paths: LcmPaths, timeoutMs = 2000): DetailedEventStats {
  const result: DetailedEventStats = {
    captured: 0, unprocessed: 0, errors: 0, lastCapture: null, scanned: 0, total: 0,
    projects: [], recentErrors: [], recentHookObservations: [], recentHookFailures: [], hookFailures: 0,
  };
  const dir = eventsDir(paths);
  const deadline = Date.now() + timeoutMs;

  let files: string[];
  try {
    files = listEventDbsNewestFirst(dir);
  } catch {
    return result;
  }
  result.total = files.length;

  let scanned = 0;

  for (const file of files) {
    if (scanned >= MAX_DBS || Date.now() >= deadline) break;
    try {
      const db = new DatabaseSync(join(dir, file), { readOnly: true });
      db.exec("PRAGMA busy_timeout = 500");
      try {
        const stats = readEventHealthStats(db);
        result.captured += stats.totalEvents;
        result.unprocessed += stats.unprocessed;
        result.errors += stats.errors;
        if (stats.lastCapture && (!result.lastCapture || stats.lastCapture > result.lastCapture)) {
          result.lastCapture = stats.lastCapture;
        }
        result.projects.push({
          file,
          captured: stats.totalEvents,
          unprocessed: stats.unprocessed,
          lastCapture: stats.lastCapture,
        });
        // Collect recent errors for verbose display (exclude maintenance/pruning entries)
        const hasErrorLog = db.prepare(
          "SELECT 1 FROM sqlite_master WHERE type = 'table' AND name = 'error_log'"
        ).get();
        if (hasErrorLog) {
          const errors = db.prepare(
            "SELECT created_at, hook, error FROM error_log WHERE hook NOT LIKE 'maintenance:%' ORDER BY id DESC LIMIT 5"
          ).all() as Array<{ created_at: string; hook: string; error: string }>;
          result.recentErrors.push(...errors);
        }
        const hasHookObservations = db.prepare(
          "SELECT 1 FROM sqlite_master WHERE type = 'table' AND name = 'hook_observation_summary'"
        ).get();
        if (hasHookObservations) {
          const observations = db.prepare(`
            SELECT session_id AS sessionId, harness, hook, operation, kind, status, reason,
                   count, last_seen AS lastSeen
            FROM hook_observation_summary
            WHERE last_seen >= datetime('now', '-7 days')
            ORDER BY last_seen DESC LIMIT 10
          `).all() as Array<Omit<DetailedEventStats["recentHookObservations"][number], "file">>;
          result.recentHookObservations.push(...observations.map((observation) => ({ file, ...observation })));
          const hasHookFailures = db.prepare(
            "SELECT 1 FROM sqlite_master WHERE type = 'table' AND name = 'hook_observation_failures'"
          ).get();
          if (hasHookFailures) {
            const failures = db.prepare(
              "SELECT COUNT(*) AS count FROM hook_observation_failures WHERE created_at >= datetime('now', '-7 days')"
            ).get() as { count: number };
            result.hookFailures += failures.count;
            const recent = db.prepare(`
              SELECT session_id AS sessionId, harness, hook, operation, code,
                     created_at AS createdAt
              FROM hook_observation_failures
              WHERE created_at >= datetime('now', '-7 days')
              ORDER BY id DESC LIMIT 5
            `).all() as Array<Omit<DetailedEventStats["recentHookFailures"][number], "file">>;
            result.recentHookFailures.push(...recent.map((failure) => ({ file, ...failure })));
          }
        }
      } finally {
        db.close();
      }
      scanned++;
    } catch {
      scanned++;
    }
  }

  result.scanned = scanned;
  // Sort and limit recent errors across all DBs
  result.recentErrors.sort((a, b) => b.created_at.localeCompare(a.created_at));
  result.recentErrors = result.recentErrors.slice(0, 5);
  result.recentHookObservations.sort((a, b) => b.lastSeen.localeCompare(a.lastSeen));
  result.recentHookObservations = result.recentHookObservations.slice(0, 20);
  result.recentHookFailures.sort((a, b) => b.createdAt.localeCompare(a.createdAt));
  result.recentHookFailures = result.recentHookFailures.slice(0, 10);

  return result;
}
