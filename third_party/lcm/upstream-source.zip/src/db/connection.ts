import { DatabaseSync } from "node:sqlite";
import { mkdirSync } from "fs";
import { dirname } from "path";

type ConnectionEntry = {
  db: DatabaseSync;
  refs: number;
  path: string;
};

const _connections = new Map<string, ConnectionEntry>();

function connectionKey(dbPath: string, readOnly = false): string {
  return readOnly ? `${dbPath}\0read-only` : dbPath;
}

function isConnectionHealthy(db: DatabaseSync): boolean {
  try {
    db.prepare("SELECT 1").get();
    return true;
  } catch {
    return false;
  }
}

function forceCloseConnection(entry: ConnectionEntry): void {
  try {
    entry.db.close();
  } catch {
    // Ignore close failures; caller is already replacing/removing this handle.
  }
}

/** Open a configured independent handle. The caller owns and closes it. */
export function openStandaloneLcmConnection(dbPath: string, options: { readOnly?: boolean } = {}): DatabaseSync {
  if (!options.readOnly) mkdirSync(dirname(dbPath), { recursive: true });
  const db = new DatabaseSync(dbPath, options.readOnly ? { readOnly: true } : {});
  try {
    // Setup pragmas can meet a lock too, so install the timeout first.
    db.exec("PRAGMA busy_timeout = 5000");
    if (!options.readOnly) {
      // Enable WAL mode for better concurrent read performance
      db.exec("PRAGMA journal_mode = WAL");
      // Enable foreign key enforcement
      db.exec("PRAGMA foreign_keys = ON");
    }
    return db;
  } catch (error) {
    try { db.close(); } catch { /* preserve the setup error */ }
    throw error;
  }
}

export function getLcmConnection(dbPath: string, options: { readOnly?: boolean } = {}): DatabaseSync {
  // No TOCTOU race here: Node.js is single-threaded and this function is
  // synchronous. There is no await/yield between the health check and the
  // refs increment, so no other caller can interleave and close the connection
  // in between. The sequence (check => increment => return) is atomic w.r.t.
  // the JavaScript event loop.
  const key = connectionKey(dbPath, options.readOnly);
  const existing = _connections.get(key);
  if (existing) {
    if (isConnectionHealthy(existing.db)) {
      existing.refs += 1;
      return existing.db;
    }
    forceCloseConnection(existing);
    _connections.delete(key);
  }

  const db = openStandaloneLcmConnection(dbPath, options);

  _connections.set(key, { db, refs: 1, path: dbPath });
  return db;
}

export interface PoolStats {
  totalConnections: number;
  activeConnections: number;
  idleConnections: number;
  connections: Array<{
    path: string;
    refs: number;
    status: "active" | "idle";
  }>;
}

export function getPoolStats(): PoolStats {
  const connections = Array.from(_connections.values()).map((entry) => ({
    path: entry.path,
    refs: entry.refs,
    status: (entry.refs > 0 ? "active" : "idle") as "active" | "idle",
  }));
  const activeConnections = connections.filter((c) => c.status === "active").length;
  return {
    totalConnections: connections.length,
    activeConnections,
    idleConnections: connections.length - activeConnections,
    connections,
  };
}

/**
 * Returns true if a read-write pooled connection for dbPath is currently open.
 * Callers that track mutable per-connection state use this to invalidate it when
 * the writable handle is evicted; read-only handles do not carry that state.
 */
export function isLcmConnectionOpen(dbPath: string): boolean {
  return _connections.has(dbPath);
}

export function closeLcmConnection(dbPath?: string, options: { readOnly?: boolean } = {}): void {
  if (typeof dbPath === "string" && dbPath.trim()) {
    const key = connectionKey(dbPath, options.readOnly);
    const entry = _connections.get(key);
    if (!entry) {
      return;
    }
    entry.refs = Math.max(0, entry.refs - 1);
    if (entry.refs === 0) {
      forceCloseConnection(entry);
      _connections.delete(key);
    }
    return;
  }

  for (const entry of _connections.values()) {
    forceCloseConnection(entry);
  }
  _connections.clear();
}
