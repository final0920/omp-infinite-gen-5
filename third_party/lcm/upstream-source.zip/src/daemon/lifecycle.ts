import { closeSync, existsSync, mkdirSync, openSync, readdirSync, readFileSync, renameSync, statSync, utimesSync, writeFileSync, unlinkSync } from "node:fs";
import { randomUUID } from "node:crypto";
import { spawn, spawnSync, type ChildProcess } from "node:child_process";
import { join, dirname } from "node:path";
import { ensureAuthToken } from "./auth.js";
import { readHold } from "./hold.js";

export type EnsureDaemonOptions = {
  port: number;
  pidFilePath: string;
  /** Overall connection/startup budget, including probes, PID waits and spawn wait. */
  spawnTimeoutMs: number;
  expectedVersion?: string;
  /** Build fingerprint (BUILD_ID) the daemon must report; a daemon without one is accepted. */
  expectedBuild?: string;
  spawnCommand?: string;
  spawnArgs?: string[];
  /** Connect only if a daemon is already up; never spawn one. */
  noSpawn?: boolean;
  _skipSpawn?: boolean; // for testing — don't attempt to spawn
  _spawnOverride?: typeof spawn;
  _skipHealthWait?: boolean;
  _fetchOverride?: typeof globalThis.fetch;
};

export type EnsureDaemonResult = {
  connected: boolean;
  port: number;
  spawned: boolean;
  /** How the running daemon's version relates to the caller's; absent when no daemon answered. */
  ownership?: DaemonOwnership;
  /** Version the running daemon reported, when one answered. */
  daemonVersion?: string;
  /** A listener held a probe past its deadline; do not spawn over it. */
  unresponsive?: boolean;
};

export type HealthResponse = {
  status: string;
  version?: string;
  build?: string;
  pid?: number;
  uptime?: number;
};

/**
 * One daemon, newest wins.
 * - `restart`: the caller is newer than the daemon (or same version, different build); the caller replaces it.
 * - `older-caller`: the daemon is newer but shares the caller's compatible component; the caller connects and warns once.
 * - `incompatible`: the daemon is newer and its compatible component differs; the caller must not use it.
 * - `current`: nothing to do.
 * The compatible component is the minor while the package is at 0.x and the major from 1.0.
 */
export type DaemonOwnership = "current" | "restart" | "older-caller" | "incompatible";

/** Releases only: a prerelease or build suffix does not parse, so it falls back to string equality. */
function parseSemver(v: string): [number, number, number] | undefined {
  const m = /^v?(\d+)\.(\d+)\.(\d+)$/.exec(v);
  return m ? [Number(m[1]), Number(m[2]), Number(m[3])] : undefined;
}

/** True when `a` is a release version strictly older than `b`; false when either does not parse. */
export function isOlderVersion(a: string, b: string): boolean {
  const pa = parseSemver(a);
  const pb = parseSemver(b);
  return Boolean(pa && pb) && compareSemver(pa!, pb!) < 0;
}

function compareSemver(a: [number, number, number], b: [number, number, number]): number {
  for (let i = 0; i < 3; i++) if (a[i] !== b[i]) return a[i] - b[i];
  return 0;
}

function compatibleComponent(v: [number, number, number]): string {
  return v[0] === 0 ? `0.${v[1]}` : `${v[0]}`;
}

/** True when two release versions share the compatible component (minor while 0.x, major from 1.0). */
export function isCompatibleVersion(a: string | undefined, b: string | undefined): boolean {
  const pa = a ? parseSemver(a) : undefined;
  const pb = b ? parseSemver(b) : undefined;
  return Boolean(pa && pb) && compatibleComponent(pa!) === compatibleComponent(pb!);
}

export function daemonOwnership(health: HealthResponse, expected: { version?: string; build?: string }): DaemonOwnership {
  const mine = expected.version ? parseSemver(expected.version) : undefined;
  const theirs = health.version ? parseSemver(health.version) : undefined;
  if (mine && theirs) {
    const cmp = compareSemver(mine, theirs);
    if (cmp > 0) return "restart";
    if (cmp < 0) return compatibleComponent(mine) === compatibleComponent(theirs) ? "older-caller" : "incompatible";
  } else if (expected.version && health.version && health.version !== expected.version) {
    // Unparseable on one side (a prerelease): a release daemon is never replaced by it.
    return theirs ? "older-caller" : "restart";
  }
  if (expected.build && health.build && health.build !== expected.build) return "restart";
  return "current";
}

/** True when the caller should replace the running daemon with its own build. */
export function isStaleDaemon(health: HealthResponse, expected: { version?: string; build?: string }): boolean {
  return daemonOwnership(health, expected) === "restart";
}

function sleep(ms: number): Promise<void> {
  return new Promise((r) => setTimeout(r, ms));
}

function isProcessAlive(pid: number): boolean {
  try {
    process.kill(pid, 0);
    return true;
  } catch {
    return false;
  }
}

function cleanStalePid(pidFilePath: string): void {
  try {
    if (existsSync(pidFilePath)) unlinkSync(pidFilePath);
  } catch { /* ignore */ }
}

// A marker older than this is treated as stale even when its pid looks alive: the OS can
// reuse a pid, and `registerDaemonActivity` markers are released well before an hour on
// every real path, so nothing legitimate ever needs to survive this long.
const MARKER_MAX_AGE_MS = 60 * 60 * 1000;

// A registered marker is refreshed well inside MARKER_MAX_AGE_MS, so an operation with no
// bound of its own — a long batchCompact or importSessions — cannot be aged out while it runs.
const MARKER_REFRESH_MS = MARKER_MAX_AGE_MS / 4;

/** Markers live in tmp, not the storage root, so the root holds only durable files and a
 * sandboxed test home cannot see another root's markers via the shared system /tmp. */
function markersDir(pidFilePath: string): string {
  return join(dirname(pidFilePath), "tmp");
}

/** Where versions before the tmp move wrote their markers. Still swept, never written to, so
 * an upgrade neither leaks the files left there nor loses sight of a live old-version marker.
 * Those writers never refresh, which is why ownership is decided by the owner's lifetime
 * rather than by the marker's age. */
function legacyMarkersDir(pidFilePath: string): string {
  return dirname(pidFilePath);
}

/** Best-effort: delete `path` when its owning `pid` is dead or the marker outlived
 * MARKER_MAX_AGE_MS. Returns true when the marker is kept. Never throws — a marker
 * already removed by another process, or genuinely live and young, is left untouched. */
/**
 * Seconds the process has been running, via `ps -o etime=`. Undefined when unknown.
 *
 * This is the pid-reuse test that does not need the owner to refresh anything: a marker
 * older than its owner's own lifetime was written by a different process that happened to
 * hold the same pid.
 */
function processElapsedSeconds(pid: number): number | undefined {
  try {
    const out = spawnSync("ps", ["-o", "etime=", "-p", String(pid)], { encoding: "utf-8" });
    const raw = String(out.stdout ?? "").trim();
    // [[dd-]hh:]mm:ss
    const match = /^(?:(\d+)-)?(?:(\d+):)?(\d+):(\d+)$/.exec(raw);
    if (!match) return undefined;
    const [, days, hours, minutes, seconds] = match;
    return Number(days ?? 0) * 86_400 + Number(hours ?? 0) * 3_600 + Number(minutes) * 60 + Number(seconds);
  } catch {
    return undefined;
  }
}

/**
 * True when this marker's live pid still owns it.
 *
 * The question age was standing in for is "did this pid get recycled since the marker was
 * written", and the process's own elapsed time answers it directly: a marker older than its
 * owner's lifetime was written by someone else. Where `ps` cannot say, the one-hour cutoff
 * is the fallback it always was — which is also why a registration refreshes its marker.
 */
function markerStillOwned(path: string, pid: number): boolean {
  const writtenMsAgo = Date.now() - statSync(path).mtimeMs;
  const elapsed = processElapsedSeconds(pid);
  if (elapsed === undefined) return writtenMsAgo <= MARKER_MAX_AGE_MS;
  return writtenMsAgo <= (elapsed + 60) * 1000; // a minute of slack for clock skew
}

function pruneMarker(path: string, pid: number): boolean {
  try {
    if (isProcessAlive(pid) && markerStillOwned(path, pid)) return true;
    unlinkSync(path);
  } catch {
    // Already gone, racing another pruner, or unreadable. Only the first of those means
    // the marker is not there any more, and this cannot tell them apart: keep a live pid's
    // entry, so a stop that is waiting on it does not stop waiting on a guess.
    return isProcessAlive(pid);
  }
  return false;
}

/** List every startup marker in `directory`, pruning the abandoned ones along the way. */
function sweepMarkers(directory: string): { pid: number; path: string }[] {
  let names: string[];
  try { names = readdirSync(directory); } catch (error) {
    if ((error as NodeJS.ErrnoException).code === "ENOENT") return [];
    throw error;
  }
  const entries: { pid: number; path: string }[] = [];
  for (const name of names) {
    const match = /^daemon\.starting\.(\d+)\.[0-9a-f-]+$/.exec(name);
    const pid = Number(match?.[1]);
    if (!Number.isSafeInteger(pid) || pid <= 0) continue;
    const path = join(directory, name);
    if (pruneMarker(path, pid)) entries.push({ pid, path });
  }
  return entries;
}

/** Register before checking a hold; release only after startup or local database work settles. */
export function registerDaemonActivity(pidFilePath: string): () => void {
  const directory = markersDir(pidFilePath);
  mkdirSync(directory, { recursive: true });
  startingDaemons(pidFilePath, true); // prune dead markers left by a crashed process before adding ours
  const path = join(directory, `daemon.starting.${process.pid}.${randomUUID()}`);
  writeFileSync(path, "", { flag: "wx" });
  const refresh = setInterval(() => {
    try { utimesSync(path, new Date(), new Date()); } catch { /* removed by stop */ }
  }, MARKER_REFRESH_MS);
  refresh.unref();
  return () => {
    clearInterval(refresh);
    try { unlinkSync(path); } catch { /* already removed by stop */ }
  };
}

/**
 * Every startup marker across both directories, dead and aged-out ones pruned on the way.
 *
 * `failOpen` is the difference between the two callers, and it is not a convenience. The
 * registration sweep is opportunistic housekeeping: an unreadable directory there must not
 * stop a caller from writing its own marker, so it is reported and skipped. `stopDaemon`
 * reads the same markers to decide whether work is in flight, and an unreadable directory
 * tells it nothing — answering "none" would let it stop a daemon mid-write. That path fails
 * closed and propagates.
 */
function startingDaemons(pidFilePath: string, failOpen = false): { pid: number; path: string }[] {
  const legacy = legacyMarkersDir(pidFilePath);
  const entries: { pid: number; path: string }[] = [];
  for (const directory of [markersDir(pidFilePath), legacy]) {
    try {
      entries.push(...sweepMarkers(directory));
    } catch (error) {
      if (!failOpen) throw error;
      console.error(`[lcm] could not scan daemon markers in ${directory}: ${error instanceof Error ? error.message : String(error)}`);
    }
  }
  return entries;
}

/** PID of the process listening on 127.0.0.1:port, via lsof (macOS/Linux). Undefined when unknown. */
export function findListenerPid(port: number): number | undefined {
  try {
    const out = spawnSync("lsof", ["-nP", "-tiTCP@127.0.0.1:" + port, "-sTCP:LISTEN"], { encoding: "utf-8" });
    const first = String(out.stdout ?? "").trim().split("\n")[0];
    const pid = parseInt(first, 10);
    return Number.isNaN(pid) ? undefined : pid;
  } catch {
    return undefined;
  }
}

/** The command line of `pid`, via `ps -o command=`. Undefined when unknown or not running. */
function processCommand(pid: number): string | undefined {
  try {
    const out = spawnSync("ps", ["-o", "command=", "-p", String(pid)], { encoding: "utf-8" });
    return String(out.stdout ?? "").trim() || undefined;
  } catch {
    return undefined;
  }
}

/** True when `command` runs lcm's entry point (`lcm`, `lcm.js`, `lcm.ts`, …) as `daemon start`. */
export function isLcmDaemonCommand(command: string): boolean {
  return /(?:^|[\s/\\])lcm(?:\.[cm]?[jt]s)?\s+daemon\s+start(?:\s|$)/.test(command);
}

/** Who holds a port the daemon could not bind or reach. */
export type PortHolder = { pid?: number; lcm: boolean };

export type PortHolderProbe = {
  listenerPid: (port: number) => number | undefined;
  command: (pid: number) => string | undefined;
};

/**
 * Identify the process listening on `port`: an lcm daemon when it is the pid the pid file
 * records, or when its command line is lcm's `daemon start`; anything else is foreign.
 *
 * The command line is what identifies a daemon whose pid file is gone: a spawner that finds a
 * recorded daemon alive but unanswering deletes the pid file before it spawns a replacement.
 */
export function identifyPortHolder(
  port: number,
  pidFilePath: string,
  probe: PortHolderProbe = { listenerPid: findListenerPid, command: processCommand },
): PortHolder {
  let recorded: number | undefined;
  try {
    const parsed = parseInt(readFileSync(pidFilePath, "utf-8").trim(), 10);
    if (!isNaN(parsed)) recorded = parsed;
  } catch { /* missing */ }
  const listener = probe.listenerPid(port);
  const pid = listener ?? recorded;
  if (pid === undefined) return { lcm: false };
  if (listener !== undefined && listener === recorded) return { pid, lcm: true };
  const command = probe.command(pid);
  return { pid, lcm: command !== undefined && isLcmDaemonCommand(command) };
}

/** Why a daemon could not take `port`, for the holder `identifyPortHolder` found. */
export function describePortHolder(
  port: number,
  holder: PortHolder,
  paths: { configPath: string; logsDir: string },
): string {
  if (holder.lcm) {
    const pid = holder.pid ?? "?";
    // "Starting" covers a concurrent start that won the listen race and has not answered yet.
    return `Port ${port} is already in use by an lcm daemon (pid ${pid}) that did not answer: it is starting, busy or stuck.`
      + ` Check ${join(paths.logsDir, "daemon.log")}; to replace it, end pid ${pid} and run: lcm daemon start`;
  }
  return `Port ${port} is already in use by another process (not an lcm daemon). Stop it or change daemon.port in ${paths.configPath}.`;
}

/** Why a detached start failed when no process could be found on `port`. */
export function describeUnansweredDaemon(port: number, logsDir: string): string {
  return `lcm daemon did not answer on port ${port} within 10s — check ${join(logsDir, "daemon.log")} and ${join(logsDir, "daemon.stderr")}`;
}

/** Connect-only callers get one short probe without a spawn budget. */
export const HEALTH_PROBE_TIMEOUT_MS = 500;
/** Standalone CLI health checks wait out ordinary daemon work, but remain bounded. */
export const DEFAULT_HEALTH_TIMEOUT_MS = 5_000;

type HealthProbe = { health: HealthResponse | null; notAnswering: boolean };

async function probeDaemonHealth(
  port: number,
  fetchFn: typeof globalThis.fetch,
  timeoutMs: number,
): Promise<HealthProbe> {
  const controller = new AbortController();
  let timer: ReturnType<typeof setTimeout>;
  try {
    return await Promise.race([
      (async (): Promise<HealthProbe> => {
        try {
          const res = await fetchFn(`http://127.0.0.1:${port}/health`, { signal: controller.signal });
          if (!res.ok) return { health: null, notAnswering: true };
          return { health: (await res.json()) as HealthResponse, notAnswering: false };
        } catch {
          return { health: null, notAnswering: false };
        }
      })(),
      new Promise<HealthProbe>((resolve) => {
        timer = setTimeout(() => {
          resolve({ health: null, notAnswering: true });
          controller.abort();
        }, Math.max(0, timeoutMs));
      }),
    ]);
  } finally {
    clearTimeout(timer!);
  }
}

export async function checkDaemonHealth(
  port: number,
  fetchFn: typeof globalThis.fetch = globalThis.fetch,
  timeoutMs = DEFAULT_HEALTH_TIMEOUT_MS,
): Promise<HealthResponse | null> {
  return (await probeDaemonHealth(port, fetchFn, timeoutMs)).health;
}

const DAEMON_STDERR_MAX_BYTES = 10 * 1024 * 1024;

/**
 * `<lcm home>/logs/daemon.stderr`, opened for append, for what the daemon prints
 * before its log exists or outside it (a crash at module load). Kept across
 * spawns so the previous failure survives the respawn; past 10 MB it is moved
 * to `daemon.stderr.1`, replacing the one before. Undefined when it cannot be
 * opened: the daemon then starts with stderr ignored, as before.
 */
function openDaemonStderr(pidFilePath: string): number | undefined {
  const path = join(dirname(pidFilePath), "logs", "daemon.stderr");
  try {
    mkdirSync(dirname(path), { recursive: true });
    if (existsSync(path) && statSync(path).size > DAEMON_STDERR_MAX_BYTES) renameSync(path, `${path}.1`);
    return openSync(path, "a");
  } catch {
    return undefined; // start without it rather than not at all
  }
}

export async function ensureDaemon(opts: EnsureDaemonOptions): Promise<EnsureDaemonResult> {
  const fetchFn = opts._fetchOverride ?? globalThis.fetch;
  // Connect-only callers pass a zero spawn budget, but still get one short probe.
  const deadline = Date.now() + (opts.noSpawn ? HEALTH_PROBE_TIMEOUT_MS : opts.spawnTimeoutMs);
  const remaining = () => Math.max(0, deadline - Date.now());
  const pause = (ms: number) => sleep(Math.min(ms, remaining()));
  const unavailable = (unresponsive = false): EnsureDaemonResult => ({
    connected: false, port: opts.port, spawned: false, ...(unresponsive ? { unresponsive: true } : {}),
  });

  // Step 0: A hold means someone claimed an offline window. Report not connected
  // without touching the daemon at all — every caller already degrades to a
  // no-op when it cannot connect, which is exactly the behaviour a hold wants.
  if (readHold(opts.pidFilePath)) {
    return { connected: false, port: opts.port, spawned: false };
  }

  // Step 1: Check if daemon is already running via health check
  if (!remaining()) return unavailable();
  const probe = await probeDaemonHealth(opts.port, fetchFn, remaining());
  if (probe.notAnswering) return unavailable(true);
  if (!remaining()) return unavailable();
  const health = probe.health;
  if (health?.status === "ok") {
    const ownership = daemonOwnership(health, { version: opts.expectedVersion, build: opts.expectedBuild });
    if (ownership === "incompatible") {
      return { connected: false, port: opts.port, spawned: false, ownership, daemonVersion: health.version };
    }
    // Version/build check — if the caller is newer, kill and respawn. A caller that
    // may not spawn (SessionEnd) must not kill either: it uses an older daemon that is
    // still compatible, and leaves the replacement to the next hook that may spawn.
    if (ownership === "restart" && (opts.noSpawn || opts._skipSpawn)) {
      const connected = Boolean(opts.noSpawn) && isCompatibleVersion(health.version, opts.expectedVersion);
      return { connected, port: opts.port, spawned: false, ownership, daemonVersion: health.version };
    }
    if (ownership === "restart") {
      // Prefer the pid the daemon reports about itself; the PID file may have drifted.
      let pid = health.pid;
      if (pid === undefined && existsSync(opts.pidFilePath)) {
        try {
          const parsed = parseInt(readFileSync(opts.pidFilePath, "utf-8").trim(), 10);
          if (!isNaN(parsed)) pid = parsed;
        } catch { /* ignore */ }
      }
      if (pid !== undefined && pid !== process.pid && isProcessAlive(pid)) {
        try {
          process.kill(pid, "SIGTERM");
          await pause(500);
        } catch { /* ignore */ }
      }
      if (!remaining()) return unavailable();
      cleanStalePid(opts.pidFilePath);
      // Fall through to spawn
    } else {
      return { connected: true, port: opts.port, spawned: false, ownership, daemonVersion: health.version };
    }
  }

  // A caller that may not spawn wants only a daemon that answers now: no waiting for one
  // that is still starting (Codex caps its short-deadline hooks at three seconds).
  if (opts.noSpawn) {
    return { connected: false, port: opts.port, spawned: false };
  }

  // Step 2: Check PID file for stale process
  if (existsSync(opts.pidFilePath)) {
    try {
      const pid = parseInt(readFileSync(opts.pidFilePath, "utf-8").trim(), 10);
      if (!isNaN(pid) && isProcessAlive(pid)) {
        await pause(1000);
        if (!remaining()) return unavailable();
        const retryProbe = await probeDaemonHealth(opts.port, fetchFn, remaining());
        if (retryProbe.notAnswering) return unavailable(true);
        if (!remaining()) return unavailable();
        const retry = retryProbe.health;
        if (retry?.status === "ok") {
          // Same verdict as the first probe: a daemon that was still publishing its PID
          // must not slip past the ownership check. An older one is replaced below.
          const ownership = daemonOwnership(retry, { version: opts.expectedVersion, build: opts.expectedBuild });
          if (ownership !== "restart" || opts.noSpawn || opts._skipSpawn) {
            const connected = ownership !== "incompatible" && ownership !== "restart";
            return { connected, port: opts.port, spawned: false, ownership, daemonVersion: retry.version };
          }
          // Signal the pid the daemon reports about itself, not the one read before the wait.
          const running = retry.pid ?? pid;
          if (running !== process.pid) {
            try { process.kill(running, "SIGTERM"); await pause(500); } catch { /* fall through to spawn */ }
          }
          if (!remaining()) return unavailable();
          cleanStalePid(opts.pidFilePath);
        }
      }
    } catch { /* ignore */ }
    cleanStalePid(opts.pidFilePath);
  }

  // Step 3: Spawn daemon (unless skipped for testing)
  if (!remaining() || opts._skipSpawn || opts.noSpawn || readHold(opts.pidFilePath)) {
    return { connected: false, port: opts.port, spawned: false };
  }

  // Ensure auth token exists before spawning
  const tokenPath = join(dirname(opts.pidFilePath), "daemon.token");
  ensureAuthToken(tokenPath);

  const spawnCommand = opts.spawnCommand ?? process.execPath;
  const sourceLoaderArgs: string[] = [];
  if (!opts.spawnArgs && spawnCommand === process.execPath && /\.(?:[cm]?ts|tsx)$/.test(process.argv[1] ?? "")) {
    // Source entrypoints need the active TS loader, but debugger/eval flags
    // belong to the caller and must not be inherited by a detached daemon.
    for (let i = 0; i < process.execArgv.length; i++) {
      const arg = process.execArgv[i];
      if (/^(?:--import|--loader|--experimental-loader|--require)=/.test(arg)) {
        sourceLoaderArgs.push(arg);
      } else if (["--import", "--loader", "--experimental-loader", "--require", "-r"].includes(arg)
          && process.execArgv[i + 1] !== undefined) {
        sourceLoaderArgs.push(arg, process.execArgv[++i]);
      }
    }
  }
  const spawnArgs = opts.spawnArgs ?? [...sourceLoaderArgs, process.argv[1], "daemon", "start", "--automatic"];
  const spawnImpl = opts._spawnOverride ?? spawn;
  const stderrFd = openDaemonStderr(opts.pidFilePath);
  let child: ChildProcess;
  try {
    child = spawnImpl(spawnCommand, spawnArgs, {
      detached: true,
      stdio: ["ignore", "ignore", stderrFd ?? "ignore"],
      env: { ...process.env },
    }) as ChildProcess;
  } finally {
    // The child holds its own copy of the descriptor.
    if (stderrFd !== undefined) closeSync(stderrFd);
  }
  child.unref();

  // The child registers itself before checking holds and publishes daemon.pid
  // only after listening. A late parent write could overwrite the winning PID.

  if (opts._skipHealthWait) {
    return { connected: false, port: opts.port, spawned: true };
  }

  // Step 4: Wait for health — only connect if version matches (if expected)
  while (remaining()) {
    const waiting = await probeDaemonHealth(opts.port, fetchFn, remaining());
    if (!remaining()) break;
    const h = waiting.health;
    if (h?.status === "ok") {
      if (isStaleDaemon(h, { version: opts.expectedVersion, build: opts.expectedBuild })) {
        await pause(300);
        continue;
      }
      return { connected: true, port: opts.port, spawned: true };
    }
    await pause(300);
  }

  return { connected: false, port: opts.port, spawned: true };
}

/**
 * Stop the daemon recorded in the PID file. Resolves true when the daemon is
 * confirmed down, false when it is still up or a listener has not answered by
 * the timeout. A health timeout never establishes that the listener is gone.
 */
export async function stopDaemon(opts: {
  port: number;
  pidFilePath: string;
  timeoutMs?: number;
  _fetchOverride?: typeof globalThis.fetch;
}): Promise<{ stopped: boolean; pid?: number }> {
  const fetchFn = opts._fetchOverride ?? globalThis.fetch;
  const deadline = Date.now() + (opts.timeoutMs ?? 5000);
  const remaining = () => Math.max(0, deadline - Date.now());
  // Read startup registrations before daemon.pid: a child hands off by writing
  // daemon.pid before removing its registration, so neither state can be missed.
  // A child registering after this snapshot sees the hold published by the caller.
  const starting = startingDaemons(opts.pidFilePath);
  let pid: number | undefined;
  if (existsSync(opts.pidFilePath)) {
    try {
      const parsed = parseInt(readFileSync(opts.pidFilePath, "utf-8").trim(), 10);
      if (!isNaN(parsed)) pid = parsed;
    } catch { /* ignore */ }
  }
  if (pid === undefined || !isProcessAlive(pid)) {
    const probe = await probeDaemonHealth(opts.port, fetchFn, remaining());
    // A busy daemon and older builds may report no pid; use the port's listener.
    pid = probe.health?.pid ?? ((probe.health || probe.notAnswering) ? findListenerPid(opts.port) : undefined) ?? pid;
  }
  if (pid !== undefined && isProcessAlive(pid)) {
    try { process.kill(pid, "SIGTERM"); } catch { /* checked below */ }
  }
  while (remaining()) {
    // Startup registrations are only waited on, never signalled: a stale
    // registration could refer to a PID the OS has since reused.
    const startingAlive = starting.some((entry) => existsSync(entry.path) && isProcessAlive(entry.pid));
    const alive = (pid !== undefined && isProcessAlive(pid)) || startingAlive;
    const probe = await probeDaemonHealth(opts.port, fetchFn, remaining());
    const health = probe.health;
    // A registered child may have handed off after our initial PID read.
    if (health?.pid !== undefined && health.pid !== pid) {
      pid = health.pid;
      try { process.kill(pid, "SIGTERM"); } catch { /* checked on the next iteration */ }
    }
    if (!alive && !health && !probe.notAnswering) {
      cleanStalePid(opts.pidFilePath);
      for (const entry of starting) {
        try { unlinkSync(entry.path); } catch { /* child already removed it */ }
      }
      return { stopped: true, pid };
    }
    await sleep(Math.min(200, remaining()));
  }
  return { stopped: false, pid };
}
