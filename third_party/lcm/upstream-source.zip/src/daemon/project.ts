import { createHash } from "node:crypto";
import { existsSync, lstatSync, mkdirSync, readdirSync, realpathSync } from "node:fs";
import { homedir } from "node:os";
import { join, resolve, normalize, join as pathJoin, dirname, basename } from "node:path";
import type { LcmPaths } from "../lcm-paths.js";
import type { SessionClient } from "../session-client.js";

function canonicalizeCwd(cwd: string): string {
  try { return realpathSync(cwd); } catch { return cwd; }
}

export const projectId = (cwd: string): string =>
  createHash("sha256").update(canonicalizeCwd(cwd)).digest("hex");

export const projectDir = (cwd: string, paths: LcmPaths): string =>
  join(paths.projectsDir, projectId(cwd));

export const projectDbPath = (cwd: string, paths: LcmPaths): string =>
  join(projectDir(cwd, paths), "db.sqlite");

export const projectMetaPath = (cwd: string, paths: LcmPaths): string =>
  join(projectDir(cwd, paths), "meta.json");

/**
 * Claude Code's project-directory name under ~/.claude/projects/: the cwd with
 * every non-alphanumeric character replaced by "-", keeping the leading dash
 * (e.g. /Users/me/.agents → -Users-me--agents). The one owner of that convention;
 * every reader of ~/.claude/projects/ goes through this.
 */
export function claudeProjectSlug(cwd: string): string {
  return cwd.replace(/[^A-Za-z0-9]/g, "-");
}

/**
 * Where Claude Code writes a session's transcript:
 * ~/.claude/projects/<claudeProjectSlug(cwd)>/<session_id>.jsonl. Used when a caller
 * knows the session but not the file (the function-hooks module has `$.session.id()`
 * and `$.session.cwd()`, not `transcript_path`). Returns null for a session id that
 * is not a plain file name.
 */
/** The harness-owned Claude transcript directory, shared by discovery and capture. */
export function claudeTranscriptDirectory(cwd: string): string {
  return join(homedir(), ".claude", "projects", claudeProjectSlug(cwd));
}

export function claudeTranscriptPath(cwd: string, sessionId: string): string | null {
  if (!/^[A-Za-z0-9_-]+$/.test(sessionId)) return null;
  return join(claudeTranscriptDirectory(cwd), `${sessionId}.jsonl`);
}

function tryRealpath(p: string): string {
  try { return realpathSync(p); } catch { return p; }
}

/**
 * Like realpathSync but handles non-existent paths by resolving the nearest
 * existing ancestor and appending the remaining components.
 * This ensures symlinked parent directories are resolved even when the leaf
 * path doesn't exist yet (e.g. a transcript file not yet created).
 */
export function realpathDeep(p: string): string {
  try { return realpathSync(p); } catch { /* fall through */ }
  // Walk up to find the nearest existing ancestor, then reconstruct
  const parts: string[] = [];
  let cur = p;
  while (true) {
    const parent = dirname(cur);
    if (parent === cur) break; // reached root
    parts.unshift(basename(cur));
    cur = parent;
    try {
      const real = realpathSync(cur);
      return join(real, ...parts);
    } catch { /* keep walking up */ }
  }
  return p; // fallback: return original
}

/**
 * Every OMP agent directory whose sessions lcm will read: the active one
 * (PI_CODING_AGENT_DIR, else the default) plus each named profile's, because
 * `omp --profile <name>` relocates sessions to
 * `~/.omp/profiles/<name>/agent/sessions` and a hook installed there reports
 * paths lcm would otherwise refuse — silently, since capture is best-effort.
 *
 * `lcm import`'s OMP discovery (`ompDiscoveryRoots` / `findAllOmpTranscripts`
 * in `../omp-transcript.js`) enumerates the same roots, minus any profile
 * reached through a symlink, so a profile session that captures live is also
 * backfilled.
 */
export function ompSessionRoots(): string[] {
  const home = homedir();
  const roots = [process.env.PI_CODING_AGENT_DIR || pathJoin(home, ".omp", "agent")];
  const profilesDir = pathJoin(home, ".omp", "profiles");
  try {
    for (const entry of readdirSync(profilesDir)) roots.push(pathJoin(profilesDir, entry, "agent"));
  } catch { /* no profiles directory: the default root is the whole list */ }
  return roots.map(root => pathJoin(root, "sessions"));
}

export function isSafeTranscriptPath(transcriptPath: string, cwd: string, client: SessionClient = "claude"): string | false {
  const resolved = resolve(transcriptPath);
  const transcriptBases = client === "codex"
    ? [pathJoin(homedir(), ".codex", "sessions"), pathJoin(homedir(), ".codex", "archived_sessions")]
    : client === "omp"
      ? ompSessionRoots()
      : [pathJoin(homedir(), ".claude", "projects")];

  // Check for symlinks: if the resolved path is a symlink, follow it and re-validate.
  let lstat: ReturnType<typeof lstatSync> | null = null;
  try { lstat = lstatSync(resolved); } catch { /* file doesn't exist */ }

  if (lstat?.isSymbolicLink()) {
    // Follow symlink to real path and re-validate against allowed bases
    let real: string;
    try { real = realpathSync(resolved); } catch { return false; }
    const allowedBases = [
      ...transcriptBases.map(tryRealpath),
      tryRealpath(resolve(cwd)),
    ];
    for (const base of allowedBases) {
      const normalBase = normalize(base + "/");
      if (real.startsWith(normalBase) || real === normalize(base)) {
        return real;
      }
    }
    return false;
  }

  // Not a symlink (or doesn't exist yet): validate using resolve() — consistent with cwd.
  // Canonicalize both the candidate path and the allowed bases via realpathSync so that
  // a symlinked parent directory (e.g. /tmp -> /private/tmp on macOS) doesn't create
  // a bypass in either direction.
  // Use realpathDeep so non-existent leaf paths still get their parent directories
  // resolved (e.g. /tmp/transcript.jsonl -> /private/tmp/transcript.jsonl on macOS).
  const candidate = realpathDeep(resolved);
  const allowedBases = [
    ...transcriptBases.map(tryRealpath),
    tryRealpath(resolve(cwd)),
  ];
  for (const base of allowedBases) {
    const normalBase = normalize(base + "/");
    if (candidate.startsWith(normalBase) || candidate === normalize(base)) {
      return candidate;
    }
  }
  return false;
}

/**
 * Ensures the project dir exists. The project's record (`meta.json`) is owned by
 * `project-meta.ts`, which this module must not import: it would form a cycle
 * through `projectMetaPath`, and a test that mocks this module would then see
 * the record written somewhere else. `openProject` records `cwd`.
 */
export const ensureProjectDir = (cwd: string, paths: LcmPaths): string => {
  const dir = projectDir(cwd, paths);
  mkdirSync(dir, { recursive: true });
  return dir;
};
