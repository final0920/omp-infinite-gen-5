import { existsSync } from "node:fs";
import { openStandaloneLcmConnection } from "../../db/connection.js";
import type { DaemonConfig } from "../config.js";
import type { LcmPaths } from "../../lcm-paths.js";
import { projectDbPath } from "../project.js";
import { sendJson } from "../server.js";
import type { RouteHandler } from "../server.js";
import { runLcmMigrations } from "../../db/migration.js";
import { ConversationStore } from "../../store/conversation-store.js";
import { SummaryStore } from "../../store/summary-store.js";
import { RetrievalEngine } from "../../retrieval.js";
import { validateCwd } from "../validate-cwd.js";
import { extractQueryTerms, languageList } from "../../store/fts5-query.js";
import { projectAuthorLanguage } from "../../search/pivot-language.js";

export function createGrepHandler(_config: DaemonConfig, paths: LcmPaths): RouteHandler {
  return async (_req, res, body) => {
    const input = JSON.parse(body || "{}");
    const { query, scope, mode, since } = input;

    if (!query) {
      sendJson(res, 400, { error: "query is required" });
      return;
    }

    if (!input.cwd) {
      sendJson(res, 200, { matches: [] });
      return;
    }

    let cwd: string;
    try {
      cwd = validateCwd(input.cwd);
    } catch {
      sendJson(res, 200, { matches: [] });
      return;
    }

    try {
      const dbPath = projectDbPath(cwd, paths);
      if (!existsSync(dbPath)) {
        sendJson(res, 200, { matches: [] });
        return;
      }
      const db = openStandaloneLcmConnection(dbPath);
      try {
        runLcmMigrations(db);
        const convStore = new ConversationStore(db);
        const summStore = new SummaryStore(db);
        const engine = new RetrievalEngine(convStore, summStore);
        const searchMode = mode ?? "full_text";
        const result = await engine.grep({
          query,
          mode: searchMode,
          scope: scope ?? "both",
          summaryId: input.summary_id,
          conversationId: input.sessionId ? (await convStore.getConversationBySessionId(input.sessionId))?.conversationId ?? -1 : undefined,
          since: since ? new Date(since) : undefined,
          terms: searchMode === "full_text" ? extractQueryTerms(query, paths, languageList(projectAuthorLanguage(cwd, paths))) : undefined,
        });
        sendJson(res, 200, result);
      } finally { db.close(); }
    } catch (err) {
      sendJson(res, 200, { matches: [] });
    }
  };
}
