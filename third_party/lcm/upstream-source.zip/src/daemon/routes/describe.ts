import { existsSync } from "node:fs";
import { openStandaloneLcmConnection } from "../../db/connection.js";
import type { DaemonConfig } from "../config.js";
import type { LcmPaths } from "../../lcm-paths.js";
import { projectDbPath } from "../project.js";
import { sendJson } from "../server.js";
import type { RouteHandler } from "../server.js";
import { runLcmMigrations } from "../../db/migration.js";
import { ConversationStore } from "../../store/conversation-store.js";
import { SummaryStore } from "../../store/summary-store.js";
import { RetrievalEngine } from "../../retrieval.js";
import { validateCwd } from "../validate-cwd.js";
import { resolveSourceCwd } from "../project-group.js";
import { daemonTimeline } from "../project-timeline.js";

export function createDescribeHandler(config: DaemonConfig, paths: LcmPaths): RouteHandler {
  return async (_req, res, body) => {
    const input = JSON.parse(body || "{}");
    const { nodeId } = input;

    if (!nodeId) {
      sendJson(res, 400, { error: "nodeId is required" });
      return;
    }

    let cwd: string | undefined;
    if (input.cwd) {
      try {
        cwd = validateCwd(input.cwd);
      } catch {
        sendJson(res, 200, { node: null });
        return;
      }
    }

    if (!cwd || !existsSync(projectDbPath(cwd, paths))) {
      sendJson(res, 200, { node: null });
      return;
    }

    // Ids are AUTOINCREMENT per database, so a node named by a search result
    // must be read from the project that result came from.
    const source = resolveSourceCwd(cwd, input.projectId, paths);
    if (!source) {
      sendJson(res, 200, { node: null, error: "project not in group" });
      return;
    }

    try {
      const dbPath = projectDbPath(source, paths);
      const db = openStandaloneLcmConnection(dbPath);
      try {
        runLcmMigrations(db);
        const convStore = new ConversationStore(db);
        const summStore = new SummaryStore(db);
        const engine = new RetrievalEngine(convStore, summStore);
        const result = await engine.describe(nodeId);
        const timeline = daemonTimeline(db, source, config, paths).describe(nodeId);
        sendJson(res, 200, { node: result && timeline ? { ...result, timeline } : result });
      } finally { db.close(); }
    } catch (err) {
      sendJson(res, 200, { node: null, error: err instanceof Error ? err.message : "describe failed" });
    }
  };
}
