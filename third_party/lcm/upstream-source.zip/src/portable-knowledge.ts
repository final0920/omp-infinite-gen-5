/**
 * Portable knowledge: export and import promoted memory entries.
 *
 * Export format:
 *   {
 *     version: 1,
 *     exportedAt: "<ISO string>",
 *     projectCwd: "<string>",
 *     entries: [{ content, tags, confidence, createdAt, sessionId }]
 *   }
 *
 * Secrets are scrubbed on export via ScrubEngine.
 * Deduplication is performed on import via deduplicateAndInsert().
 */

import { existsSync, writeFileSync } from "node:fs";
import { join } from "node:path";
import { createHash } from "node:crypto";
import { realpathSync } from "node:fs";

import { PromotedStore } from "./db/promoted.js";
import { decodeLegacyTags } from "./db/votes.js";
import { runLcmMigrations } from "./db/migration.js";
import { deduplicateAndInsert } from "./promotion/dedup.js";
import { ScrubEngine } from "./scrub.js";
import { loadDaemonConfig } from "./daemon/config.js";
import { getLcmConnection, closeLcmConnection } from "./db/connection.js";
import type { LcmPaths } from "./lcm-paths.js";
import { updateProjectMetaIn } from "./daemon/project-meta.js";

export const EXPORT_VERSION = 1;

export interface ExportEntry {
  content: string;
  tags: string[];
  confidence: number;
  createdAt: string;
  sessionId: string | null;
}

export interface ExportDocument {
  version: number;
  exportedAt: string;
  projectCwd: string;
  entries: ExportEntry[];
}

// ─── Internal helpers (accept optional baseDir for testing) ──────────────────

function canonicalizeCwd(cwd: string): string {
  try { return realpathSync(cwd); } catch { return cwd; }
}

function resolveProjectId(cwd: string): string {
  return createHash("sha256").update(canonicalizeCwd(cwd)).digest("hex");
}

function resolveProjectDir(cwd: string, baseDir: string): string {
  return join(baseDir, "projects", resolveProjectId(cwd));
}

function resolveProjectDbPath(cwd: string, baseDir: string): string {
  return join(resolveProjectDir(cwd, baseDir), "db.sqlite");
}

// ─── Export ──────────────────────────────────────────────────────────────────

export interface ExportOptions {
  /** Only include entries with these tags */
  tags?: string[];
  /** Only include entries created at or after this ISO date string */
  since?: string;
  /** Output file path (stdout if omitted) */
  output?: string;
  /** Output format — only "json" supported for now */
  format?: "json";
  /** Skip scrubbing secrets (not recommended; useful for tests) */
  skipScrub?: boolean;
  /** Explicit storage root used by older library callers. */
  _lcmBaseDir?: string;
}

export interface ExportResult {
  exported: number;
  projectCwd: string;
}

export async function exportKnowledge(
  cwd: string,
  pathsOrOptions: LcmPaths | ExportOptions,
  injectedOptions: ExportOptions = {},
): Promise<ExportResult> {
  const opts = "home" in pathsOrOptions ? injectedOptions : pathsOrOptions;
  const baseDir = "home" in pathsOrOptions ? pathsOrOptions.home : opts._lcmBaseDir;
  if (!baseDir) throw new Error("exportKnowledge requires an LcmPaths storage root");
  const dbPath = resolveProjectDbPath(cwd, baseDir);

  if (!existsSync(dbPath)) {
    throw new Error(`No lossless-claude database found for project: ${cwd}`);
  }

  const db = getLcmConnection(dbPath);
  let entries: ExportEntry[];
  try {
    runLcmMigrations(db);

    const store = new PromotedStore(db);
    const projId = resolveProjectId(cwd);

    const rows = store.getAll({
      projectId: projId,
      since: opts.since,
      tags: opts.tags,
    });

    // Export is an exit: scrub with every rule capture uses, including the global patterns.
    let scrubber: ScrubEngine | null = null;
    if (!opts.skipScrub) {
      const projDir = resolveProjectDir(cwd, baseDir);
      const config = loadDaemonConfig(join(baseDir, "config.json"));
      scrubber = await ScrubEngine.forProject(config.security?.sensitivePatterns ?? [], projDir);
    }

    entries = rows.map((r) => {
      let content = r.content;
      if (scrubber) {
        content = scrubber.scrub(content);
      }
      return {
        content,
        tags: JSON.parse(r.tags) as string[],
        confidence: r.confidence,
        createdAt: r.created_at,
        // sessionId is per-project and per-machine. Nullify on export so that
        // importing into a different project/machine does not create dead
        // references pointing at a session that does not exist in the new context.
        sessionId: null,
      };
    });
  } finally {
    closeLcmConnection(dbPath);
  }

  const doc: ExportDocument = {
    version: EXPORT_VERSION,
    exportedAt: new Date().toISOString(),
    projectCwd: cwd,
    entries,
  };

  const json = JSON.stringify(doc, null, 2);

  if (opts.output) {
    writeFileSync(opts.output, json, "utf-8");
  } else {
    process.stdout.write(json + "\n");
  }

  return { exported: entries.length, projectCwd: cwd };
}

// ─── Import ──────────────────────────────────────────────────────────────────

export interface ImportOptions {
  /** Merge with existing entries, deduplicating (default behaviour) */
  merge?: boolean;
  /** Preview without writing anything */
  dryRun?: boolean;
  /** Override confidence for all imported entries */
  confidence?: number;
  /** Explicit storage root used by older library callers. */
  _lcmBaseDir?: string;
}

export interface ImportResult {
  total: number;
  imported: number;
  skipped: number;
  dryRun: boolean;
  /** Error messages from entries that failed deduplication/insert. */
  errors?: string[];
}

const DEFAULT_DEDUP_THRESHOLDS = {
  dedupBm25Threshold: 15,
  dedupCandidateLimit: 100,
};

export async function importKnowledge(
  cwd: string,
  pathsOrDoc: LcmPaths | ExportDocument,
  docOrOptions: ExportDocument | ImportOptions = {},
  injectedOptions: ImportOptions = {},
): Promise<ImportResult> {
  const paths = "home" in pathsOrDoc ? pathsOrDoc : undefined;
  const doc = (paths ? docOrOptions : pathsOrDoc) as ExportDocument;
  const opts = (paths ? injectedOptions : docOrOptions) as ImportOptions;
  if (doc.version !== EXPORT_VERSION) {
    throw new Error(`Unsupported export version: ${doc.version} (expected ${EXPORT_VERSION})`);
  }

  if (opts.dryRun) {
    return {
      total: doc.entries.length,
      imported: 0,
      skipped: 0,
      dryRun: true,
    };
  }

  const baseDir = paths?.home ?? opts._lcmBaseDir;
  if (!baseDir) throw new Error("importKnowledge requires an LcmPaths storage root");
  const projDir = resolveProjectDir(cwd, baseDir);
  const dbPath = resolveProjectDbPath(cwd, baseDir);

  // Record the destination before opening its store or processing any incoming memory.
  updateProjectMetaIn(projDir, { cwd });

  const db = getLcmConnection(dbPath);

  let imported = 0;
  let skipped = 0;
  const errors: string[] = [];

  try {
    runLcmMigrations(db);

    const store = new PromotedStore(db);
    const projId = resolveProjectId(cwd);

    for (const entry of doc.entries) {
      const confidence = opts.confidence !== undefined ? opts.confidence : entry.confidence;
      try {
        // An export taken before tag normalization carries a legacy row's tags as a string.
        const tags = decodeLegacyTags(entry.tags);
        if (!tags) throw new Error("tags must be an array of strings");
        await deduplicateAndInsert({
          store,
          content: entry.content,
          tags,
          projectId: projId,
          sessionId: entry.sessionId ?? undefined,
          depth: 0,
          confidence,
          thresholds: DEFAULT_DEDUP_THRESHOLDS,
        });
        imported++;
      } catch (e) {
        skipped++;
        errors.push(e instanceof Error ? e.message : String(e));
      }
    }
  } finally {
    closeLcmConnection(dbPath);
  }

  return {
    total: doc.entries.length,
    imported,
    skipped,
    dryRun: false,
    ...(errors.length > 0 ? { errors } : {}),
  };
}
