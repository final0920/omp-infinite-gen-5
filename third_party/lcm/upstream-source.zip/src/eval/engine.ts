/**
 * Summarizer model eval harness.
 *
 * Runs the real CompactionEngine with the production configuration against a
 * session loaded into an in-memory SQLite database, records every summarizer
 * call, and scores the resulting summaries mechanically. The caller supplies
 * the candidate; all compaction writes stay in memory.
 */
import { DatabaseSync } from "node:sqlite";
import { CompactionEngine, compactEngineConfig, COMPACT_TOKEN_BUDGET } from "../compaction.js";
import { runLcmMigrations } from "../db/migration.js";
import type { LcmSummarizeFn, SummarizeContext, SummarizerUsage } from "../llm/types.js";
import { ConversationStore } from "../store/conversation-store.js";
import { SummaryStore } from "../store/summary-store.js";
import { resolveMaxOutputTokens, resolveTargetTokens } from "../summarize.js";
import { SummaryRejectedError } from "../llm/summary-rejection.js";
import { findUnsupportedDetails, type UnsupportedDetail } from "./unsupported-details.js";
import { buildSummaryPrompt } from "../llm/prompt.js";
import type { ToolOutcome } from "../tool-calls.js";
import type { ToolSummaryContext } from "../tool-summary-context.js";

// ── Corpus ─────────────────────────────────────────────────────────────────

/** Same estimate production uses for prompt sizing. */
const CHARS_PER_TOKEN = 4;

export type CorpusMessage = {
  seq: number;
  role: "user" | "assistant" | "system" | "tool";
  content: string;
  tokenCount: number;
  createdAt: string;
  /** Stored, scrubbed selected inputs; call outcomes are joined before export. */
  toolCalls?: CorpusToolCall[];
};

export type CorpusToolCall = {
  callId: string;
  name: string;
  input: string | null;
  outcome: ToolOutcome;
  blockReason?: string | null;
  truncated?: boolean;
};

export type PlantedFact = { name: string; pattern: string };

export type CorpusSession = {
  label: string;
  messages: CorpusMessage[];
  plantedFacts?: PlantedFact[];
};

// ── Synthetic session with planted facts ──────────────────────────────────

const PLANTED_FACTS: PlantedFact[] = [
  { name: "decision-with-rationale", pattern: "ristretto|allocator" },
  { name: "renamed-file", pattern: "ledger-writer\\.ts" },
  { name: "open-task", pattern: "backfill|verticality" },
  { name: "numeric-constraint", pattern: "7331" },
  { name: "user-correction", pattern: "ULID" },
];

const FILLER_TOPICS = [
  "the retry policy for the ingest queue",
  "the shape of the config loader",
  "how the daemon reports health",
  "the CLI help text layout",
  "the migration ordering rules",
  "the search index rebuild path",
  "the log rotation cadence",
  "the plugin manifest validation",
];

function fillerTurn(i: number): [string, string] {
  const topic = FILLER_TOPICS[i % FILLER_TOPICS.length];
  const user = `Let's look at ${topic}. Walk me through the current behaviour and any edge cases you see, turn ${i}.`;
  const lines: string[] = [];
  for (let j = 0; j < 40; j++) {
    lines.push(
      `Observation ${i}.${j}: ${topic} handles case ${j} by checking the input, ` +
        `normalising it, and writing the outcome to the store before returning. ` +
        `No branch here changes public behaviour; the code path is covered by unit tests.`,
    );
  }
  return [user, lines.join("\n")];
}

/**
 * A synthetic session large enough for three leaf chunks under production
 * config; a depth-1 condensation follows only when the leaf summaries are
 * verbose enough to reach the condensed minimum. The five facts are planted in
 * the first turns so they sit outside the protected fresh tail and must
 * survive summarization to appear in the final context.
 */
export function buildSyntheticSession(options: { toolFailures?: boolean } = {}): CorpusSession {
  const planted: [string, string][] = [
    [
      "Which cache library should we use for the summary lookups?",
      "Decision: use ristretto for the cache. Rationale: the allocator pressure of the LRU alternative was 3x higher in the profile.",
    ],
    [
      "Rename the writer module so its name matches what it does.",
      "Done. Renamed src/ledger/writer.ts to src/ledger/ledger-writer.ts and updated the three imports.",
    ],
    [
      "What is still open after this?",
      "Open task: backfill the verticality column for records imported before March. Not started.",
    ],
    [
      "How many rows can one batch carry?",
      "The numeric constraint is hard: a batch may carry at most 7331 rows, enforced by the schema check.",
    ],
    [
      "You wrote UUID above. That is wrong, we use ULID for record ids.",
      "Correct, my mistake. Record ids are ULID, not UUID. I updated the note.",
    ],
  ];

  const messages: CorpusMessage[] = [];
  const base = Date.parse("2026-01-01T00:00:00Z");
  let seq = 0;
  const push = (role: CorpusMessage["role"], content: string) => {
    messages.push({
      seq: seq++,
      role,
      content,
      tokenCount: Math.ceil(content.length / CHARS_PER_TOKEN),
      createdAt: new Date(base + (seq - 1) * 60_000).toISOString(),
    });
  };

  for (const [u, a] of planted) {
    push("user", u);
    push("assistant", a);
  }
  // ~73k tokens of filler: three 20k leaf chunks outside the tail, then one condensation.
  for (let i = 0; i < 30; i++) {
    const [u, a] = fillerTurn(i);
    push("user", u);
    push("assistant", a);
  }

  if (options.toolFailures) {
    messages[0].toolCalls = [{ callId: "failure", name: "Bash", input: "npm install legacy-widget", outcome: "failed" }];
    messages[1].toolCalls = [{ callId: "fix", name: "Bash", input: "npm install current-widget", outcome: "succeeded" }];
    messages[2].toolCalls = [{
      callId: "block", name: "Bash", input: "make deploy", outcome: "blocked",
      blockReason: "PreToolUse:Bash hook error: deployments are disabled",
    }];
  }
  return { label: options.toolFailures ? "synthetic-tool-failures" : "synthetic-planted", messages, plantedFacts: PLANTED_FACTS };
}

// ── Instrumented summarizer ────────────────────────────────────────────────

/** Production usage shape with the provider label widened to bench providers. */
export type EvalUsage = Omit<SummarizerUsage, "provider"> & { provider: string };

export type SummarizerAttempt = {
  provider: string;
  kind: "session" | "http" | "process";
  model?: string;
  latencyMs: number;
  usageReports: number;
  error?: string;
};

export type SummarizerCall = {
  pass: "leaf" | "condensed";
  depth: number;
  aggressive: boolean;
  inputChars: number;
  source: string;
  /** Actual request prompt, including the bounded structured evidence when present. */
  prompt?: string;
  toolContext?: ToolSummaryContext;
  /** Exact command retention is a mechanical check; paraphrases need human review. */
  toolPairRetention?: { failedCommand: string; succeededCommand: string; retained: boolean }[];
  targetTokens: number;
  outputChars: number;
  outputTokensEstimate: number;
  latencyMs: number;
  prefillMs?: number;
  decodeMs?: number;
  usages: EvalUsage[];
  /** Provider-chain attempts, including its retry after a cut-off answer. */
  attempts: SummarizerAttempt[];
  rejections: string[];
  unsupportedDetails: UnsupportedDetail[];
  output?: string;
  /** Format checks on this call's output; leaf summaries get condensed away and would otherwise go unscored. */
  format?: SummaryScore;
  usage?: EvalUsage;
  /** Legacy bench metric: the output echoes the input's first 500 characters. */
  emptyContentFallback: boolean;
  error?: string;
};

export type InstrumentedSummarizer = { summarize: LcmSummarizeFn; calls: SummarizerCall[] };

/** Wrap a summarizer so every call is recorded with the same target the summarizer computed. */
export function instrumentSummarizer(inner: LcmSummarizeFn, toolContext = true): InstrumentedSummarizer {
  const calls: SummarizerCall[] = [];
  const summarize: LcmSummarizeFn = async (text, aggressive, ctx: SummarizeContext = {}) => {
    const requestContext = toolContext ? ctx : { ...ctx, toolContext: undefined };
    const isCondensed = ctx.isCondensed ?? false;
    const targetTokens =
      ctx.targetTokens ??
      resolveTargetTokens({
        inputTokens: Math.ceil(text.length / CHARS_PER_TOKEN),
        mode: aggressive ? "aggressive" : "normal",
        isCondensed,
        condensedTargetTokens: 2000,
      });
    const call: SummarizerCall = {
      pass: isCondensed ? "condensed" : "leaf",
      depth: isCondensed ? (ctx.depth ?? 1) : 0,
      aggressive: aggressive === true,
      inputChars: text.length,
      source: text,
      prompt: buildSummaryPrompt(text, aggressive, requestContext),
      toolContext: ctx.toolContext,
      targetTokens,
      outputChars: 0,
      outputTokensEstimate: 0,
      latencyMs: 0,
      usages: [],
      attempts: [],
      rejections: [],
      unsupportedDetails: [],
      emptyContentFallback: false,
    };
    calls.push(call);
    const started = Date.now();
    let currentAttempt: SummarizerAttempt | undefined;
    let attemptStarted = started;
    const finishAttempt = (error?: string) => {
      if (!currentAttempt) return;
      currentAttempt.latencyMs = Date.now() - attemptStarted;
      currentAttempt.error = error;
      currentAttempt = undefined;
    };
    try {
      const out = await inner(text, aggressive, {
        ...requestContext,
        onAttempt: (attempt) => {
          finishAttempt();
          currentAttempt = { ...attempt, latencyMs: 0, usageReports: 0 };
          attemptStarted = Date.now();
          call.attempts.push(currentAttempt);
          ctx.onAttempt?.(attempt);
        },
        onUsage: (usage) => {
          call.usage = usage;
          call.usages.push(usage);
          if (currentAttempt) currentAttempt.usageReports++;
          if (usage.prefillMs !== undefined) call.prefillMs = (call.prefillMs ?? 0) + usage.prefillMs;
          if (usage.decodeMs !== undefined) call.decodeMs = (call.decodeMs ?? 0) + usage.decodeMs;
          ctx.onUsage?.(usage);
        },
        onFallback: (fallback) => {
          call.rejections.push(fallback.reason);
          finishAttempt(fallback.reason);
          ctx.onFallback?.(fallback);
        },
      });
      finishAttempt();
      call.latencyMs = Date.now() - started;
      call.outputChars = out.length;
      call.outputTokensEstimate = Math.ceil(out.length / CHARS_PER_TOKEN);
      call.output = out;
      call.format = scoreSummary(out, call.depth);
      const evidence = requestContext.toolContext ? `${text}\n${JSON.stringify(requestContext.toolContext)}` : text;
      call.unsupportedDetails = findUnsupportedDetails(evidence, out);
      call.toolPairRetention = ctx.toolContext?.errorFixPairs.map(pair => ({
        ...pair, retained: out.includes(pair.failedCommand) && out.includes(pair.succeededCommand),
      }));
      call.emptyContentFallback = out === text.slice(0, 500);
      return out;
    } catch (err) {
      call.latencyMs = Date.now() - started;
      call.error = err instanceof Error ? err.message : String(err);
      finishAttempt(call.error);
      if (err instanceof SummaryRejectedError) call.rejections.push(err.reason);
      throw err;
    }
  };
  return { summarize, calls };
}

// ── Scoring ────────────────────────────────────────────────────────────────

export type SummaryScore = {
  depth: number;
  chars: number;
  tokensEstimate: number;
  hasFilesLine: boolean | null;
  hasExpandTrailer: boolean;
  isFallback: boolean;
};

const EXPAND_TRAILER = "Expand for details about:";

/**
 * Format checks mirror the prompt contracts: leaf prompts require a `Files:`
 * line, every prompt requires the `Expand for details about:` trailer as the
 * last line. Leaf `hasFilesLine` is null for condensed summaries.
 */
export function scoreSummary(content: string, depth: number): SummaryScore {
  const trimmed = content.trim();
  const lastLine = trimmed.split("\n").at(-1) ?? "";
  return {
    depth,
    chars: trimmed.length,
    tokensEstimate: Math.ceil(trimmed.length / CHARS_PER_TOKEN),
    hasFilesLine: depth === 0 ? /^Files:/m.test(trimmed) : null,
    hasExpandTrailer: lastLine.startsWith(EXPAND_TRAILER),
    isFallback: /\[Truncated from \d+ tokens\]$/.test(trimmed),
  };
}

export function checkPlantedFacts(
  contextText: string,
  facts: PlantedFact[],
): { name: string; survived: boolean }[] {
  return facts.map((f) => ({ name: f.name, survived: new RegExp(f.pattern, "i").test(contextText) }));
}

// ── Run ────────────────────────────────────────────────────────────────────

export type EvalRunResult = {
  /** False only for the evaluation baseline; production always supplies window evidence. */
  toolContextEnabled: boolean;
  label: string;
  model: string;
  /** Which bench provider produced this run — the same model scores differently per provider. */
  provider: string;
  /** Reasoning/thinking knobs in effect, if any; part of the result identity. */
  variant?: string;
  /** Effective corpus language, if known; part of the result identity. */
  language?: string;
  run: number;
  startedAt: string;
  incomplete: boolean;
  error?: string;
  inputMessages: number;
  inputTokens: number;
  tokensBefore: number;
  tokensAfter: number;
  calls: SummarizerCall[];
  summaries: (SummaryScore & { summaryId: string; content: string })[];
  plantedFacts?: { name: string; survived: boolean }[];
  totals: {
    calls: number;
    failedCalls: number;
    latencyMs: number;
    inputTokens: number;
    outputTokens: number;
    /** null when any call or billed answer has no reported price. */
    costUsd: number | null;
    /** Format-passing calls over all calls that returned output. */
    formatPass: number;
    formatTotal: number;
    /** HTTP-provider calls whose output reached the production output cap: the summary was cut off. */
    maxTokensHits: number;
    rejectedCalls: number;
    unsupportedDetails: number;
    prefillMs: number | null;
    decodeMs: number | null;
  };
};



export async function runEval(input: {
  session: CorpusSession;
  summarizer: LcmSummarizeFn;
  model: string;
  provider: string;
  variant?: string;
  run: number;
  /** Effective configured or detected corpus language used by production. */
  language?: string;
  /** Evaluation baseline: suppress the supplemental input at the model boundary. */
  toolContext?: boolean;
}): Promise<EvalRunResult> {
  const { session, model, provider, variant, run, language } = input;
  const db = new DatabaseSync(":memory:");
  try {
    runLcmMigrations(db);
    const conversationStore = new ConversationStore(db);
    const summaryStore = new SummaryStore(db);
    const conversation = await conversationStore.getOrCreateConversation(`eval-${session.label}`);
    const cid = conversation.conversationId;

    const records = await conversationStore.createMessagesBulk(
      session.messages.map((m) => ({
        conversationId: cid,
        seq: m.seq,
        role: m.role,
        content: m.content,
        tokenCount: m.tokenCount,
      })),
    );
    // Keep original timestamps so the prompt's time headers match production.
    const setCreated = db.prepare("UPDATE messages SET created_at = ? WHERE message_id = ?");
    records.forEach((r, i) => setCreated.run(session.messages[i].createdAt, r.messageId));
    const insertCall = db.prepare(`INSERT INTO transcript_tool_calls
      (session_id, call_id, message_id, name, input, outcome, block_reason, truncated)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)`);
    records.forEach((record, index) => {
      for (const call of session.messages[index].toolCalls ?? []) {
        insertCall.run(conversation.sessionId, call.callId, record.messageId, call.name,
          call.input, call.outcome, call.blockReason ?? null, Number(call.truncated ?? false));
      }
    });
    await summaryStore.appendContextMessages(cid, records.map((r) => r.messageId));

    const toolContextEnabled = input.toolContext !== false;
    const { summarize, calls } = instrumentSummarizer(input.summarizer, toolContextEnabled);
    // No scrubber: corpus content was already scrubbed at ingest and the export
    // copies stored content verbatim.
    const engine = new CompactionEngine(conversationStore, summaryStore, compactEngineConfig({ language }));
    const tokensBefore = await summaryStore.getContextTokenCount(cid);
    const startedAt = new Date().toISOString();

    let error: string | undefined;
    try {
      await engine.compact({ conversationId: cid, tokenBudget: COMPACT_TOKEN_BUDGET, summarize, force: true });
    } catch (err) {
      error = err instanceof Error ? err.message : String(err);
    }

    const items = await summaryStore.getContextItems(cid);
    const summaries: EvalRunResult["summaries"] = [];
    for (const item of items) {
      if (item.itemType !== "summary" || !item.summaryId) continue;
      const record = await summaryStore.getSummary(item.summaryId);
      if (record) {
        summaries.push({ summaryId: record.summaryId, content: record.content, ...scoreSummary(record.content, record.depth) });
      }
    }
    const tokensAfter = await summaryStore.getContextTokenCount(cid);

    const contextText = summaries.map((summary) => summary.content).join("\n\n");
    const scoredCalls = calls.filter((c) => c.format);
    const formatPass = scoredCalls.filter((c) => c.format!.hasExpandTrailer && c.format!.hasFilesLine !== false).length;
    const usages = calls.flatMap((call) => call.usages);
    const totalPhase = (phase: "prefillMs" | "decodeMs") => usages.some((usage) => usage[phase] !== undefined)
      ? usages.reduce((total, usage) => total + (usage[phase] ?? 0), 0) : null;

    return {
      toolContextEnabled,
      label: session.label,
      provider,
      variant,
      language,
      model,
      run,
      startedAt,
      incomplete: error !== undefined,
      error,
      inputMessages: session.messages.length,
      inputTokens: session.messages.reduce((n, m) => n + m.tokenCount, 0),
      tokensBefore,
      tokensAfter,
      calls,
      summaries,
      // An incomplete run leaves chunks un-summarized, so fact survival would be
      // scored against a partial context — report nothing rather than a low score.
      plantedFacts: session.plantedFacts && error === undefined ? checkPlantedFacts(contextText, session.plantedFacts) : undefined,
      totals: {
        calls: calls.length,
        failedCalls: calls.filter((c) => c.error).length,
        latencyMs: calls.reduce((n, c) => n + c.latencyMs, 0),
        inputTokens: usages.reduce((n, usage) => n + (usage.inputTokens ?? 0), 0),
        outputTokens: usages.reduce((n, usage) => n + (usage.outputTokens ?? 0), 0),
        costUsd: calls.length > 0 && calls.every((call) => call.usages.length > 0
          && call.attempts.every((attempt) => attempt.usageReports > 0))
          && usages.every((usage) => typeof usage.costUsd === "number")
          ? usages.reduce((n, usage) => n + usage.costUsd!, 0)
          : null,
        formatPass,
        formatTotal: scoredCalls.length,
        maxTokensHits: calls.reduce((n, call) => n + Math.max(
          call.usages.filter((usage) => usage.rejectionReason === "length" || usage.rejectionReason === "max_tokens").length,
          call.rejections.filter((reason) => /length|max_tokens/.test(reason)).length,
          !provider.endsWith("-process") && (call.usage?.outputTokens ?? 0) >= resolveMaxOutputTokens(call.targetTokens) ? 1 : 0,
        ), 0),
        rejectedCalls: calls.reduce((n, call) => n + Math.max(
          call.usages.filter((usage) => usage.rejectionReason !== undefined).length, call.rejections.length,
        ), 0),
        unsupportedDetails: calls.reduce((n, call) => n + call.unsupportedDetails.length, 0),
        prefillMs: totalPhase("prefillMs"),
        decodeMs: totalPhase("decodeMs"),
      },
    };
  } finally {
    db.close();
  }
}
