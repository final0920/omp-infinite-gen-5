import { existsSync, lstatSync, readdirSync, readFileSync, type Dirent } from "node:fs";
import { basename, join } from "node:path";

/**
 * What a subagent transcript's `.meta.json` sidecar can tell us about the
 * dispatch that created it. All three are null when the sidecar is missing,
 * unreadable or not a JSON object; a readable sidecar always yields
 * `parentSessionId`, the other two only when it carries them.
 */
export interface SubagentAttribution {
  parentSessionId: string | null;
  subagentType: string | null;
  subagentDesc: string | null;
}

const EMPTY_ATTRIBUTION: SubagentAttribution = {
  parentSessionId: null,
  subagentType: null,
  subagentDesc: null,
};

/**
 * Reads the `.meta.json` sidecar next to a subagent transcript.
 *
 * `folderSessionId` is the session that owns the `subagents/` directory the
 * transcript lives in — the parent for the common case (no `parentAgentId`
 * in the sidecar). When the sidecar does carry `parentAgentId` (a nested
 * dispatch), the immediate dispatcher is another `agent-<id>.jsonl` under the
 * same session's `subagents/` tree, not the owning session, so the id is
 * prefixed with `agent-` to match that transcript's own `session_id`.
 *
 * A missing, unreadable, or invalid sidecar — including one that parses to
 * something other than an object — yields all three fields null: not an
 * error, and no fallback to the folder name.
 */
export function readSubagentAttribution(
  transcriptPath: string,
  folderSessionId: string,
): SubagentAttribution {
  const metaPath = transcriptPath.replace(/\.jsonl$/, ".meta.json");
  if (!existsSync(metaPath)) return EMPTY_ATTRIBUTION;

  let parsed: unknown;
  try {
    parsed = JSON.parse(readFileSync(metaPath, "utf-8"));
  } catch {
    return EMPTY_ATTRIBUTION;
  }
  if (parsed === null || typeof parsed !== "object" || Array.isArray(parsed)) return EMPTY_ATTRIBUTION;
  const meta = parsed as Record<string, unknown>;

  const parentAgentId = typeof meta.parentAgentId === "string" && meta.parentAgentId ? meta.parentAgentId : null;
  return {
    parentSessionId: parentAgentId ? `agent-${parentAgentId}` : folderSessionId,
    subagentType: typeof meta.agentType === "string" ? meta.agentType : null,
    subagentDesc: typeof meta.description === "string" ? meta.description : null,
  };
}

export interface DiscoveredSubagentTranscript {
  path: string;
  /** Matches a `conversations.session_id` value (e.g. `agent-<id>`). */
  sessionId: string;
  mtime: number;
  attribution: SubagentAttribution;
}

/**
 * Every subagent transcript one session dispatched, with its attribution:
 * the only walker of `<sessionDir>/subagents/`, shared by `lcm import`, live
 * `/ingest` and the migration backfill so all three apply one rule.
 *
 * An `agent-<id>.jsonl` can sit directly under `subagents/` or nested
 * arbitrarily deeper — e.g. `subagents/workflows/wf_<id>/` for a workflow
 * run's own subagents — with the same format and the same sidecar at every
 * depth. Only `journal.jsonl` — a workflow run's own log, excluded by name,
 * not by shape — is not a transcript. `subagents/` itself and every entry
 * under it are skipped when symlinked; a directory that cannot be read is
 * skipped without losing what was found before it. The owning session is
 * `basename(sessionDir)` for every transcript found, however deep; the
 * directories in between are never a parent.
 *
 * Two transcripts under the same `subagents/` tree sharing a basename (so
 * the same `sessionId`) dedupe to the first one found, in walk order; every
 * later duplicate is dropped and logged instead of overwriting the row the
 * first one already ingested with a different transcript's tail.
 */
export function discoverSubagentTranscripts(sessionDir: string): DiscoveredSubagentTranscript[] {
  const subagentsDir = join(sessionDir, "subagents");
  if (!isRealDirectory(subagentsDir)) return [];
  const walk: WalkState = { folderSessionId: basename(sessionDir), out: [], seenSessionIds: new Set() };
  walkSubagentDir(subagentsDir, walk);
  return walk.out;
}

interface WalkState {
  folderSessionId: string;
  out: DiscoveredSubagentTranscript[];
  seenSessionIds: Set<string>;
}

function isRealDirectory(path: string): boolean {
  try {
    return lstatSync(path).isDirectory();
  } catch {
    return false;
  }
}

function listEntries(dir: string): Dirent[] {
  try {
    return readdirSync(dir, { withFileTypes: true });
  } catch {
    return []; // unreadable, or removed between the parent's readdir and this one
  }
}

function walkSubagentDir(dir: string, walk: WalkState): void {
  for (const entry of listEntries(dir)) {
    if (entry.isSymbolicLink()) continue;
    if (entry.isDirectory()) {
      walkSubagentDir(join(dir, entry.name), walk);
      continue;
    }
    const found = isSubagentTranscriptFile(entry) ? discoveredTranscript(join(dir, entry.name), walk.folderSessionId) : null;
    if (!found) continue;
    if (walk.seenSessionIds.has(found.sessionId)) {
      console.error(`subagent-attribution: duplicate sessionId "${found.sessionId}" at ${found.path}, keeping the first`);
      continue;
    }
    walk.seenSessionIds.add(found.sessionId);
    walk.out.push(found);
  }
}

function isSubagentTranscriptFile(entry: Dirent): boolean {
  return entry.isFile() && entry.name !== "journal.jsonl" && entry.name.endsWith(".jsonl");
}

function discoveredTranscript(path: string, folderSessionId: string): DiscoveredSubagentTranscript | null {
  try {
    const st = lstatSync(path);
    if (st.isSymbolicLink()) return null;
    return {
      path,
      sessionId: basename(path, ".jsonl"),
      mtime: st.mtimeMs,
      attribution: readSubagentAttribution(path, folderSessionId),
    };
  } catch {
    return null; // deleted between readdir and stat, or unreadable
  }
}

/**
 * `discoverSubagentTranscripts` over every `<project>/<session>/` directory
 * under a `~/.claude/projects`-shaped tree. Used by the one-time migration
 * backfill.
 */
export function walkSubagentTranscripts(claudeProjectsDir: string): DiscoveredSubagentTranscript[] {
  const entries: DiscoveredSubagentTranscript[] = [];
  if (!existsSync(claudeProjectsDir)) return entries;

  for (const projectEntry of readdirSync(claudeProjectsDir, { withFileTypes: true })) {
    if (!projectEntry.isDirectory()) continue;
    collectProjectSubagentTranscripts(join(claudeProjectsDir, projectEntry.name), entries);
  }

  return entries;
}

function collectProjectSubagentTranscripts(projectDir: string, out: DiscoveredSubagentTranscript[]): void {
  for (const sessionEntry of readdirSync(projectDir, { withFileTypes: true })) {
    if (!sessionEntry.isDirectory()) continue;
    out.push(...discoverSubagentTranscripts(join(projectDir, sessionEntry.name)));
  }
}
